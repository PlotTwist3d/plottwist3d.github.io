label credits:
    play music "audio/into the night.mp3"
    $ credits_speed = 60 #scrolling speed in seconds
    hide screen settingsUI with dissolve
    scene smoky background with fade
    $who_old = "VOICE"
    show cred at Move((0.5, 6.25), (0.5, 0.0), credits_speed, repeat=False, bounce=False, xanchor="center", yanchor="bottom")
    with Pause(credits_speed)
    $ renpy.pause()
    return

init python:
    credits = ('Based on The It Lives Anthology', 'By Pixelberry'), ('Project Founder & Director', 'Lindsay @linkysmommy'), ('Assistant Project Director', 'Maggie @heartofarcanum'), ('Head Writers', 'Lindsay @linkysmommy'), ('Head Writers', 'Maggie @heartofarcanum'), ('Senior Writers', 'Eri @pinesprings'), ('Senior Writers', 'Shionch @Shionch'), ('Senior Writers', 'M @myhamartiaishubris'), ('Senior Writers', 'Alex @emocean-is-trash'), ('Senior Writers', 'Evie @duchesshanalee'), ('Junior Writers', 'Sugar @honey-choices'), ('Junior Writers', 'Reb @zyrel'), ('Junior Writers', 'Ri'), ('Junior Writers', 'Salem @saibug1022'), ('Junior Writers', 'Orc @orcsmoocher'),  ('Art Assets', 'Pixelberry'), ('Artists', 'Aku @yourresidentartist'), ('Artists', 'Hashie @hashiedraws'), ('Artists', 'Kay @zigsnose'), ('Artists', 'Shionch @shionch'), ('Artists', 'Sam @dandywondrous'), ('Artists', 'Anja @ledenicvet'), ('Artists', 'Orc @orcsmoocher'), ('Artists', 'Tanu @robintora'), ('Artists', 'Carina @it-lived-in-the-woods'), ('Artists', 'Fern'), ('Artists', 'Layla @laylaisthename'), ('GUI', 'Lindsay @linkysmommy'), ('GUI', 'Shionch @shionch'), ('Senior Programmers', 'Shionch @shionch'), ('Senior Programmers', 'Kristi @frostedge'), ('Senior Programmers', 'Sugar @honey-choices'), ('Senior Programmers', 'Lindsay @linkysmommy'), ('Assistant Programmers', 'Evie @duchesshanalee'), ('Assistant Programmers', 'M @myhamartiaishubris'), ('Editor', 'Lindsay @linkysmommy'), ('Music', 'Amphibious Zoo Music'), ('Music', 'Lindsay @linkysmommy'), ('Music', 'Pixelberry'), ('Alpha Testers', 'Orc @orcsmoocher'), ('Alpha Testers', 'Reb @zyrel'), ('Alpha Testers', 'Ri'), ('Alpha Testers', 'Salem @saibug1022'), ('Beta Testers', 'Layla @laylaisthename'), ('Beta Testers', 'Thia @ascindio'), ('Beta Testers', 'Elias @el-dritchknight'), ('Beta Testers', 'Issa @issabees'), ('Beta Testers', 'Simone'), ('Social Media Manager', 'Eri @pinesprings')
    credits_s = "{size=100}{font=fonts/TTSupermolotNeue-ExtraBold.ttf}Credits\n\n"
    c1 = ''
    for c in credits:
        if not c1==c[0]:
            credits_s += "\n{size=55}" + "\n{font=fonts/TTSupermolotNeue-ExtraBold.ttf}" + c[0] + "\n"
        credits_s += "{size=40}" +  "\n{font=fonts/Sofia Pro Semi Bold Az.otf}" + c[1] + "\n"
        c1=c[0]
    credits_s += "\n{size=40}Engine\n{size=40}Ren'py\n6.15.7.374" #Don't forget to set this to your Ren'py version

init:
#    image cred = Text(credits_s, font="myfont.ttf", text_align=0.5) #use this if you want to use special fonts
    image cred = Text(credits_s, color="#ffffff", text_align=0.5)
    image theend = Text("{size=80}The end", text_align=0.5)
    image thanks = Text("{size=80}Thanks for Playing!", text_align=0.5)
