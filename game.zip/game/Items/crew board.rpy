default ghost_found = False
default pixel_found = False
default torque_found = False
default silk_found = False

image crew board = Transform(Composite(
    (769, 1350),
        (-200, 150), "images/Items/board/crew_board.png",
        (-200, 150), ConditionSwitch(
            "ghost_found", "images/Items/board/colt.png", # TODO replace this for selectable sprite
            True, "images/Colt/Mood/nothing.png"
        ),
        (-200, 150), ConditionSwitch(
            "pixel_found", "images/Items/board/pixel.png",
            True, "images/Colt/Mood/nothing.png"
        ),
        (-200, 150), ConditionSwitch(
            "silk_found", "images/Items/board/silk.png",
            True, "images/Colt/Mood/nothing.png"
        ),
        (-200, 150), ConditionSwitch(
            "torque_found", "images/Items/board/logan_[logan_race].png",
            True, "images/Colt/Mood/nothing.png"
        )
), zoom=1.2)