label chapter4_scene1:
    jump end_of_chapter