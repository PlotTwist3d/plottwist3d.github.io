# chapter 3
default ch3_title = "Under Fire"
default ch3_asked_for_backup = False
default ch3_ingrid_backup = False
default ch3_shot_by_colt = False
default ch3_disarm_colt = False
default ch3_roof_mona = False
default ch3_roof_ingrid = False
default ch3_roof_romance = False
default ch3_roof_ingrid_would = False
default ch3_colt_scene = False
default ch3_jackals_chase_calm = False