label chapter3_scene1:
    ##initalizing chapter variables
    $ middle = False
    $ bottom = False
    $ regular = True
    $ current_chapter = 3
    $ playable_character = "ELLIE"
    $ playing_as = capsEllie

    # restore chapter defaults
    $ save_relationship_system_scores()
    $ maximum_suave_points_end_of_chapter = maximum_suave_points
    $ maximum_serious_points_end_of_chapter = maximum_serious_points
    $ suave_points_end_of_chapter = suave_points
    $ serious_points_end_of_chapter = serious_points

    $ ch3_asked_for_backup = False
    $ ch3_ingrid_backup = False
    $ ch3_shot_by_colt = False
    $ ch3_disarm_colt = False
    $ ch3_roof_mona = False
    $ ch3_roof_ingrid = False
    $ ch3_roof_romance = False
    $ ch3_roof_ingrid_would = False
    $ ch3_colt_scene = False
    $ ch3_jackals_chase_calm = False

    # outfits
    $ change_mona_outfit(0, 0, False) # prison outfit
    if ch2_racer_outfit:
        $ change_ellie_outfit("racer", 1)
    else:
        $ change_ellie_outfit("casual", ellie_default_outfit)
    $ change_ingrid_outfit("mission", 1)

    play music "audio/TPA/action danger.mp3" fadein 0.5

    $ hide_character()
    scene black with fade

    show screen location_title("new york text") with dissolve
    show screen settingsUI
    show screen suave_and_serious_points
    $ renpy.pause(2, hard=True)
    hide screen location_title with dissolve

    "Your mind goes blank for a second as you stare at Colt, his gun trained squarely on your head."
    "A shiver runs down your spine, your mind momentaneously taken back to Jason Shaw."
    "The deafening sound of the shots ricocheting off your car. The accident. Jason pulling you out of your wrecked car."
    "Jason grabbing you like a human shield, putting the muzzle of the gun to your temple--"

    play music "audio/TPA/tense fight.mp3" fadein 0.5

    if not ch2_disable_comms:
        $ center_voice = AgentGrey.upper()
        center_grey "{color=[highlight]}Agent [Wheeler]. Do you copy?{/color}"
        $ center_voice = "TUTORIAL"

        $ hide_character()
        scene auto show security at mid_right with fade
        "[AgentGrey]'s voice pulls you back to the present. You steele yourself for the situation ahead."

    else:
        "You shake off the memories of your past."
        scene auto show security at mid_right with fade

    $ maximum_serious_points += 1

    $ show_character("ellie")
    ellie "Ten years, and you're still pointing guns at people instead of talking to them. Real charming, Colt."

    $ show_character("ellie", "angry")
    menu:
        ellie "Put the gun down."

        "You're wasting my time.":
            $ ch3_asked_for_backup = True
            $ hide_character()
            "You recall the way Ingrid had phrased the sentence before you left with Colt and hope she understands your meaning."
            
            if ch2_disable_comms:
                "You wait for the telltale sign of static in your ear... But then remember you disabled your comms!"

                $ my_notify_func("gui/notify.png", "WELL, WELL, WELL", "If it ain't the consequences\nof your actions...")
                $ show_character("ellie", "surprised")
                ellie "(Damn it! I'll have to do this on my own.)"

                jump ch3_gunpoint_no_backup

            else:
                "You hear the telltale sign of static in your ear before Ingrid's voice comes through."
                $ show_character("ingrid", modifier="holo")
                $ serious_points += 1
                ingrid_holo "On my way. Stall him."
                $ ingrid_relationship += 2
                $ ch3_ingrid_backup = True
                jump ch3_gunpoint_no_backup

        "You're making a mistake.":
            $ show_character("colt")
            colt "Am I?"
            $ colt_relationship -= 2
            colt "I don't think so."

            jump ch3_gunpoint_no_backup

        "Before I make you.":
            $ hide_character()
            "You glare at him."

            $ show_character("ellie", "angry")
            ellie "I'm serious, Colt. You think I can't take you down?"

            $ colt_relationship += 2

            $ show_character("colt", "happy")
            colt "I know you can."
            colt "That's why I have a gun on you."

            jump ch3_gunpoint_no_backup

    jump ch3_gunpoint_no_backup

label ch3_gunpoint_no_backup:
    $ show_character("colt")
    colt "Keep your hands where I can see them, Jackal."
    colt "And tell your squad to back off."
    
    $ show_character("ellie", "surprised")
    ellie "I don't have a squad."

    $ show_character("colt", "angry")
    colt "You think I'm an idiot?"

    if not ch2_maintained_cover:
        colt "Clearly nobody buys that you're a famous racer, and your \"target\" doesn't seem to mind."
        colt "Who is she, your Silk? Where are the others?"

    else:
        colt "You might have fooled everyone else but you don't fool me."
        colt "You're either the leader or you're the infiltrator."
        colt "So which one is it? Ghost or Silk?"

    $ show_character("ellie")
    ellie "You couldn't be more wrong if you tried."
    ellie "You're not going to shoot me, Colt."

    $ show_character("colt")
    colt "Oh yeah? And why's that?"

    $ show_character("ellie")
    menu:
        ellie "..."

        "{image=heart_colt} Because you love me." (hidden=not ellie_prom_love):
            $ show_character("colt")
            colt "{i}Love{/i}? Present tense?"

            $ show_character("ellie")
            ellie "I don't hear you denying it."

            if not ch2_disable_comms:
                $ show_character("mona", "surprised",modifier="bruised holo")
                mona_holo "Really? You're flirting now?"

                $ show_character("grey", modifier="holo")
                grey_holo "Ignore her. Do what you have to do, Agent."

            jump ch3_gunpoint_talk

        "{image=heart_colt} Because you need me." (hidden=ellie_prom_love):

            if ellie_prom == "Colt":
                ellie "You once told me you wanted to rule L.A. with me."
                ellie "Am I not in your plans anymore?"

            else:
                ellie "We were always the smartest of the MPC."
                ellie "I like a man with brains."

            if not ch2_disable_comms:
                $ show_character("mona", "surprised",modifier="bruised holo")
                mona_holo "Really? You're flirting now?"

                $ show_character("grey", modifier="holo")
                grey_holo "Ignore her. Do what you have to do, Agent."

            jump ch3_gunpoint_talk

        "Because you need something from me.":
            $ show_character("ellie")
            ellie "If you really did just want to kill me you would have done it already."
            ellie "And with all the questions you're asking about the Jackals it's easy to guess."
            ellie "Just so you know, the chances of me talking go exponentially down if you shoot me."

            $ show_character("colt", "surprised")
            colt "So you do know something."

            $ hide_character()
            "You notice his grip on the gun slackening. He doesn't seem to realize it himself."

            jump ch3_gunpoint_fight

        "[[Go for the gun]" (hidden=ch3_asked_for_backup):
            $ ch3_shot_by_colt = True
            
            $ hide_character()
            "You lunge for the gun... And manage to grab Colt's wrist!"
            "You try to wrestle it out of his hand."

            play sound "audio/SFX/sfx pistol shot.mp3"

            "The gun goes off..."

            jump title_screen_for_demo

label ch3_gunpoint_talk:
    $ hide_character()
    "He looks at you intensely and for one charged moment you think he might drop the gun... But then he tightens his grip."
    $ colt_romance += 1

    $ show_character("colt")
    colt "Don't try to distract me."

    $ show_character("ellie", "happy")
    ellie "So you think I'm distracting, huh?"

    $ show_character("colt", "surprised")
    colt "I have a gun to your head!"

    $ show_character("ellie")
    ellie "And? I always liked a little danger."

    $ show_character("colt", "surprised")
    colt "A {i}little{/i}?!"

    $ hide_character()
    "His grip on the gun goes a little slack. Colt doesn't seem to notice."
    
    jump ch3_gunpoint_fight

label ch3_gunpoint_fight:
    $ show_character("ellie", "surprised")
    ellie "(Now's my chance!)"

    menu:
        ellie "(I'll...)"        
        "Disarm him!":
            $ ch3_disarm_colt = True
            $ hide_character()
            "You lunge for the gun... And manage to grab his wrist!"
            if ch3_asked_for_backup:
                "As if on cue, you see Ingrid quietly slide open the vent right behind Colt."
                "She catches your eye as she lowers herself to the floor, not making a single sound."
            "You try to wrestle the gun out of Colt's hand."
        
        "Punch him!" (hidden=ch3_asked_for_backup):
            $ hide_character()
            "Taking advantage of his momentaneous distraction, you ball your hand into a fist and smack him hard on the face!"

            $ show_character("colt", "surprised", shake=True)
            colt "{i}Hrk{/i}!"

            $ hide_character()
            "As your hand makes contact with him face, he squeezes the trigger."
        
        "Wait for backup." (hidden=not ch3_asked_for_backup):
            $ show_character("ellie")
            ellie "Think about what you're doing, Colt..."
            ellie "If I'm really with the Jackals do you think you can take on all of us?"

            $ show_character("colt")
            colt "I won't need to because you'll call them off."
            $ show_character("colt", "angry")
            colt "Now."

            $ show_character("ellie")
            ellie "I {i}would{/i}. If I was with them."

            $ show_character("colt", "angry")
            colt "If you're not with them then who are you with?"

            $ hide_character()
            "As if on cue, you see Ingrid quietly slide open the vent right behind Colt."
            "She catches your eye as she lowers herself to the floor, not making a single sound."

            $ show_character("ingrid")
            ingrid "..."

            $ hide_character()
            "You quickly refocus your attention back on Colt."

            $ show_character("ellie")
            ellie "Who am I with?"

            $ hide_character()
            "You allow yourself a little smile."

            $ show_character("ellie", "happy")
            if ingrid_codename:
                ellie "[ingrid_codename]."
            else:
                ellie "Her."

            $ show_character("colt", "surprised")
            colt "Who--"

            $ show_character("ingrid", "angry")
            ingrid "Me."

            $ hide_character()
            "He whips around, startled at the sound of her voice behind him. She catches his wrist."
            "As he struggles with Ingrid, you drop to a low crouch and sweep his legs!"

            $ show_character("colt", "surprised", shake=True)
            colt "{i}Hrk{/i}!"

            $ hide_character()
            "Ingrid manages to keep ahold of his arm as he tumbles to the floor."
            "You attempt to remove the gun from his hand--"

    play sound "audio/SFX/sfx pistol shot.mp3"
    
    $ hide_character()
    "The gun goes off..."
    
    #jump title_cutscene
    jump title_screen_for_demo

label chapter3_after_title_cutscene:
    v "Chapter 3: [ch3_title]"

    play music "audio/TPA/tense fight.mp3" fadein 0.5
    show screen suave_and_serious_points
    show screen settingsUI
    scene auto show security at mid_right with fade

    $ ellie_gunshot = ch3_shot_by_colt ### will display Ellie with gunshot wound

    if ellie_gunshot:
        jump ch3_shot_fired
    else:
        "The bullet lodges itself on the wall behind you, missing you by an inch."

        "You manage to wrestle the gun out of Colt's grip. You eject the magazine with practised ease, and let the bullets scatter across the floor."

        "Finally, you pull back the slide, checking that the chamber is empty. You keep the gun with you, just in case."

        $ show_character("ellie")
        ellie "All clear."

        if ch3_ingrid_backup:
            $ hide_character()
            "Ingrid grunts with the effort of holding Colt immobilized, her arms around his neck in a vice."

            $ show_character("ingrid", "angry")
            ingrid "Mr. Kaneko, stop resisting. We are not your enemies--"

            $ show_character("colt", "angry")
            colt "This sure feels friendly."

            $ show_character("ellie", "angry")
            ellie "It was friendly until you pointed a gun at me!"

            if colt_flirt:
                $ show_character("mona", modifier="bruised holo")
                mona_holo "I thought you were into that, the way you were flirting with him..."

            $ hide_character()
            "Colt snarls but doesn't resist further. You see Ingrid tighten her grip just enough to remind him who's in control."

            "Your earpiece crackles louder than usual, and you see Ingrid flinch from the sound."

            $ show_character("grey", "surprised", modifier="holo")
            grey_holo "Agent Delaney, it's all clear. You have the go ahead."

            $ show_character("ellie", "surprised")
            ellie "What--"

            $ hide_character()
            "Ingrid clears her throat and slowly releases Colt. He bats her away, trying to smooth out his suit."

            $ show_character("ingrid")
            ingrid "Mr. Kaneko, you called us here. On behalf of Halo?"

            $ hide_character()
            "He snorts."

            $ show_character("colt")
            colt "I didn't call you. I called--"

            $ hide_character()
            "He cuts himself off, understanding downing on him."
            "He turns to you, eyes wide in shock."

            $ show_character("colt", "surprised", shake=False)
            colt "You're a Phantom Agent?!"

            $ show_character("ellie")
            ellie "Say that louder, why don't you? It's not like it's a secret or anything."

            $ show_character("ingrid")
            ingrid "Mr. Kaneko--"

            $ show_character("colt")
            colt "Kaneko was... was my father. Call me Colt."

            if ellie_prom == "Colt":
                $ hide_character()
                "Something flashes in Ingrid's eyes and you know exactly what she's recalling."

                "You think back to prom night."

                scene prom sepia at center with dissolve
                "Slowly dancing with Mona, you suddenly bump into somebody else on the floor."
                $ young_colt_outfit = "prom"
                $ brent_outfit = "prom"
                $ show_character("ingrid", "angry", modifier="young")
                ingrid "Ugh, could you {i}please{/i} watch where you're going?"

                $ hide_character()
                "You turn around to see Ingrid and Brent."
                "Brent gives Mona the once-over."

                $ show_character("brent", "angry")
                brent "Do you even go to this school?"

                $ show_character("colt", modifier="young")
                colt "Do I {i}look{/i} like I go to this school?"

                $ hide_character()
                scene auto show security at mid_right with fade

                "Ingrid scowls at you but regains her professional demeanor quickly."

            $ show_character("ingrid")
            ingrid "{i}Colt{/i}. I'm Phantom Agent Delaney."

            $ hide_character()
            "She gestures vaguely at you."

            $ show_character("ingrid")
            ingrid "And you're acquainted with Phantom Agent [Wheeler]."

            $ hide_character()
            "She glares at you for a moment before focusing back on Colt."

            $ show_character("ingrid")
            ingrid "We're investigating the Jackals."

        else:
            "Colt stares at you, shocked by the accidental discharge of his gun."

            $ show_character("colt", "surprised")
            colt "[Ellie], I..."

            $ hide_character()
            "He watches the way you hold the gun, your entire posture. You see the gears turning inside his brain."
            "He looks at you, eyes wide in shock."

            $ show_character("colt", "surprised")
            colt "It's you, isn't it?"
            colt "You're a Phantom Agent!"

        jump ch3_colt_jackals

label ch3_shot_fired:
    $ my_notify_func("gui/notify.png", "TARGET PRACTISE", "Colt shot you on accident at\nthe Auto Show!")
    "The bullet pierces your shoulder, lodging itself on the wall behind you when it exits your body."

    $ show_character("ellie", "surprised")
    ellie "{i}Hrk...{/i}"

    $ hide_character()
    "Colt stares at you, shocked by the accidental discharge of his gun."

    $ show_character("colt", "surprised")
    colt "Oh God... [Ellie], I..."

    $ hide_character()
    "You tumble backwards, slumping against the wall, blood pouring out of your wound."
    "The reaches for you, the gun forgotten. Colt pull out the handkerchief from his immaculate white suit, trying to stop the bleeding."

    $ show_character("colt", "surprised")
    colt "I didn't mean to shoot you--"

    if not ch2_disable_comms:
        if current_li == "Mona":
            $ show_character("mona", "surprised", modifier="bruised holo")
            mona_holo "[Ellie_nickname]? [Ellie_nickname!u]?!"
        elif current_li == "Ingrid":
            $ show_character("ingrid", "surprised", modifier="holo")
            ingrid_holo "Agent [Wheeler]? [Ellie]? [Ellie_nickname!u]?!"
        else:
            $ show_character("grey", "surprised", modifier="holo")
            grey_holo "Agent [Wheeler]? Agent [Wheeler], do you copy?"

    if ch2_disable_comms:
        $ hide_character()
        "You click your comms back on."

    $ show_character("ellie", "sad")
    ellie "This is... {i}Hrk{/i}... This is Agent [Wheeler], requesting backup. I have been shot-- {i}Ugh{/i}-- in the shoulder."

    $ show_character("ingrid", "surprised", modifier="holo")
    ingrid_holo "Don't do anything stupid! I'm on my way."

    $ show_character("colt", "surprised")
    colt "Agent--"

    $ hide_character()
    "Understanding seems to down on him as he puts the gun away, applying pressure to your wound."

    $ show_character("colt", "surprised")
    colt "We know everyone that was hired the secure this event, which means..."
    colt "It's you, isn't it?"
    colt "You're a Phantom Agent!"

    jump ch3_colt_jackals

label ch3_colt_jackals:
    $ hide_character()
    if not ch3_asked_for_backup:
        "You're about to reply, to protect your secret identity, when he suddenly starts laughing."

    $ show_character("colt", "happy")
    colt "Of course it's you! That makes so much more sense."

    $ show_character("ellie")
    ellie "And here I was thinking you couldn't sound crazier than when you were holding me hostage..."

    $ show_character("colt", "happy")
    colt "It was me, [Ellie_nickname]. I contacted GAIA."

    $ show_character("ellie", "surprised")
    ellie "(Oh... This must have been addressed on that briefing that I skipped to break Mona out of jail.)"
    if current_li == "Mona":
        ellie "(Worth it.)"

    play music "audio/TPA/default chill.mp3" fadein 0.5

    $ show_character("ellie")
    ellie "About the Jackals?"

    $ show_character("colt", "neutral")
    colt "Right... the Jackals."

    $ hide_character()
    "He stares at you awkwardly for a moment. Then he cracks a smile."

    $ show_character("colt", "happy")
    colt "Eh, I should have guessed."
    colt "Of course you'd turn out to be a secret agent, after the way you took down Shaw."

    $ hide_character()
    $ bottom = True
    $ middle = False
    $ regular = False
    show big colt at center with dissolve
    menu:
        b3 "And you..."

        "Always had terrible aim but congrats, you finally hit something.":
            hide big colt with dissolve
            $ bottom = False
            $ middle = False
            $ regular = True
            "He snorts."
            $ colt_relationship += 2

            if ellie_gunshot:
                $ show_character("colt", "happy")
                colt "And that's without even aiming."
                colt "You'd be screwed if I actually wanted to kill you, Agent [Wheeler]."
            else:
                $ show_character("colt", "happy")
                colt "That wall sure had it coming."
                colt "A little bit to the right and you'd be screwed, though. A small mercy from me."

            $ show_character("ellie", "angry")
            ellie "You know I can arrest you, right?"

            $ show_character("colt")
            colt "Sure. If you didn't need my help."

        "Are still hotheaded and rash.":
            hide big colt with dissolve
            $ bottom = False
            $ middle = False
            $ regular = True
            $ colt_relationship -= 2
            $ show_character("colt", "angry")
            colt "Ah, of course! My very rash decision to lure you away and hold you at gunpoint."
            colt "Absolutely no prior preparation came into that. No weapons needed, no isolated space..."
            
            $ show_character("ellie", "angry")
            ellie "You know I can arrest you, right?"

            $ show_character("colt")
            colt "Sure. If you didn't need my help."

        "{image=heart_colt}Couldn't wait to get a piece of me, huh?" (hidden=not ellie_gunshot):
            $ my_notify_func("gui/notify.png", "BLEEDING HEART", "You flirted with Colt even though he\nshot you! Are you ok?")
            hide big colt with dissolve
            $ bottom = False
            $ middle = False
            $ regular = True
            $ show_character("colt", "surprised")
            colt "Not like this! I didn't mean to shoot you."

            $ show_character("ellie", "happy")
            ellie "Then you better make it up to me when I stop bleeding all over this perfectly good floor."

            $ colt_romance += 1
            $ show_character("colt")
            colt "You're unbelievable, [Ellie] [Wheeler]."

            $ show_character("ellie")
            ellie "Why did you contact GAIA anyway? If anything I expected you to be on the Jackals' side."

        "{image=heart_colt}Look nice in that suit." (hidden=ellie_gunshot):
            hide big colt with dissolve
            $ bottom = False
            $ middle = False
            $ regular = True
            $ show_character("colt", "happy")
            colt "Just \"nice\"?"

            $ show_character("ellie", "happy")
            ellie "You lose style points for holding me at gunpoint."

            $ colt_romance += 1
            $ show_character("colt")
            colt "You're unbelievable, [Ellie] [Wheeler]."

            $ show_character("ellie")
            ellie "Why did you contact GAIA anyway? If anything I expected you to be on the Jackals' side."

    $ show_character("colt")
    colt "I reached out to GAIA because they have been targetting my company a lot."

    $ show_character("ellie")
    ellie "Your company?"

    $ show_character("colt")
    colt "Halo. I'm co-founder, built it from the ground up."
    $ show_character("colt", "angry")
    colt "And now these assholes swept in and terrified my hard-earned customer base."

    $ show_character("ellie")
    ellie "I hope you realize how hypocritical that sounds coming from you, Colt Kaneko of the MPC."

    $ show_character("colt", "happy")
    colt "It's only okay when I do it."
    $ show_character("colt")
    colt "Besides, I've left that life behind."
    colt "It's what my father would have wanted."

    if ch3_ingrid_backup:
        if not colt_flirt:
            $ show_character("ingrid")
            ingrid "Sorry to break up the passive-aggressive reunion, but we have more important things to focus on."

        else:
            $ show_character("ingrid")
            ingrid "Sorry to break up the... whatever the Hell you two got going on, but we have more important things to focus on."
        
    elif ch3_shot_by_colt:
        
        $ hide_character()
        "You keep pressure on your wound as Colt steps back."

    $ show_character("ellie")
    ellie "Right."
    ellie "Was there even an actual prototype or did you just want to lure me here, Colt?"

    $ show_character("colt")
    colt "There is."

    $ show_character("ellie")
    ellie "Take me to it."

    if ch3_shot_by_colt:
        $ show_character("colt", "surprised")
        colt "So you can bleed all over the leather seats?"

        $ show_character("ellie", "angry")
        ellie "And whose fault would that be, huh?"
        $ show_character("ellie")
        ellie "Look, I think the Jackals may be after it."

        $ show_character("colt", "surprised")
        colt "Should you really still be working? You're injured!"

        $ show_character("ellie")
        ellie "That never stopped me before."

    else:
        $ show_character("colt", "happy")
        colt "No offense, but I don't think you can afford to buy it on your International Super Spy salary."

        if ch3_ingrid_backup:
            if ch1_ingrid_truth:
                $ show_character("ingrid")
                ingrid "I'm pretty sure she could just steal it."
            else:
                $ hide_character()
                "Ingrid scoffs."
                $ show_character("ingrid", "angry")
                ingrid "Like she wouldn't just steal it."

        $ show_character("ellie", "surprised")
        ellie "Not the point!"
        $ show_character("ellie")
        ellie "The Jackals may be after it."

    $ show_character("colt")
    colt "That... is actually a fair point."

    if ch3_ingrid_backup:
        $ show_character("ingrid")
        ellie "I think we should split up."
        ellie "For all we know they might still be mingling with the guests. Silk, especially."

        $ hide_character()
        "Ingrid looks as if she wants to argue with you but decides against it."

        $ show_character("ingrid")
        ingrid "Right..."

        $ show_character("ellie")
        ellie "I'll check the prototype."

        $ hide_character()
        "Ingrid gives you a slight nod and glares at Colt before leaving."

    if ch3_shot_by_colt:
        $ show_character("colt", "surprised")
        colt "But are you sure you're up for--"

        $ show_character("ellie", "angry")
        ellie "Colt."

        $ hide_character()
        "He puts his hands up in surrender."

    $ show_character("colt")
    colt "Alright, follow me."

    jump ch3_scn1_prototype

label ch3_scn1_prototype:
    $ hide_character()
    "You follow Colt through a series of doors and hallways."

    scene auto show prototype at center with fade

    $ show_character("colt")
    colt "Here we are."

    $ timeout_label = None
    $ show_character("ellie")
    menu:
        ellie "Wow, this is..."

        "So extra.":
            $ colt_relationship -= 2
            $ show_character("colt", "angry")
            colt "It's for VIPs only, be glad I even brought you here."
            
            $ show_character("ellie")
            ellie "Sure."
        
        "Fancy.":
            $ show_character("colt")
            colt "It better be. Cost me a fortune to set this up."

    $ show_character("ellie")
    ellie "The car looks a lot like your dad's."

    $ show_character("colt")
    colt "That's the point."
    colt "It wasn't easy to start fresh, you know?"
    colt "Once I made it to the top I wanted to do something to honor him."
    $ show_character("colt", "sad")
    colt "I wish he was here to see it."

    $ hide_character()
    "He seems to catch himself and clears his throat hastily."

    $ show_character("colt")
    colt "So, what's the plan?"
    $ hide_character()

    scene black with fade
    pause 2.0

    jump ch3_jones_mission

label ch3_jones_mission:
    #scene something with fade
    play music "audio/TPA/spy investigate.mp3" fadein 0.5
    scene junk at left with fade
    pause 1.5

    $ playable_character = "JONES"
    $ playing_as = capsAgentJones

    $ hide_character()
    tutorial "Now playing as [AgentJones] [Jones]."

    "Once you make it to the drop location, you make a beeline for the globe."

    $ show_character("jones")
    left_jones "(I hope I'm right about this...)"

    $ hide_character()
    "You brush your fingertip over {color=[highlight]}Morocco{/color} and press down..."
    "... Until you hear a click and the top half pops open."

    $ show_character("jones", "happy")
    left_jones "(Let's see what we have here...)"

    $ hide_character()
    show screen item("flashdrive_silver", "It's a flashdrive.")
    $ regular = False
    $ bottom = True
    menu:
        with dis
        "Jackpot!":
            $ bottom = False
            $ regular = True
    
    hide screen item with dis

    $ hide_character()
    "You pocket the flashdrive."

    $ show_character("vivian", modifier="holo")
    vivian_holo "Did you get it?"

    $ show_character("jones", "happy")
    left_jones "Yup, piece of cake."

    $ show_character("vivian", modifier="holo")
    vivian_holo "Good, because I have news from your mentees."

    $ show_character("jones")
    left_jones "That can't be good..."

    if ch3_shot_by_colt:
        $ show_character("vivian", "sad", modifier="holo")
        vivian_holo "Bullet wounds rarely are."

        $ show_character("jones", "surprised")
        left_jones "[Ellie_nickname] got shot?!"

        $ show_character("vivian", "surprised", modifier="holo")
        vivian_holo "First of all, how do you know it wasn't Ingrid?"

        $ show_character("jones", "surprised")
        left_jones "Vivian!"

        $ show_character("vivian", "surprised", "holo")
        vivian_holo "[Ellie]'s fine! Jeez!"
        vivian_holo "Just bleeding a little!"
    
    else:
        $ show_character("vivian", modifier="holo")
        vivian_holo "Your baby had a gun pointed at [ellie_pronoun_pos_her] head."

        $ show_character("jones", "surprised")
        left_jones "Please tell me [Ellie_nickname]'s okay."

        $ show_character("vivian", "surprised", modifier="holo")
        vivian_holo "First of all, how do you know it wasn't Ingrid?"

        $ show_character("jones", "surprised")
        left_jones "Vivian!"

        $ show_character("vivian", "surprised", "holo")
        vivian_holo "[Ellie]'s fine! Jeez!"
        $ show_character("vivian", modifier="holo")
        if not ch3_ingrid_backup:
            vivian_holo "[ellie_pronoun_she!c] disarmed the guy."
        else:
            vivian_holo "Ingrid had [ellie_pronoun_her] back."

    $ hide_character()
    "You breathe a sigh of relief."

    $ show_character("jones")
    left_jones "Good."

    $ show_character("vivian", modifier="holo")
    vivian_holo "So... [Ellie]?"

    $ show_character("jones", "happy")
    left_jones "You think the best spy in the entire world wouldn't know?"

    $ show_character("vivian", "happy", modifier="holo")
    vivian_holo "You mean [Grey]? She knows, for sure."

    $ show_character("jones", "happy")
    left_jones "Very funny."
    if jones_grey_dating:
        left_jones "Leave my [grey_partner] out of this."
    else: # jones is single
        menu:
            left_jones "Let me remind you that..."

            "I'm your [jones_partner]." (disabled=jones_grey_dating):
                $ my_notify_func("gui/notify.png", "PLOT TWIST", "[Jones] and Vivian are dating!")
                $ jones_viv_dating = True
                left_jones "So you should be nicer to me."
                
                $ show_character("vivian", "happy", "holo")
                vivian_holo "I'll make it up to you later."
                $ show_character("vivian", modifier="holo")
                vivian_holo "If you answer me seriously, that is."

                $ show_character("jones")
                left_jones "Fine."

            "I kicked [AgentGrey!c]'s ass.":
                $ show_character("vivian", "happy", "holo")
                vivian_holo "Didn't [grey_pronoun_she] kick your ass too?"

                $ show_character("jones", "happy")
                left_jones "I don't know what you're talking about."

                $ show_character("vivian", modifier="holo")
                vivian_holo "Sure. What's the actual answer, though?"

    $ show_character("jones")
    left_jones "If anyone was going to go off course it would be [Ellie]."
    left_jones "This mission is personal to [ellie_pronoun_her]."

    $ show_character("vivian", "surprised", "holo")
    vivian_holo "I thought you couldn't be assigned personal missions? Especially after you and You-Know-Who..."

    $ show_character("jones", "neutral")
    left_jones "I don't think the director knows about it."

    $ show_character("vivian", "surprised", "holo")
    vivian_holo "But you do. Are you going to tell him?"
    vivian_holo "I mean, it's what you're supposed to do, right? She already got shot at and all--"

    $ show_character("jones", "neutral")
    left_jones "Nobody's telling anyone anything."

    $ show_character("vivian", "surprised", "holo")
    vivian_holo "Sorry, I'm going to need you to repeat that. It sounded like you were talking about breaking protocol. Again."
    $ show_character("vivian", "surprised", "holo")
    vivian_holo "And make me an accomplice to it. Again!"
    vivian_holo "Why would you tell me?!"

    $ show_character("jones", "happy")
    left_jones "Vivian, we all know you're just an Internet person. You don't exist IRL."
    
    $ show_character("vivian", "surprised", "holo")
    vivian_holo "... Are you referencing a meme? Wow, the situation must be dire."

    $ show_character("jones", "happy")
    left_jones "I pay attention to your Internet mambo jambo."

    if jones_viv_dating:
        left_jones "Besides, we have no secrets between us."

    $ hide_character()
    "You hear Vivian sigh heavily."

    $ show_character("vivian", "neutral", "holo")
    vivian_holo "He won't hear it from me either."
    $ show_character("vivian", "surprised", "holo")
    vivian_holo "But I will not be breaking you out of jail one more time! I'm drawing the line!"

    $ show_character("jones")
    left_jones "I'm sure I can manage not to get caught."

    $ show_character("vivian", "neutral", "holo")
    vivian_holo "Manage all you want, I'm serious here."
    vivian_holo "You do understand they won't give you a second chance, right?"
    $ show_character("vivian", "surprised", modifier="holo")
    vivian_holo "Why are you protecting her? Why is this so important?"

    $ show_character("jones")
    left_jones "[Ellie_nickname]'s a good kid, Vivian... [ellie_pronoun_she!c] just got in with the wrong crowd."

    if ch1_trail_mission_successful:
        left_jones "The potential is there, you saw how [ellie_pronoun_she] handled all [ellie_pronoun_pos_her] training missions."
    else:
        left_jones "Still a little rough around the edges but [ellie_pronoun_she]'ll get there."
    
    left_jones "[ellie_pronoun_pos_her!c] heart is in the right place. I know [ellie_pronoun_she] wants to do good."

    $ hide_character()
    "There's a beat of silence before Vivian gasps in understanding."

    $ show_character("vivian", "surprised", "holo")
    vivian_holo "You think she's another Rowan."

    $ hide_character()
    "You flinch at the mention of your late ex and parter, {color=[highlight]}Rowan Salazar{/color}."

    $ show_character("vivian", "surprised", "holo")
    vivian_holo "That's-- Wow, ok! A lot to unpack there--"

    $ show_character("jones")
    left_jones "I already failed Rowan. I'm not failing [Ellie_nickname] too."
    $ hide_character()

    scene black with fade
    pause 1.0

    jump ch3_scn2_prototype