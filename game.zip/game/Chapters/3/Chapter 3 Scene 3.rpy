label ch3_mission_debrief:
    scene safehouse simple at left with fade

    $ ellie_gunshot = False
    $ change_ellie_outfit("casual", ellie_default_outfit, gunshot=False)
    $ change_ingrid_outfit("casual", 1)
    $ ch3_jackals_chase_calm = completed_mission(mission_required_value, mission_current_value,
                                                achievement_success_title, achievement_success_text,
                                                achievement_failure_title, achievement_failure_text)

    $ maximum_serious_points += 1

    play music "audio/TPA/default chill.mp3"

    if ch3_shot_by_colt:
        $ hide_character()
        "Back at the safe house, you sit by while Agent [Grey] expertly cleans and bandages your wound."

        $ show_character("grey")
        grey "There... How does that feel?"

        $ hide_character()
        "You poke at the bandages on your shoulder."

        $ show_character("ellie")
        ellie "Better. Thank you, [AgentGrey]."

        $ show_character("grey")
        grey "You were lucky it didn't hit anything major."

        $ show_character("ingrid", "angry")
        ingrid "You're not lucky, you're an idiot!"

        if ch2_disable_comms:
            ingrid "How could you be so reckless?!"
        else: 
            ingrid "You should have asked for backup the moment you saw the gun!"

        $ show_character("ellie", "angry")
        ellie "I had it under control!"

        $ my_notify_func("gui/notify.png", "MISSION IMPOSSIBLE", "You'll get another shot. Pun intended.")

        $ show_character("ingrid", "angry")
        ingrid "{i}Clearly{/i}."

        $ hide_character()
        "Next to you, Mona snorts."

        $ show_character("mona", "happy", modifier="bruised")
        "I went through all that trouble taking a bullet for you and you get shot anyway? What a waste."
        
        if current_li == "Mona":
            $ hide_character()
            "Mona looks as nonchalant as ever, but the way she keeps hovering closer to you tells you otherwise."

    else:
        $ hide_character()
        "Back at the safe house, you sit by while Ingrid relays everything to Agent [Grey]."

        if not ch2_maintained_cover:
            $ show_character("ingrid", "surprised")
            ingrid "First [Ellie] couldn't keep her cover together, then that Colt guy showed up."
        else:
            $ show_character("ingrid", "surprised")
            ingrid "Our cover was intact, I didn't think there would be a problem with us splitting up."
        
        ingrid "But then the whole thing with the car happened--"

        if ch3_jackals_chase_calm:
            $ serious_points += 1
            $ show_character("grey")
            grey "Which Agent [Wheeler] handled well enough, giving the circumstances."

        $ show_character("ingrid", "angry")
        ingrid "And the suspect got away."

        $ hide_character()
        "Ingrid gives you a dirty look."
        "Mona turns to you."

        $ show_character("mona", "happy", modifier="bruised")
        mona "You've got a real talent for attracting guns, Ellie. You should put that in your résumé, if this whole super spy thing doesn't work out."

    if current_li == "Mona":
        $ hide_character()
        "Mona looks as nonchalant as ever, but the way she keeps hovering closer to you tells you otherwise."

    $ hide_character()
    "Ingrid gapes at her."

    $ show_character("ingrid", "surprised")
    ingrid "What is wrong with you?!"

    $ hide_character()
    "Mona shrugs."

    $ show_character("mona", "happy", modifier="bruised")
    mona "Not a thing. What's wrong with you?"

    $ show_character("ellie")
    ellie "She uses humor as a defense mechanism when she's anxious."

    $ show_character("mona", modifier="bruised")
    mona "I do not."

    $ show_character("ellie")
    ellie "Didn't say it was you, but if the shoe fits..."

    $ show_character("ingrid", "angry")
    ingrid "Well, stop it. It's annoying."

    $ show_character("mona", "angry", modifier="bruised")
    mona "Nobody asked you."
    
    $ hide_character()
    "They continue bickering."
    "You roll your eyes at them, pushing off past Agent [Grey]."
    
    if ch3_shot_by_colt:
        "Your shoulder brushes [AgentGrey]'s and you wince, touching the wound with your hand."

        if current_li == "Mona":
            $ show_character("mona", "surprised", modifier="bruised")
            mona "[Ellie_nickname]--"

        elif current_li == "Ingrid":
            $ show_character("ingrid", "surprised")
            ingrid "[Ellie_nickname]--"

        else:
            $ show_character("grey", "surprised")
            grey "[Ellie_nickname]--"

        $ show_character("ellie", "angry")
        ellie "I'm fine! I just need some air."

    else:

        $ show_character("ellie")
        ellie "I'm going to get some air."

        $ hide_character()
        "They don't seem to hear you over their bickering."

    $ hide_character()
    "You storm off upstairs to the roof."

    scene new york view rail empty

    "You watch the city below, taking a deep breath."
    "You hear the roof door creak softly as someone makes their way up."
    "You turn around."

    if ellie_prom == "Mona" and current_li == "Mona": # if you flirted with her enough basically
        jump ch3_mission_debrief_mona
    else:
        jump ch3_mission_debrief_ingrid

label ch3_mission_debrief_mona:
    $ ch3_roof_mona = True
    $ ch3_roof_ingrid = False
    scene new york view rail empty

    if ch3_shot_by_colt:
        $ hide_character()
        "Mona comes stand next to you, her hand on the rail. She fixes her gaze on the city below, silent for a beat."

        $ show_character("mona", modifier="bruised")
        mona "You okay?"
        mona "Don't worry, scars are sexy. Trust me, I have a bunch of them."

        $ show_character("ellie", "sad")
        ellie "Mona..."

        scene new york view rail mona with dissolve
    
    else:
        $ show_character("mona", modifier="bruised")
        mona "Shouldn't you be planning your next step instead of hiding here?"

        mona "Sure, you had a gun to your head but you handled it fine."

        $ hide_character()
        "She comes to stand next to you, her hand on the rail. Mona fixes her gaze on the city below, silent for a beat."
        
        scene new york view rail mona with dissolve

    $ show_character("ellie", "sad")
    ellie "Can we not talk about this right now?"

    $ show_character("mona", modifier="bruised")
    mona "What do you want to talk about?"

    $ show_character("ellie")
    ellie "Do we need to talk?"
    
    $ hide_character()
    "She pauses."

    $ show_character("mona", modifier="bruised")
    mona "I've thought about this moment a lot. I've thought about {i}you{/i} a lot."

    $ show_character("ellie")
    menu:
        ellie "I've..."

        "{image=heart_mona} Thought about you too.":
            play music "audio/ROD/romance sentimental.mp3"
            $ ch3_roof_romance = True
            ellie "I've been kind of waiting for you."

            if ch2_mona_diamond_scene_casual_fun:
                $ hide_character()
                "Mona raises her eyebrow."

                $ show_character("mona", modifier="bruised")
                mona "Sure you have, Miss Casual Fun."

            elif ch2_mona_diamond_scene_someone_else:
                $ hide_character()
                "Mona raises her eyebrow."

                $ show_character("mona", modifier="bruised")
                mona "So you telling me you were interested in someone else was what? A lie?"

                if colt_flirt and not ch2_disable_comms:
                    mona "You flirted with Colt too. Must be missing the entire crew."
                    mona "Did you throw Logan a bone too when I wasn't listening?"

            else:
                $ hide_character()
                "Mona raises her eyebrow. You blab on."

                $ show_character("ellie")
                ellie "Not in the sense that I didn't try to be with anyone else... It's just nobody compares to you."

                $ show_character("mona", "happy", modifier="bruised")
                mona "Yeah, well, I'm hard to forget."

                $ show_character("ellie")
                ellie "You told me to forget you, though."

                $ show_character("mona", "happy", modifier="bruised")
                mona "I knew you were stubborn."
                mona "I'm pretty incredible."

            $ show_character("ellie")
            ellie "Mona, I'm serious."

            $ mona_romance += 3

            $ show_character("mona", "happy", modifier="bruised")
            mona "I know."

            $ show_character("mona", "sad", modifier="bruised")
            mona "I've dreamed about what it would be like to kiss you again..."

            $ hide_character()
            "Her voice is so low you barely hear her."

            $ show_character("ellie")
            ellie "Oh, yeah...?"
            
            $ hide_character()
            "You cover her hand with yours."

            pause 0.5
            show new_york_view_ellie_animation
            pause 2.0
            scene new york view rail mona ellie
            hide new_york_view_ellie_animation

            "You keep moving closer and closer, as if a magnet is pulling you her."

            $ hide_character()
            "The door to the roof slams open and you jump apart, both of you avoiding the other's gaze!"

            play music "audio/TPA/default chill.mp3"

            hide new_york_view_ellie_animation
            scene new york view rail empty

            jump ch3_scn2_jones_interruption
        
        "Been trying to move on.":
            $ ch3_roof_romance = False

            ellie "It's been 10 years, Mona. Things change. {i}I{/i} have changed."
            ellie "Maybe you should move on too."
            if ch2_mona_diamond_scene_casual_fun:
                $ show_character("mona", "happy", "bruised")
                mona "Yeah, yeah, I remember your whole spiel about 'casual fun'."
                mona "How much casual fun have you had?"

                $ show_character("ellie")
                ellie "That's none of your business."

                $ hide_character()
                "The door to the roof slams open and you jump apart, both of you avoiding the other's gaze!"

            elif ch2_mona_diamond_scene_someone_else:
                $ show_character("mona", modifier="bruised")
                if ch2_ellie_flirt_with_ingrid_in_front_of_mona:
                    mona "Then why am I the one here instead of her?"

                else:
                    mona "You're really going to keep on pretending you're not into me?"
                    mona "How delusional are you?"

                $ show_character("ellie")
                ellie "That's none of your business."

                $ hide_character()
                "The door to the roof slams open and you jump apart, both of you avoiding the other's gaze!"

            elif ch2_mona_diamond_scene_only_one:
                $ mona_rejected = True
                $ mona_relationship -= 20
                $ mona_romance -= 100
                $ mona_romance_old = mona_romance
                $ show_character("mona", "angry", "bruised")
                mona "So the whole thing about not being able to forget me was what?"
                mona "You don't get to jerk me around, [Ellie] [Wheeler]."

                if ch2_string_logan_along:
                    mona "I shouldn't even be surprised anymore."
                    mona "You're right, you've changed. You're more manipulative now."

                $ show_character("ellie", "angry")
                ellie "I am not--"

                $ hide_character()
                "The door to the roof slams open and you jump apart, both of you avoiding the other's gaze!"
            
            else:
                $ show_character("mona", modifier="bruised")
                mona "Just like I asked you to..."

                $ hide_character()
                "You're both silent for a beat, watching the busy streets of the city from above."

                $ show_character("ellie")
                ellie "What did you think it was going to be like? Seeing me again?"

                $ show_character("mona", "happy", modifier="bruised")
                mona "Honestly? I thought you'd be arresting me."

                $ show_character("ellie", "happy")
                ellie "Didn't think I'd be breaking you out of jail?"

                $ hide_character()
                "She leans towards you."

                $ show_character("mona", "happy", modifier="bruised")
                mona "Please. There was bureaucracy involved, you didn't break me out of anything."

                $ show_character("ellie", "happy")
                ellie "Didn't I?"

                $ hide_character()
                "The door to the roof slams open and you jump apart."

            scene new york view rail empty
            jump ch3_scn2_jones_interruption

label ch3_mission_debrief_ingrid:
    $ ch3_roof_mona = False
    $ ch3_roof_ingrid = True

    $ hide_character
    scene new york view rail empty
    "Ingrid shuffles awkwardly on her feet, and you can tell she's avoiding your gaze."

    $ show_character("ellie")
    ellie "(She must feel bad about the whole thing.)" # yeah right

    $ hide_character()
    "You turn your back to her and she heaves a sigh."

    $ show_character("ingrid", "sad")
    ingrid "[Ellie]... Can we talk?"

    $ show_character("ellie")
    ellie "That depends. Are you going to yell at me again?"

    $ show_character("ingrid")
    ingrid "I {i}was{/i} going to, yes."

    $ show_character("ellie", "angry")
    ellie "Then no."
    $ show_character("ellie")
    ellie "I need a minute. Alone."

    $ hide_character()
    "She crosses over to you, propping her hands on the rail."
    
    scene new york view rail ingrid with dissolve

    $ show_character("ellie", "angry")
    ellie "I said {i}alone{/i}."

    $ show_character("ingrid", "angry")
    ingrid "I know what you said! Damn it, [Ellie]!"
    ingrid "Can't you just--"

    $ hide_character()
    "Ingrid hesitates, deflating a little. She grips the rail hard." # hesitation was a tell on the lie detector game

    $ show_character("ingrid", "sad")
    ingrid "Please... Just let me be here."
    ingrid "I let you go on your own and you could've died. I'm sorry. I'm so, so sorry, [Ellie]..."
    ingrid "Please don't make me go."

    $ show_character("ellie")
    menu:
        ellie "(She blames herself...)"

        "{image=heart_ingrid} Take her hand.":
            $ ch3_roof_romance = True

            ellie "Hey..."

            $ hide_character()
            "You cover her hand with yours."

            pause 0.5
            show new_york_view_ellie_animation
            pause 2.0
            scene new york view rail ingrid ellie
            hide new_york_view_ellie_animation

            $ ingrid_romance += 1
            $ show_character("ingrid", "sad")
            ingrid "I heard the shot--"

            if ch2_disable_comms:
                ingrid "I didn't know if you were alive or dead--"
            elif ch3_asked_for_backup:
                ingrid "If I had been faster--"
            else:
                ingrid "I shouldn't have let you out of my sight--"

            $ hide_character()
            "You squeeze her hand."

            $ show_character("ellie")
            ellie "You can't get rid of me that easily."

            $ hide_character()
            "Ingrid looks at you intently, like she's deciding whether or not to say what's on her mind."

            "Her eyes soften and she opens her mouth to speak..."

            "... The door to the roof slams open and you jump apart, both of you avoiding the other's gaze!"

            play music "audio/TPA/default chill.mp3"

            scene new york view rail empty

            jump ch3_scn2_jones_interruption

        "Reassure her.":
            ellie "It's not your fault."
            ellie "Colt had it planned from the moment he recognized me. He would have gone after me either way."

            $ show_character("ingrid")
            ingrid "What if he didn't?"
            ingrid "Would {i}you{/i} have gone after him?"

            $ show_character("ellie")
            menu:
                ellie "I..."

                "Would.":
                    $ ch3_roof_ingrid_would = True
                    $ hide_character()
                    "Ingrid doesn't say anything, but you can tell by her sharp inhale that she's trying not to yell at you again."

                    $ show_character("ellie", "surprised")
                    ellie "Did you want me to lie to you?"

                    $ ingrid_relationship -= 2
                    $ show_character("ingrid")
                    ingrid "... When it's about you being reckless? Yes."

                "Wouldn't.":
                    ellie "It would have blown my cover. No chance in Hell."
                    
                    $ ingrid_relationship += 2
                    $ show_character("ingrid")
                    ingrid "Good."

            $ hide_character()
            "The door to the roof slams open and you both turn towards it."

            play music "audio/TPA/default chill.mp3"

            jump ch3_scn2_jones_interruption

        "Berate her.":
            $ show_character("ellie", "angry")
            ellie "Don't pull that bullshit on me!"

            if ch3_shot_by_colt:
                ellie "You're not the one who got shot! This is not your pity party."
            else:
                ellie "You're not the one who almost got shot! This is not your pity party."

            $ hide_character()
            "Ingrid jerks away from the rail."

            scene new york view rail empty

            $ ingrid_relationship -= 2
            $ show_character("ingrid", "angry")
            if ch3_asked_for_backup:
                ingrid "I was there too, asshole! We {i}both{/i} almost got shot!"
                ingrid "But go off, keep being a self-centered prick!"

            elif ch2_disable_comms:
                ingrid "Yeah, and whose fault was that? You disabled your comms!"
                ingrid "What was I supposed to do?!"

            else: # comms are up but didn't ask for backup
                ingrid "Really!? Can you get your head out of your ass for one second?"

            $ hide_character()
            play sound "audio/SFX/sfx punch.mp3"

            "You watch as she punches the metal rail in anger."
            "Ingrid brushes some stray hairs out of her face, all fight seemingly gone out of her system."

            $ show_character("ellie")
            ellie "Feel better?"

            $ hide_character()
            "She glares at you."

            $ ingrid_relationship += 4
            $ show_character("ingrid")
            ingrid "... Yes."

            $ hide_character()
            "The door to the roof slams open and you both turn towards it."

            play music "audio/TPA/default chill.mp3"

            jump ch3_scn2_jones_interruption

            scene new york view rail empty
            pass

label ch3_scn2_jones_interruption:
    $ show_character("jones", "surprised")
    jones "There you are!"
    jones "Am I interrupting something?"

    if ch3_roof_romance:
        if ch3_roof_ingrid:
            $ show_character("ingrid", "surprised")
            ingrid "Of course not! Nope! Nada!"
            ingrid "I should-- I have-- I forgot something downstairs!"

            $ hide_character()
            "Ingrid quickly disappears down the stairs."

            $ show_character("jones")
            jones "... Right."

        else:
            $ show_character("mona")
            mona "Yes. Leave."

            $ show_character("ellie", "surprised")
            ellie "Mona!"

            $ hide_character()
            "She snorts at your exhasperation."

            $ show_character("ellie", "surprised")
            ellie "She's kidding! Do you need something, Agent [Jones]?"

            $ show_character("jones")
            jones "Just wanted to see how you were holding up."

            $ hide_character()
            "[AgentJones] pointedly looks at Mona."
            "Mona rolls her eyes but makes her way to the stairs, leaving you alone with your mentor."

    elif mona_rejected:
        $ show_character("mona", "angry")
        mona "She's all yours."

        $ hide_character()
        "Mona storms out."

    else:
        if ch3_roof_ingrid:
            $ show_character("ingrid")
            ingrid "I was just on my way out."

            $ hide_character()
            "Ingrid makes her way to the stairs, leaving you alone with your mentor."

        else:
            $ show_character("mona")
            mona "I'll leave you with your goody-two-shoes business."

            $ hide_character()
            "Mona makes her way to the stairs, leaving you alone with your mentor."

    $ show_character("jones")
    jones "So... How are you holding up, kid?"

    $ show_character("ellie")
    menu:
        ellie "I'm..."

        "Okay.":
            if ch3_shot_by_colt:
                ellie "Bullet hole notwithstanding."
            else:
                ellie "Really. I'm fine."
        "Going to be okay.":
            ellie "It was tense, not going to lie."
            ellie "These things don't happen in training."
        "Sick of talking about this.":
            $ show_character("ellie", "angry")
            ellie "Can everyone stop fussing over me for five minutes?"

            $ show_character("jones", "happy")
            jones "The bastards! How dare they care about you!"
            $ show_character("jones")
            jones "Listen, kid..."

    $ show_character("jones")
    jones "Missions go sideways all the time."
    jones "You know, my first mission with [AgentGrey] went all kinds of wrong."
    jones "We had a shoot out too, funny enough."
    jones "My point is, these things happen. There's no blueprint for this."

    $ show_character("ellie", "surprised")
    ellie "Actually... There might be."
    ellie "I need to talk to Colt. Now."

    $ hide_character()
    jump ch3_end_stats

label ch3_end_stats:
    scene black with fade
    pause 1.0

    $ center_voice = "CHAPTER STATS"

    if ch3_shot_by_colt:
        end_stats "Colt shot you when you tried to disarm him!"
    else:
        end_stats "You disarmed Colt without getting shot."

    end_stats "You found out Colt was the one that called GAIA about the Jackals."

    end_stats "Halo AI went rogue and drove you straight to Logan!"

    if ch1_arrest_logan:
        end_stats "You tried to arrest Logan but he got away."

    elif ch1_talk_logan_out_of_it:
        end_stats "You tried to convince Logan to come with you but he got away."

    else:
        end_stats "The AI helped Logan get away!"

    if ch3_roof_mona:
        end_stats "Mona followed you to the roof to check on you."
    else:
        end_stats "Ingrid followed you to the roof to check on you."

    if ch3_roof_romance:
        end_stats "The two of you shared a moment alone."

    elif mona_rejected:
        end_stats "You didn't reciprocate Mona's feelings."

    elif ch3_roof_ingrid_would:
        end_stats "You told Ingrid you would have put yourself in harm's way anyway."
    
    end_stats "Agent [Jones] retrieved a flashdrive."

    end_stats "ALLIES\nIngrid ... Alive & Recruited\nMona ... Alive & Recruited\nColt ... Alive\nLogan ... Alive"

    end_stats "POINTS\n{color=[red]}SUAVE{/color} [suave_points] out of [maximum_suave_points]\n{color=[blue]}SERIOUS{/color} [serious_points] out of [maximum_serious_points]"

    $ center_voice = "TUTORIAL"

    jump end_of_chapter
    #jump end_of_demo