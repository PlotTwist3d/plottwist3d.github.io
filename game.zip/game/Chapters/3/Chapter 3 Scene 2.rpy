label ch3_scn2_prototype:
    $ playable_character = "ELLIE"
    $ playing_as = capsEllie

    $ hide_character()

    play music "audio/TPA/default chill.mp3"
    scene auto show prototype at center with fade
    
    tutorial "Now playing as [Ellie] [Wheeler]."

    "You walk over to the car. You circle around it, taking in all the details."

    $ show_character("ellie")
    ellie "What can you tell me about this prototype?"

    $ show_character("colt")
    colt "It's our most recent addition to the luxury line."
    colt "Eletric. Automatic. Halo AI Assistant compatible."

    $ show_character("ellie")
    menu:
        ellie "It sounds..."

        "Great.":
            $ show_character("colt")
            colt "Does it? Does it really?"
            $ colt_relationship -= 2
            colt "It's like you're not even driving it, with the amount of add-ons this thing has."

            $ show_character("ellie", "surprised")
            ellie "If you don't like it why did you make this car?"

        "Terrible.":
            ellie "Automatic? Eletric? AI?"
            ellie "Do you even like any of that?"
            
            $ colt_relationship += 2

    $ maximum_suave_points += 1
        
    $ show_character("colt")
    colt "It's not a matter of personal taste."
    colt "We have to produce cars that will sell."
    colt "Not my fault the general public can't appreciate an actual good car."

    $ show_character("ellie")
    menu:
        ellie "A good car?"

        "Should you really be bad-mouthing your customers?":
            $ hide_character()
            "Colt shrugs."

            $ show_character("colt", "happy")
            colt "As long as it isn't to their faces."
        
        "That's why your designs are inspired by older models?":
            ellie "First the bike, now this one that looks suspiciously like your father's..."
            $ suave_points += 1
            
            $ show_character("colt", "happy")
            colt "Think they'll get the hint?"

            $ show_character("ellie", "happy")
            ellie "Doubt it."

    $ show_character("colt")
    colt "I could go on and go on all the marketing points of this car. Bore you to death, really."

    $ hide_character()
    "He gives you a mischievious smile."

    $ show_character("colt", "happy")
    colt "Or we could talk about the fun stuff."
    colt "And give us a chance to catch up. It's been what, 10 years?"

    if colt_romance >= 2 or ellie_prom=="Colt":
        colt "I want to know all about you."

    $ show_character("ellie")
    ellie "(This could give me some more information on the car.)"
    ellie "(And on Colt.)"
    $ hide_character()

    $ middle = False
    $ bottom = True
    $ regular = False
    $ timeout_label = None

    $ colt_mood = "neutral"
    show big colt with dissolve

    menu:
        with dis
        b "Colt, let's..."

        "Do it.":
            hide big colt
            $ colt_mood = "happy"
            show big colt
            pause 1.5
            hide big colt with dissolve
            $ middle = False
            $ bottom = False
            $ regular = True

            jump ch3_colt_diamond_scene

        "Not.":
            $ middle = False
            $ bottom = False
            $ regular = True
            hide big colt with dissolve

            $ show_character("ellie")
            ellie "This isn't the time, Colt."
            ellie "Just tell me what I need to know about this prototype."

            $ show_character("colt")
            colt "Fine."

            $ hide_character()
            "He produces a key from his pocket and unlocks the car, motioning for you to get inside."
            "You hop in to the driver's side."

            scene auto show inside prototype at center with fade
            
            $ show_character("colt")
            colt "Really?"

            $ show_character("ellie", "happy")
            ellie "The salesman goes in the passenger's seat."

            $ hide_character()
            "Colt rolls his eyes but gets in the car with you."

            if ch3_shot_by_colt:
                $ show_character("colt")
                colt "You better not leave blood all over my precious seats."

                $ show_character("ellie")
                ellie "Should have thought of that before you shot me."

            $ show_character("colt")
            colt "Whatever."
            
            $ hide_character()
            "He points to a series of buttons as he explains."

            $ show_character("colt")
            colt "This one starts the car."

            $ show_character("ellie")
            ellie "Doesn't it need the key?"

            $ show_character("colt")
            colt "Not if the AI is configured with the owner's biometrics."

            $ hide_character()
            play sound "audio/SFX/sfx car startup.mp3"
            "He presses the button and the engire roars to life."

            $ show_character("colt")
            colt "It's connected to my account. Anyway, moving on."
            colt "This one turns autopilot on and off."
            colt "That one overrides AI commands. For the sane people out there that don't want AI to take over the world."
            colt "And that one--"
            
            jump ch3_jackals_chase

label ch3_colt_diamond_scene:
    $ ch3_colt_scene = True
    play music "audio/TPA/default chill.mp3" fadein 0.5

    $ show_character("colt", "happy")
    colt "Let me unlock the car."
    
    $ hide_character()
    "He produces a key from his pocket and unlocks the car, motioning for you to get inside."
    "You hop in to the driver's side."
    
    #scene auto show no prototype at center with fade
    scene auto show inside prototype at center with fade

    $ show_character("colt")
    colt "Really?"

    $ show_character("ellie", "happy")
    ellie "The salesman goes in the passenger's seat."

    $ hide_character()
    "Colt rolls his eyes but gets in the car with you."

    if ch3_shot_by_colt:
        $ show_character("colt")
        colt "You better not leave blood all over my precious seats."

        $ show_character("ellie")
        ellie "Should have thought of that before you shot me."

    $ show_character("colt")
    colt "Whatever."

    $ show_character("colt", "happy")
    colt "So... A secret agent, huh?"
    colt "How do you even become one?"

    $ show_character("ellie")
    menu:
        ellie "I'd tell you..."

        "But then I'd have to kill you.":

            $ show_character("colt", "happy")
            colt "Hey now, aren't we past the killing each other phase by now?"
            colt "It's been like 15 minutes, give it a rest."

            $ show_character("ellie")
            ellie "Focus."
        
        "{image=heart_colt} But I like to keep you guessing.":
            $ show_character("ellie", "happy")
            ellie "Can't give all my secrets away."
            ellie "My mysteriousness is my best quality."

            $ colt_romance += 1
            $ show_character("colt", "happy")
            colt "Funny, it's my best quality too."

            $ show_character("ellie")
            ellie "Speaking of mysterious--"

            $ hide_character()
            "You gesture vaguely at the car's dashboard."

    $ show_character("colt")
    colt "Right."
    colt "Well, this button starts the car. It has a biometric sensor, so if you have it integrated with Halo AI it will let you drive without a key."
    colt "It also won't stop the car unless it reads your biometrics again."

    $ hide_character()
    "He presses the button and the engine roars to life."
    play sound "audio/SFX/sfx car startup.mp3"

    $ show_character("colt", "happy")
    colt "You can also unlock the doors with my biometrics but I like to do it the old fashioned way."

    $ show_character("ellie", "surprised")
    ellie "(So {i}this{/i} is the actual reason the Jackals need a hacker.)"

    $ hide_character()
    "Colt watches you expectantly."
    
    $ show_character("ellie")
    menu:
        ellie "Tell me about yourself."

        "Where do you live?": # colt_relationship--
            $ show_character("colt", "happy")
            colt "Damn, what are you? A cop?"

            $ show_character("ellie")
            ellie "Clearly. Now answer me."

            $ colt_relationship -= 2
            $ show_character("colt")
            colt "I'll have to plead the fifth on that one."
            colt "I'm a public figure now. I don't just give my address away."

            $ show_character("ellie")
            ellie "So, not that different from when you were a criminal."

            $ show_character("colt", "happy")
            colt "With better insurance, though."

        "{image=heart_colt} Are you seeing anyone?":
            $ show_character("colt", "happy")
            colt "Subtle, [Ellie]."

            $ show_character("ellie", "happy")
            ellie "Never heard of her, what's she like?"

            $ hide_character()
            "Colt shakes his head disapprovingly but you catch a flicker of amusement on his face."

            $ colt_romance += 1
            
            $ show_character("colt")
            colt "I'm married to my job."

            $ show_character("ellie", "happy")
            ellie "You're full of it, Colt Kaneko."

        "About Halo.": # colt_relationship++
            $ colt_relationship += 2
            $ show_character("colt", "happy")
            colt "I don't want to brag but... I worked so hard to get here, you know?"
            $ show_character("colt")
            colt "It started small, just one garage out here in New York."
            colt "Then I caught a lucky break with some investors and my company took off."
            $ show_character("colt", "happy")
            colt "Not even my Pops would think I'd be this successful."

            $ show_character("ellie")
            ellie "Seems like you really did good for yourself."

            $ show_character("colt")
            colt "I did."
            colt "And you don't seem to be doing half-bad either."

            if ch3_shot_by_colt:
                colt "Bullet hole aside, that is."

    $ show_character("colt", "happy")
    colt "I still can't believe you're here."

    if ellie_prom == "Colt":
        colt "And your partner seems familiar too."
    colt "What a small world..."

    $ show_character("ellie")
    menu:
        ellie "So small..."

        "{image=heart_colt} That I found you again.":
            
            $ hide_character()
            "You're both silent for a beat, just looking at each other."

            $ show_character("colt")
            colt "I'm really glad you did."

            $ show_character("ellie")
            ellie "Me too."

        "That I can't seem to get away from you.":
            pass

    $ show_character("ellie")
    ellie "Okay, focus. What else do these buttons do?"

    $ show_character("colt")
    colt "This one turns autopilot on and off."
    colt "You need to press it {color=[highlight]}twice{/color} for it to disable autopilot."
    colt "That one overrides AI commands. For the sane people out there that don't want AI to take over the world."
    colt "You need to say a specific passphrase, otherwise it won't disable the AI. We needed to put in extra security because of regulations."

    $ show_character("ellie")
    ellie "What's the passphrase?"

    $ show_character("colt", "happy")
    colt "It's elementary, my dear Watson."

    $ show_character("ellie", "surprised")
    ellie "Is that the phrase or are you just messing with me?"

    $ hide_character()
    "Colt snorts and points to another button."

    $ show_character("colt", "happy")
    colt "And this one--"

    jump ch3_jackals_chase

label ch3_jackals_chase:

    $ hide_character()
    scene auto show inside prototype with hpunch
    pause 0.5

    "The ground shakes as the wall comes crashing down!"

    play sound "audio/SFX/sfx car drive.mp3"

    "The prototype car starts driving itself through the hole in the wall!"

    play music "audio/ROD/action adrenaline.mp3"

    $ mission_required_value = 2
    $ mission_current_value = 0
    $ current_mission_complete = False
    $ achievement_success_title = None
    $ achievement_success_text = None
    $ achievement_failure_title = None
    $ achievement_failure_text = None

    scene black with fade
    show driving bg animation
    show car driving animation

    $ show_character("colt", "surprised")
    colt "[Ellie_nickname]! Stop the car!"

    $ show_character("ellie", "surprised")
    ellie "I'm trying!"

    $ hide_character()
    
    $ selected_item = None
    $ item1 = "pedal gas"
    $ item2 = "steering straight"
    $ item3 = "pedal brake"

    $ item1_bubble = "neutral"
    $ item2_bubble = "neutral"
    $ item3_bubble = "neutral"

    $ item1_text = "Step on the gas!"
    $ item2_text = "Grip the steering wheel!"
    $ item3_text = "Slow down!"

    $ item1_jump = "ch3_jackals_chase_no_timeout"
    $ item2_jump = "ch3_jackals_chase_no_timeout"
    $ item3_jump = "ch3_jackals_chase_no_timeout"

    $ regular = False
    $ middle = False
    $ timeout_label = "ch3_jackals_chase_timeout"

    call screen item_choice("Stop that car!", confirm_selection=False)

label ch3_jackals_chase_timeout:
    $ regular = True
    $ selected_item = "choice2"
    
    jump ch3_jackals_chase_no_timeout

label ch3_jackals_chase_no_timeout:
    $ regular = True
    if selected_item != "choice3":
        if selected_item == "choice1":
            "You press down on a pedal, sending the car forward with a jolt!" 

        else: # incorrect
            "You grip the steering wheel tight, bracing for impact..."
            "And the car keeps gaining speed!"

        $ show_character("colt", "surprised")
        colt "WHAT ARE YOU DOING?!"

        $ show_character("ellie", "surprised")
        ellie "I panicked!"

        $ hide_character()
        "You quickly press down on the brakes..."
        "But nothing happens!"

        $ show_character("ellie", "surprised")
        ellie "It's not working!"

        $ show_character("colt", "surprised")
        colt "Damn it! It must be in autopilot!"

    else:
        "You quickly press down on the brakes..."
        "The car slows down the tiniest bit before accelerating again!"
        $ mission_current_value += 1
        $ show_point_gained("+MISSION")

        $ show_character("ellie", "surprised")
        ellie "Colt, a little help!?"

        $ show_character("colt", "surprised")
        colt "It must be in autopilot!"

    $ center_voice = "HALO AI"
    $ timeout_label = None
    $ show_character("ellie", "surprised")
    menu:
        ellie "(I should...)"
        
        "Press the autopilot button!" (hidden=ch3_colt_scene):
            $ hide_character()
            "You quickly tap the autopilot button."
            "... Nothing happens."

            "You keep tapping the button in a panic."

            $ show_character("colt", "surprised")
            colt "Stop! You're going to break it!"

            $ hide_character()
            "He slaps your hand away and taps the button twice in quick succession."
            
            $ hide_character()
            halo_ai "Welcome, Colt! Disabling autopilot..."

        "Press the autopilot button twice!" (hidden=not ch3_colt_scene):
            $ hide_character()
            "You remember Colt's explanation about the autopilot and quickly tap the button twice."
            $ show_point_gained("++MISSION")
            $ mission_current_value += 2

            $ hide_character()
            halo_ai "Welcome, Colt! Disabling autopilot..."
        
        "Tell the AI to disable autopilot!" (hidden=ch3_colt_scene):
            ellie "Huh, AI? Can you disable autopilot?"

            $ show_character("colt", "surprised")
            colt "Seriously?"
            colt "You either click the command button or use the prompt phrase, it's not supposed to just--"

            $ show_character("ellie", "angry")
            ellie "Click the damn button!"

            $ hide_character()
            "Colt presses the autopilot button twice in rapid succession."

            $ hide_character()
            halo_ai "Welcome, Colt! Disabling autopilot..."

            $ show_point_gained("+MISSION")
            $ mission_current_value += 1
            
        "Tell Colt to disable autopilot!":
            ellie "Do something! It's your car!"

            $ colt_relationship -= 2

            $ show_character("colt", "surprised")
            colt "I'm trying!"

            $ hide_character()
            "Colt presses the autopilot button twice in rapid succession."

            $ hide_character()
            halo_ai "Welcome, Colt! Disabling autopilot..."

            $ show_point_gained("+MISSION")
            $ mission_current_value += 1

    $ hide_character()
    halo_ai_red "Error. User unrecognized. Please provide passphrase."

    $ show_character("colt")
    colt "The passphrase is: it's elementary, my dear Watson."

    $ hide_character()
    halo_ai_red "Error. User unrecognized. Cancelling last command."
    
    $ show_character("colt", "angry")
    colt "{i}Unrecognized{/i}?! I own you!"

    $ hide_character()
    "The car keeps driving by itself. You notice how the road signs show up on the dashboard, the AI seemingly managing to not break any rules."

    $ show_character("ellie", "surprised")
    ellie "(Great. We might die in a horrible AI car accident but we won't be getting any speeding tickets.)"
    
    jump ch3_jackals_logan

label ch3_jackals_logan:
    $ hide_character()
    "The car starts slowing to a stop as it takes a turn into a dark alley."
    play sound "audio/SFX/sfx car stop squeal.mp3"
    hide driving bg animation
    hide car driving animation
    scene bar alley
    show fancy car overlay

    "A figure stands before you, and you recognize him immediately."

    $ show_character("logan")
    logan "..."

    $ hide_character()
    "You hear a click as the doors unlock. You and Colt share a look."

    $ show_character("ellie", "surprised")
    ellie "Logan doesn't seem to have seen us yet, we can--"

    $ show_character("colt", "angry")
    colt "Son of a--"

    $ hide_character()
    "Colt angrily storms out of the car, slamming the door shut on his way out."
    "Logan's eyes widen in surprise."

    $ show_character("colt", "angry")
    colt "{i}Of course{/i} you numbskull would be in on it!"
    
    $ show_character("logan", "surprised")
    logan "Colt?!"

    $ hide_character()
    "Colt wastes no time getting in Logan's face. You quickly slip out of the car."

    hide fancy car overlay

    $ show_character("ellie", "surprised")
    ellie "Colt! Logan! Stand down, both of you!"
            
    $ show_character("logan", "surprised")
    logan "[Ellie]?!"

    if ellie_prom == "Logan":
        $ hide_character()
        "His look softens as he takes you in."

    $ show_character("logan", "surprised")
    logan "What-- What are you doing here?"

    if ch3_shot_by_colt:
        $ hide_character()
        "Logan's gaze catches on the wound on your shoulder."

        $ show_character("logan", "surprised")
        logan "What happened to you? Are you okay?"

        $ show_character("colt", "angry")
        colt "Don't change the subject."

    if ch1_arrest_logan:
        $ show_character("ellie")
        ellie "You're under arrest, Logan."

    elif ch1_talk_logan_out_of_it:
        $ show_character("ellie")
        ellie "I'm here to help you."

        $ colt_relationship -= 2
        $ show_character("colt", "angry")
        colt "Are you kidding me--"

        $ hide_character()
        "You shoot him a warning look. Colt quiets down, muttering something under his breath."

        $ show_character("ellie")
        ellie "You're in a bad situation, Logan... I can help you."
        $ logan_relationship += 4

        if ch2_string_logan_along:
            ellie "You know I can. This doesn't have to be this way..."

            $ hide_character()
            "Logan stares at you, his resolve wavering..."

            $ show_character("colt", "angry")
            colt "You're giving him another chance? To this ungrateful bastard?"
    
    else:
        $ show_character("colt", "angry")
        colt "I {i}knew{/i} it was you!"

    $ show_character("logan", "surprised")
    logan "What are you talking about?"

    $ show_character("colt", "angry")
    colt "After everything my father did for you, you go and steal from me?"

    $ show_character("logan", "angry")
    logan "Because you're a real saint, aren't you {i}Junior{/i}?"

    $ hide_character()
    "Colt and Logan glare at each other. You sense they are about to come to blows."

    $ maximum_serious_points += 1

    $ show_character("ellie", "surprised")
    menu:
        ellie "(I should...)"

        "Side with Logan!":
            ellie "Colt, back off."
            
            $ colt_relationship -= 2
            $ show_character("colt", "angry")
            colt "And let him get away?"

            $ show_character("ellie", "angry")
            ellie "Do I need to arrest you for brawling too, Colt?"

            $ hide_character()
            "He glares at you for a minute, but backs off."

            $ hide_character()
            "Logan tips his head at you in silent acknowledgement."
            $ logan_relationship += 2
            $ show_character("logan")
            logan "..."

        "Side with Colt!":

            if ch1_arrest_logan:
                $ hide_character()
                "You step between them, fully intent on aprehending Logan yourself."
                $ show_character("colt")
                colt "..."
                $ colt_relationship += 2
                "Colt backs off."
                "You step towards Logan."

                $ show_character("ellie")
                ellie "You're coming with us. I'm taking you in, Logan."


            elif ch1_talk_logan_out_of_it:
                $ hide_character()
                "You step between them, fully intent on turning Logan against the Jackals."

                $ show_character("ellie")
                ellie "We can protect you from them. Please, Logan... Just come with us."

                $ colt_relationship += 2

                $ show_character("colt")
                colt "You're lucky she's more understanding than me."

            $ serious_points += 1
            
    $ hide_character()
    "He looks between you and Colt, his jaw set. He seems to be weighting his options."

    play sound "audio/SFX/sfx car startup.mp3"
    "You hear the car's engine rumble behind you."
    "Logan shifts his gaze to the car and you can see the moment he makes up his mind."

    play sound "audio/SFX/sfx car drive.mp3"
    "The car comes rushing in! You and Colt barely have time to dive out of the way!"

    if ch3_shot_by_colt:
        $ show_character("ellie", "surprised")
        ellie "{i}Ugh{/i}!"

        $ hide_character()
        "You land on your wounded shoulder, the pain shooting through you as the car opens its doors automatically."

    else:
        $ show_character("ellie", "surprised")
        ellie "{i}Ugh{/i}!"

        $ hide_character()
        "You land on your side, looking up at the car as opens its doors automatically."

    halo_ai_red "Torque! GO, GO, GO!"

    "Logan dives into the car, tires screeching as the car difts out of the alley!"

    $ show_character("colt", "surprised")
    colt "No!"

    $ hide_character()
    "You and Colt scramble to your feet, but Logan's long gone."

    stop sound
    scene black with fade
    pause 2.0

    jump ch3_mission_debrief