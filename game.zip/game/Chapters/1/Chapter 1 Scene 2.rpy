label ch1_scene2:

    scene prison security office at right with dissolve
    show screen location_title("los angeles text") with dissolve
    $ renpy.pause(2, hard=True)
    hide screen location_title with dissolve
    
    $ change_ellie_outfit("casual", ellie_default_outfit) # default casual outfit

    "After a 6-hour flight and a 40-minute drive, you arrive at the prison."
    "A correction's officer greets you as you arrive."

    $ show_character("officer", "happy")

    $ fake_identity_name = "Elena"
    $ fake_identify_surname = "Rhys"

    officer "Ms. [fake_identify_surname]! We talked on the phone, it's a pleasure to meet you."

    $ hide_character()
    "She motions for you to follow her."
    scene prison security office at right_to_mid

    $ show_character("officer", "neutral")
    officer "I apologize for the wait."
    officer "We had some problems with the inmate. She refused to see you, we had to drag her to the visiting room kicking and screaming."

    $ show_character("ellie", "surprised")
    ellie "Does that happen a lot?"

    $ show_character("officer")
    officer "With her? No."
    officer "She never has visits and refuses to see whoever insist on showing up."
    officer "We made it very clear to her this visit wasn't optional."

    $ hide_character()

    scene prison security office at mid_to_left
    pause 1.5
    scene prison interrogation room at center with dissolve

    "She ushers you through a heavy metal door."

    $ show_character("officer")
    officer "Press the red button beside the door to signal you're ready to leave."
    officer "I'll be waiting outside if you need me."

    $ show_character("ellie")

    menu:
        ellie "Thank you, officer."

        "I feel safe with you around.":
            $ show_character("officer", "happy")
            officer "It's no trouble, miss."
            officer "It's not everyday that we are visited by important people."
            $ suave_points += 1
            $ maximum_suave_points += 1
            $ show_character("officer")
            $ ch1_officer_suave_point = True
            officer "We take your safety very seriously."
        "I'm sure we will be fine.":
            $ show_character("officer")
            $ ch1_officer_suave_point = False
            officer "I wouldn't be so sure."
            officer "She is a dangerous woman. There's a reason she's in here."

    $ hide_character()
    "She gives you a curt nod before exiting the room, closing the door behind her."
    "You take a deep breath before facing the woman in front of you."

    $ center_voice = "???"
    qc "[Ellie_nickname]? [Ellie] [Wheeler]?"

    $ center_voice = "TUTORIAL"
    "You exhale slowly as your eyes meet."

    $ show_character("ellie")
    ellie "Hi, {color=[highlight]}Mona{/color}."

    $ hide_character()

    "Memories of you and Mona start rushing in."

    scene auto shop inside sepia at center with dissolve

    $ show_character("mona", modifier="young")
    mona "Where did you find this one, Logan?"

    $ show_character("ximena")
    ximena "Mona, will you stop teasing the poor girl?"

    $ show_character("mona", "happy", modifier="young")
    mona "Relax, I don't bite... Much."

    if not ellie_young_first_kiss:
        $ show_character("ellie")
        menu:
            ellie "(Mona was...)"

            "My first kiss.":
                $ ellie_young_first_kiss = "Mona"
                $ hide_character()
                scene underground rave sepia at left with dissolve
                $ show_character("logan", "happy", "young")
                logan "Mona's made a lot of girls fall in love with her here."

                $ show_character("toby", "surprised")
                toby "I don't think I've ever seen Mona look at anyone the way she's been looking at you tonight."
                $ show_character("mona", "angry", "young")
                mona "..."
                $ show_character("toby", "happy")
                toby "Man, she is {i}not{/i} happy about liking you."
                $ hide_character()

            "A menace.":
                $ hide_character()
                scene auto shop inside sepia at center with dissolve
                $ show_character("mona", "neutral", modifier="young")
                mona "You should watch your back around everyone here."
                mona "Especially me."
                $ hide_character()

    $ hide_character()
    scene prison interrogation room at center with dissolve

    "You take in the woman in front of you."

    #TODO Mona character customization

    $ bottom = True
    $ middle = False
    $ regular = False

    $ change_mona_outfit(0, 0, False) # prison outfit
    show big mona with dissolve
    menu:
        b "Long time no see."

        "Enjoying the consequences of your actions?":
            hide big mona with dissolve
            $ bottom = False
            $ middle = False
            $ regular = True
            
            $ show_character("mona", "neutral")
            mona "What, the free housing, clothing and food?"
            mona "Oh no, please stop this torture!"
            mona "I beg of you, no more!"

            $ show_character("ellie", "angry")
            ellie "Very funny."

            $ show_character("mona")
            mona "Not up for jokes? Ok, fine."
            #$ notify_relationship_point("+MONA")
            $ mona_relationship += 2
            mona "It sucks, I can't wait to be out of here."

        "You look well.":
            hide big mona with dissolve
            $ bottom = False
            $ middle = False
            $ regular = True
            
            if ch1_officer_suave_point:
                $ show_character("mona", "angry")
                #$ notify_relationship_point("-MONA")
                $ mona_relationship -= 2
                mona "Cut the crap, [Ellie_nickname]."

    $ show_character("mona")
    mona "What do you want?"

    $ hide_character()
    "The metal chair scraps against the floor as you pull it out to sit in front of her."
    "You glance at the cuffs on her wrists, noticing the fading lines of her sleeve tattoo."

    if ellie_young_tattoo:
        "You remember your own tattoo, that you got after watching Ximena do the one on Mona's back."
    
    elif ellie_tattoo_visible:
        "She notices your tattoo poking out of your sleeve and her lips twitch into a sly smirk."
        $ show_character("mona", "happy")
        mona "Still a naïve girl playing tough, hm?"
        $ hide_character()
        "You ignore her remark."

    $ show_character("ellie")
    ellie "I need your help."

    $ show_character("mona", "happy")
    mona "Clearly. I figured this wouldn't be a social call after 10 years of no contact."
    $ show_character("mona")
    mona "You're revving up the wrong engine, though. I don't do favors."
    mona "... Unless it benefits me."

    $ show_character("ellie")
    ellie "Or you could do it for old time's sake."

    $ hide_character()
    "She sneers."

    $ show_character("mona")
    mona "Don't count on it. I already took a bullet for you."

    $ show_character("ellie", "angry")
    ellie "Yeah. {i}After{/i} you almost killed me."

    $ show_character("mona")
    mona "I owe you nothing. I only look out for myself."

    $ show_character("ellie")
    ellie "That's not true."

    if not ellie_prom:
        $ hide_character()
        tutorial "The next choice will determine your past relationship with Mona."
        $ show_character("ellie")
        $ young_mona_outfit = "prom"
        menu:
            ellie "What about prom? You..."

            "{image=heart_mona} Sacrificed yourself for me.":
                $ ellie_prom = "Mona"
                $ my_notify_func("gui/notify.png", "A BAD GIRL ROMANCE", f"You went to prom with Mona!")
                $ hide_character()
                scene hallway fancy sepia at center with dissolve

                "You remember how {color=[highlight]}The Brotherhood{/color} - a crew of corrupt cops lead by your father's ex-partner, Det. Shaw - used you as bait to catch her."

                $ show_character("mona", "happy", modifier="young")
                mona "Pretty tempting bait if you ask me. I gotta respect the move."
                $ show_character("mona", "neutral", "young")
                mona "I'm gonna offer them a deal. I bet I know how to find what they're after."
                
                $ hide_character()
                "She was, of course, talking about helping The Brotherhood capture the rest of the Mercy Park Crew."

                $ show_character("mona", modifier="young")
                mona "If it's them or me, it's gonna be them."
                mona "Wait for them to take me. Then get downstairs."
                $ hide_character()
                scene prison interrogation room at center with dissolve

            "Helped us escape.":
                $ ellie_prom = "Colt"
                if not ellie_young_first_kiss:
                    $ ellie_young_first_kiss = "Colt"
                $ show_character("ellie")
                ellie "Me and Colt. You helped us."
                $ my_notify_func("gui/notify.png", "A BAD BOY ROMANCE", f"You went to prom with Colt!")
    else:
        $ show_character("ellie")
        ellie "You helped Logan and I escape."

    $ show_character("mona")
    mona "I did that to save my own skin."

    if ellie_prom == "Mona":
        $ hide_character()
        "You think back to prom night."
        scene hotel suite sepia at left with dissolve

        $ young_mona_outfit = "prom"
        $ show_character("mona", modifier="young")
        mona "I think about you all the time. Worry about you... wonder what you're doing... want to tell you I love you--"
        $ hide_character()
        scene prison interrogation room at center with dissolve

        $ show_character("ellie")
        ellie "That's bull and you know it."
        menu:
            ellie "You loved me..."

            "And I loved you back.":
                $ ellie_prom_love = True
                $ hide_character()
                "She is silent for what feels like an eternity, refusing to meet your eyes."
                "Then she mutters so low you barely make out the words."
                $ show_character("mona", "sad")
                $ mona_relationship += 2
                mona "{i}I know.{/i}"

            "You can't pretend otherwise now.":
                $ ellie_prom_love = False

    $ show_character("mona")
    mona "You still haven't told me what you need from me."

    $ show_character("ellie")
    ellie "I need to find Logan."

    $ show_character("mona", "happy")
    mona "Well, I can tell you he isn't here."
    $ show_character("mona")
    mona "As far as I know, at least."

    $ show_character("ellie")
    ellie "But you {i}do{/i} know something?"

    $ hide_character()
    "She shrugs."

    $ show_character("mona", "happy")
    mona "Depends on what you have to offer."

    $ show_character("ellie")
    ellie "Fine. What's your price?"

    $ hide_character()
    "She leans towards you over the table, the chains on the cuffs rustling."

    $ show_character("mona", "happy")
    mona "Freedom."
    $ show_character("ellie")
    ellie "What makes you think I can get you out?"
    $ show_character("mona")
    mona "It's not everyone that manages to grab me for visitation."
    mona "The guards made it sound like you were important."

    if ch1_officer_suave_point:
        mona "Bat your pretty eyelashes at them and sneak me out."

label ch1_first_premium_choice_informant:

    $ hide_character()
    tutorial "This is your first point-required choice!"
    tutorial "SUAVE points allow you to recruit {color=[red]}informants{/color} and {color=[red]}influence{/color} other characters."

    if suave_points < 1:
        tutorial "You don't have enough SUAVE points. Because it's the first point-required choice we'll give you one for free."
        $ suave_points += 1
        tutorial "You're welcome."

    $ show_character("ellie")
    menu:
        ellie "..."

        "I can get you a conditional release." (suave=True, points=1, disabled=(suave_points < 1)):
            $ hide_character()
            "She narrows her eyes at you."
            $ show_character("mona")
            mona "And how would you do that?"

            $ show_character("ellie")

            jump ch1_mona_early_release

label ch1_mona_early_release:
    menu:
        ellie "..."

        "Just... Trust me.":
            ellie "I give you my word I'll get you out if you help me."

            $ show_character("mona")
            #$ notify_relationship_point("-MONA")
            mona "Words are meaningless. It's actions that count."
            $ mona_relationship -= 2
        
        "You said it yourself, I'm important.":
            $ show_character("mona", "surprised")
            mona "Not that I'm saying you aren't or whatever but... Why?"
            
            $ show_character("ellie", "happy")
            ellie "They might be under the impression I'm a part of the Cordonian royal family."

            $ show_character("mona")
            mona "How did you pull that off?"
            $ mona_relationship += 2
            #$ notify_relationship_point("+MONA")
            mona "Nevermind, I don't care."

        "By making you an informant.":
            $ show_character("mona", "angry")
            mona "You're asking me to be an official snitch?"

            $ show_character("ellie")
            ellie "I'm asking you to look after yourself."
            ellie "Besides, it's nothing you haven't done before. Switching sides."

            $ show_character("mona")
            mona "Fine. Make it happen."
    
    $ hide_character()
    "You pull out your phone and dial [AgentJones]'s number. Mona gives you an intrigued look."

    $ show_character("jones", "neutral", modifier="holo")
    jones_holo "[Wheeler]. You missed the morning check-in."

    $ show_character("ellie")
    ellie "I know, sorry."

    if jones_ellie_fav_child:
        ellie "I'm still your favorite mentee though, right?"

        $ show_character("jones", "happy", modifier="holo")
        jones_holo "Depends on why you're calling me right now."

    $ show_character("jones", modifier="holo")
    jones_holo "What's going on? Talk to me."

    $ show_character("ellie")
    ellie "I'm following up on a lead."
    ellie "I know someone who has information on the crew."

    $ hide_character()

    "You look at Mona."

    $ show_character("ellie")
    ellie "I need you to sign off on it so she can get released from prison."

    $ hide_character()
    "You hear a sigh from the other side of the line."

    $ show_character("jones", modifier="holo")
    jones_holo "I hope you know what you're doing."
    jones_holo "I'll see what I can do, but if anything goes wrong it's your ass on the line."

    $ show_character("ellie")
    ellie "I know. Thank you."
    #menu:
    #    ellie "..."
        
    #    "I know.":
    #        pass
    #    "What if Agent Gray signs up on it as well?" (serious=True, points=1, disabled=(serious_points < 1)):
    #        $ ch1_grey_sign_off = True
    #        $ show_character("jones", "happy", modifier="holo")
    #        jones_holo "Your ass would be significantly less on the line."
    #        $ show_character("jones", modifier="holo")
    #        $ my_notify_func("gui/achivement.png", "CAVALRY", "You got Agent Gray to back you up.")
    #        jones_holo "[grey_pronoun_she!c] might be convinced. I'll try."
    #        $ hide_character()
    #        tutorial "SERIOUS points unlock {color=[blue]}collectibles{/color} and {color=[blue]}leadership{/color} options."
    
    #$ show_character("ellie", "happy")
    #ellie "Thank you."

    $ hide_character()
    "As soon as you hang up, Mona let's out an impressed whistle."

    $ show_character("mona", "surprised")
    $ mona_relationship += 2
    mona "I heard you were a cop, but I didn't know you were some kind of big shot."

    $ show_character("ellie")
    ellie "I'm neither of these things."

    $ hide_character()
    "She gives you a skeptical look."

    $ show_character("ellie")
    ellie "I kept my word."
    ellie "Tell me what you know."

    $ show_character("mona")
    mona "Why Logan?"
    mona "Why not Colt?"

    $ hide_character()
    "You arch an eyebrow at her."

    $ show_character("mona", "happy")
    mona "Whatever. Logan it is."
    mona "He's running with a new crew."

    $ show_character("ellie")
    ellie "The Velvet Jackels."

    $ hide_character()
    "Mona studies your face silently for a minute. You fight the urge to squirm under her gaze."

    $ show_character("mona")
    mona "What are you going to do when you find him?"

    $ show_character("ellie")
    menu:
        ellie "I..."

        "Am going to arrest him.":
            $ ch1_arrest_logan = True
            $ show_character("mona", "neutral")
            $ mona_relationship += 2
            #$ notify_relationship_point("+MONA")
            mona "Well, at least you're honest."

        "Will try to talk him out of it.":
            $ ch1_talk_logan_out_of_it = True
            $ show_character("mona", "sad")
            mona "All this time and you still think you can change us."
            $ show_character("mona")
            mona "Don't take it too personally when you get disappointed again."

        "{image=heart_mona} Am more interested in what I could do with you.":
            if ch1_officer_suave_point:
                $ hide_character()
                "She rolls her eyes."

                $ show_character("mona")
                mona "I feel so special, it's not like you've flirted with everyone that crossed your path today."

                $ show_character("ellie", "surprised")
                ellie "I didn't!"

                $ show_character("mona")
                mona "Yeah? Tell that to the guard that brought you here."

                $ show_character("ellie", "surprised")
                ellie "It's called being polite!"
                ellie "Plus I had my cover to maintain!"
            
                $ show_character("mona")
                mona "You keep telling yourself that."
                mona "Whatever helps you sleep at night."

            else:
                if ellie_prom == "Mona":
                    $ show_character("mona", "happy")
                    mona "I think I got a pretty good idea of what you can do with me."

                else:
                    $ hide_character()
                    "Mona laughs."

                    $ show_character("mona", "happy")
                    mona "Sorry, Officer. I don't date cops."

                    $ show_character("ellie", "happy")
                    ellie "Then it's a good thing I'm not a cop."
                    ellie "Also, who said anything about dating?"                
                    ellie "We can still have some fun."

                    $ show_character("mona", "happy")
                    $ mona_romance += 1
                    mona "You couldn't handle me."                

            if ellie_prom == "Mona":
                $ hide_character()
                "You think back to prom night, and how the two of you layed in bed together after your first time."
                "When you lock eyes, you know she's thinking about it too."

                $ show_character("mona")
                #$ notify_relationship_point("+{image=heart_mona} MONA")
                $ mona_romance += 1
                #$ mona_relationship += 2
                mona "..."

    $ show_character("ellie")
    ellie "What else do you know about the Jackals?"

    $ show_character("mona")
    mona "They're ruthless."
    if ellie_valedictorian:
        $ dictorian = "valedictorian"
    else:
        $ dictorian = "salutorian"
    
    mona "You're in way over your head, Little Miss [dictorian!c]."

    $ show_character("ellie")

    menu:
        ellie "For someone who doesn't care you..."

        "{image=heart_mona} Sure pay a lot of attention to me.":
            if ellie_prom == "Mona":
                $ show_character("mona", "happy")
                mona "I did tell you you'd be hard to forget."
                
                $ show_character("ellie", "happy")
                ellie "Doesn't sound like you tried all that much."

                $ show_character("mona")
                $ mona_romance += 1
                mona "Maybe I didn't."

            else:
                $ show_character("mona")
                mona "I took a bullet for you. I need to how to collect on that debt at all times."
                mona "Never know when I might need it."

                $ show_character("ellie")
                ellie "Oh yeah?"
                ellie "What else do you expect to get from me?"

                $ show_character("mona", "happy")
                #$ notify_relationship_point("+{image=heart_mona} MONA")
                $ mona_romance += 1
                #$ mona_relationship += 2
                mona "Ask me again when we're out of here."

        "Kept tabs on everyone.":
            $ show_character("mona")
            mona "It's hard not to."
            mona "Don't know if you noticed but I don't have much to do here."
    
    $ show_character("ellie")
    ellie "What else do you know?"
    $ loop_question_option1 = False
    $ loop_question_option2 = False
    $ loop_question_option3 = False
    jump question_loop

label question_loop:
    $ show_character("ellie")

    if not (loop_question_option1 and loop_question_option2 and loop_question_option3):
        menu:
            ellie "Tell me about..."

            "Logan. Do you know where he is?" (hidden=loop_question_option1):
                $ loop_question_option1 = True
                
                $ show_character("mona", "happy")
                mona "I might."
                $ show_character("mona")
                mona "I'll take you there. Gotta have some leverage in case that phone call was fake."

                $ show_character("ellie")
                ellie "It wasn't."

                jump question_loop

            "The Velvet Jackals." (hidden=loop_question_option2):
                $ loop_question_option2 = True

                $ show_character("mona")
                mona "I've heard many versions of it but the gist is..."
                mona "They ran the scene here in L.A. after Mercy Park got taken down. With The Brotherhood gone as well they rose up real fast."
                mona "Some say they ran off the other crews. Killed them or payed them off. The police too."

                $ show_character("mona", "happy")
                mona "But not your dad."

                if ch1_talk_logan_out_of_it:
                    mona "Must be where you get your unwavering morals from."

                    $ show_character("ellie")
                    ellie "At least my moral compass doesn't spin like a roulette wheel."

                    $ show_character("mona", "happy")
                    mona "You trying to tell me something? Harsh."

                $ show_character("ellie", "surprised")
                ellie "(Good thing Dad got the hell out of here with that promotion.)"

                jump question_loop
            
            "Colt." (hidden=loop_question_option3):
                $ loop_question_option3 = True

                $ show_character("mona")
                mona "You really don't know?"

                $ show_character("ellie")
                ellie "I'm just asking to waste your time."
                $ show_character("ellie", "angry")
                ellie "Clearly I don't know."

                $ show_character("mona", "happy")
                mona "He was running his own crew."
                mona "Wanted to recruit me and all."

                $ show_character("ellie", "surprised")
                ellie "So he could have bust you out?"

                $ show_character("mona")
                mona "Could."
                mona "Would."
                mona "Didn't."

                $ show_character("mona")
                mona "Doesn't really matter."
                mona "I refused the offer anyway."

                $ show_character("ellie", "surprised")
                ellie "Why?"

                $ hide_character()
                "She shrugs nonchallantly."

                jump question_loop

    jump ch1_scene2_end_of_question_loop

label ch1_scene2_end_of_question_loop:
    $ show_character("ellie")
    ellie "What about--"

    $ show_character("mona", "surprised")
    mona "Geez, it's like I'm being interrogated all over again."
    $ show_character("mona")
    mona "I'll answer the rest of your annoying questions once I'm a free woman."

    $ show_character("ellie")
    ellie "... Fine."
    ellie "But just so you know, this is not you walking free."
    ellie "Think of it more like a very strict supervised release."

    $ show_character("mona", "happy")
    mona "What you're saying is that you're just a glorified babysitter."

    $ show_character("ellie")
    ellie "What I'm saying is that you'll have to earn your freedom."
    ellie "Help me find Logan and feed me information on the Jackals and you walk."
    ellie "Until then you only have limited mobility and full surveillance oversight."

    $ hide_character()
    "You pause to look at her in the eyes."

    $ show_character("ellie", "angry")
    ellie "Betray me and the prison I send you to will be one hundred times worse than this one."
    ellie "Understood?"
    
    $ hide_character()
    "She looks amused."

    $ show_character("mona", "happy")
    mona "Having trust issues? I know the feeling."

    if ch1_talk_logan_out_of_it:
        mona "Guess your moral compass isn't above using threats."

    $ show_character("mona")
    mona "But fine. Understood."

    $ show_character("ellie")
    ellie "Good."

    $ hide_character()
    "You stand up and make your way back to the heavy metal door."
    "You press the button beside it, just like the officer instructed you to."
    "You hear a buzz and the door unlocks."

    $ show_character("mona")
    mona "Hey, [Ellie_nickname]?"

    $ hide_character()
    "You turn your head to look at her."

    $ show_character("mona")
    if mona_flirt or ellie_prom == "Mona":
        mona "... It was good seeing you."
    
    mona "I do want to help, believe it or not."

    $ show_character("ellie")

    menu:
        ellie "..."

        "I don't believe you.": # +MONA
            $ show_character("mona", "happy")
            $ mona_relationship += 2
            #$ notify_relationship_point("+MONA")
            mona "Didn't expect you to."
            $ ch1_mona_liar = True

        "I don't care.": # -MONA
            $ show_character("mona")
            $ mona_relationship -= 2
            #$ notify_relationship_point("-MONA")
            mona "And I'm supposed to believe you came all this way for something you don't care about?"
            $ ch1_mona_dont_care = True

            $ hide_character()
            "You turn back to the door, ignoring her."

        "I know." (hidden=(mona_flirt or ellie_prom == 'Mona')): # NO CHANGE
            $ ch1_mona_i_know = True
            $ show_character("mona")
            mona "No, you don't."
            
            $ show_character("ellie")
            ellie "What, you think I wouldn't have done my homework before coming here?"
            ellie "You've been trying to get your sentence reduced, cutting deals left and right."
            ellie "You were always going to flip."

            $ show_character("ellie", "happy")
            ellie "As long as it benefits you, right?"

            $ hide_character()
            "She stares at you, her mouth agape like she wants to say something but the words are never spoken."

        "I trust you.": # NO CHANGE but affects something?
            $ show_character("mona")
            mona "Don't."
            
            $ show_character("ellie")
            ellie "You took a bullet for me. You had nothing to gain and everything to lose."
            ellie "I trust that you're still that person, deep down."
            ellie "Life hasn't been fair to you. You played the hand you were dealt. That doesn't make you evil."

            $ hide_character()
            "You don't see her flinch, but the sound of the metal of the cuffs rustling gives it away."

            $ ch1_mona_trusted = True

        "{image=heart_mona} It was good seeing you too." (hidden= not (mona_flirt or ellie_prom == 'Mona')): # + <3 MONA
            $ show_character("mona", "happy")
            $ mona_romance += 1
            mona "See you on the other side."

    $ show_character("ellie")
    ellie "I'll come pick you up."

    $ hide_character()
    "You walk out of there without looking back."

    jump ch1_scene2_after_visiting_mona

label ch1_scene2_after_visiting_mona:
    $ hide_character()
    scene black with dissolve
    pause 1.0

    scene hotel suite at center with dissolve

    "A short drive later, you walk into the safehouse you arranged for the time being."
    
    # play sound "phone notification" TODO

    $ my_notify_func("gui/achievement.png", "INCOMING CALL", "Ingrid Delaney")

    play sound "audio/SFX/sfx phone ring.mp3"
    
    "Your phone rings."

    jump ch1_scene2_ingrid

label ch1_scene2_ingrid:

    $ hide_character()
    "You answer the call."

    $ right_image = "gaia plane"
    scene hotel suite at center
    show split_screen at center with wipeleft

    $ show_character("ellie")
    ellie "Hey--"

    $ show_character("ingrid", "angry")
    ingrid "Don't you {i}hey{/i} me!"
    ingrid "We're supposed to be partners, what the Hell are you doing?!"

    $ show_character("ellie")
    menu:
        ellie "You..."

        "Are absolutely right.": 
            ellie "I should have talked to you first."
            ellie "I'm not going rogue or anything."
            $ ch1_not_going_rogue = True

        "Need to chill.":  # -INGRID
            $ show_character("ingrid", "angry")
            ingrid "I need to chill?! You need to chill!"
            $ ingrid_relationship -= 2
            ingrid "It's our first mission and you're already going rogue."

    $ show_character("ellie", "surprised")
    ellie "I promise I know what I'm doing."

    $ show_character("ingrid")
    ingrid "Do you?"
    ingrid "I talked to Agent [Jones], I know you picked up an informant. Who are they?"

    $ show_character("ellie")
    ellie "Just... Someone I used to know."

    menu:
        ellie "Look, Ingrid..."

        "You'll just have to trust me.":
            $ ch1_ingrid_truth = False

            $ show_character("ellie")
            ellie "I can't really explain but this is a calculated risk."
            ellie "She knows stuff and she might be the only one willing to talk to us."

            $ show_character("ingrid")
            ingrid "Fine. But let the record show I don't like this one bit."

            $ show_character("ellie")
            ellie "Noted."
        
        "I'll explain everything.":
            $ ch1_ingrid_truth = True
            ellie "Just... bear with me, ok?"

            $ hide_character()

            "You recount to Ingrid all that happened during your senior year of high school."
            "You recount to Ingrid all that happened during your senior year of high school."
            "You tell her about the Mercy Park Crew, the heists you pulled with them, The Brotherhood..."
            "All the details down to how you stopped them for good."

            $ show_character("ingrid", "surprised")
            ingrid "And here I thought I had a lot going on during high school."

            if ellie_valedictorian:
                ingrid "And you still made Valedictorian? How did you-- Did you even sleep, like, what--"
                ingrid "You know what? Not important."

            $ show_character("ingrid")
            ingrid "And this... {i}contact{/i} of yours, you think you can trust her? After everything?"

            if ellie_prom == "Mona":
                $ show_character("ingrid", "surprised")
                ingrid "Wait... Is she the girl you took to prom?"
                ingrid "Gorgeous, sleeve tattoo, looked like she could break me in half?"

                $ hide_character()
                "You think back to prom night."

                scene prom sepia at center with dissolve
                "Slowly dancing with Mona, you suddenly bump into somebody else on the floor."
                $ young_ingrid_outfit = "prom"
                $ brent_outfit = "prom"
                $ show_character("ingrid", "angry", modifier="young")
                ingrid "Ugh, could you {i}please{/i} watch where you're going?"

                $ hide_character()
                "You turn around to see Ingrid and Brent."
                "Brent gives Mona the once-over."

                $ show_character("brent", "angry")
                brent "Do you even go to this school?"

                $ show_character("mona", modifier="young")
                mona "Do I {i}look{/i} like I go to this school?"

                $ hide_character()
                scene hotel suite at center
                show split_screen at center

                $ show_character("ellie")
                ellie "Yeah..."
                $ show_character("ellie", "surprised")
                ellie "Still can't believe you went with Brent."

                $ show_character("ingrid")
                ingrid "That doesn't matter right now."

            $ show_character("ingrid")
            ingrid "She sounds like a liability. Too unpredictable."

            $ show_character("ellie")
            if ch1_mona_trusted:
                ellie "I know but I trust her."
            elif ch1_mona_dont_care:
                ellie "She's our best bet. She knows stuff."
            elif ch1_mona_i_know:
                ellie "She's desperate. She'll fall in line."
            elif ch1_mona_liar:
                ellie "She is unpredictable. We can't let our guard down around her."
            else:
                ellie "I can handle her."

            $ show_character("ingrid")
            ingrid "Alright... I'll defer to you on this one."

    $ show_character("ingrid")
    ingrid "I'm on my way there. Meet you at the hotel?"

    $ show_character("ellie")
    ellie "See you."

    $ hide_character()
    hide split_screen with wiperight
    "You hang up the phone."    
    "After putting away your stuff you get started on the preparations for Ingrid's arrival and Mona's liberation."    

    jump ch1_scene3