label ch1_scene3:

    scene black with dissolve

    $ playable_character = "MONA"
    $ playing_as = "MONA"
    $ who_old = "NOT VOICE"

    $ change_mona_outfit(0, 0, False)

    tutorial "Now playing as Mona."

    scene prison cell clean at right with dissolve

    "It's been a few days since [Ellie] came to visit you."

    $ show_character("mona", "neutral")
    with dis
    left_mona "(I should have known it was too good to be true.)"
    left_mona "(I can only count on myself. Always.)"

    if ch1_mona_trusted:
        left_mona "(She said she trusted me...)"
    elif ch1_mona_i_know:
        left_mona "(She thinks she knows everything.)"
    elif ch1_mona_dont_care:
        left_mona "(Turns out she really meant it when she said she didn't care.)"
        if mona_flirt or ellie_prom == "Mona":
            $ show_character("mona", "sad") 
            with dis
            left_mona "(It shouldn't sting the way it does.)"
    elif ch1_mona_liar:
        left_mona "(Guess we're both liars.)"
    else: # said it was good to see her
        $ show_character("mona", "sad")
        left_mona "(I can't believe I actually expected her to show up for me.)"
        left_mona "({i}It was good seeing you{/i}, how pathetic is that?)"

    if mona_relationship_icon == "like":
        $ mona_relationship -= 2

    $ show_character("mona", "angry") 
    with dis
    left_mona "(What a bunch of bullshit.)"

    $ hide_character()
    "The doors to your cell unlock with a buzz."
    "You fall in line with the other inmates for your mandatory outside time in the yard."

    scene prison patio at center with dissolve
    pause 0.5

    $ show_character("mona")
    left_mona "(I just have to keep my head down. I'll get out of here one way or another.)"

    $ show_character("jacqueline", "angry")
    ugh "Oi! What do you think you're doing, Hot Shot?"

    play music "audio/TPA/tense fight.mp3" fadein 1.0

    $ hide_character()
    "So much for keeping your head down."

    $ show_character("mona")
    left_mona "Minding my own business. You should try it sometime."

    $ hide_character()
    "That was apparently the wrong thing to say, as she takes a deliberate step into your space, hands curling into fists."

    $ show_character("jacqueline", "angry")
    this_bitch "Heard you've been talking to the cops. We don't take kindly to snitches around here."

    $ show_character("mona", "angry")
    left_mona "Back off."
    left_mona "I didn't talk to no one. And even if I did it wouldn't be any of your business."
    left_mona "Back. Off."

    $ hide_character()
    "You're awfully aware of the crowd starting to circle the two of you."

    $ show_character("jacqueline", "angry")
    this_bitch "You know what happens to snitches?"

    $ mission_current_value = 0
    $ mission_required_value = 2
    $ timeout_label = "ch1_scene3_fight_fail"
    
    $ show_character("mona", "surprised")
    menu: 
        left_mona "(She's going to kill me, I should...)"

        "Throw the first punch!": # +FIGHT
            $ hide_character()
            jump ch1_scene3_fight_punch

        "Reason with her!": # -FIGHT
            $ show_character("mona", "surprised")
            left_mona "Look, I don't want any trouble--"
            jump ch1_scene3_fight_fail

label ch1_scene3_fight_punch:
    $ timeout_label = None
    play sound "audio/SFX/sfx punch.mp3"
    "{i}SMACK!{/i} Your fist connects with her jaw, sending her tumbling backwards."
    "She glares at you as the crowd around you starts chanting {i}fight! Fight! Fight!{/i}"

    $ show_character("jacqueline", "angry")
    this_bitch "You little bitch!"
    $ mission_current_value += 1
    $ show_point_gained("+FIGHT")

    $ show_character("mona", "angry")
    left_mona "Come at me again, I dare you."

    $ hide_character()
    "She wipes the blood off her mouth and circles back around you."
    "You square your shoulders, preparing for the worst."

    jump ch1_scene3_fight_charge

label ch1_scene3_fight_fail:
    $ timeout_label = None
    play sound "audio/SFX/sfx punch.mp3"
    "{i}SMACK!{/i} She punches you in the gut, knocking the wind right out of you."
    "She glares at you as the crowd around you starts chanting {i}fight! Fight! Fight!{/i}"

    $ show_character("jacqueline", "angry")
    $ show_point_gained("-FIGHT")
    this_bitch "You're a rat! You'll die like one."

    jump ch1_scene3_fight_charge

label ch1_scene3_fight_charge:
    
    $ hide_character()
    "She charges at you at full speed."

    $ timeout_label = "ch1_scene3_fight_scream"
    $ show_character("mona", "surprised")
    menu:
        left_mona "..."

        "Sidestep her!": # -FIGHT
            $ hide_character()
            "You try to sidestep her but you're not fast enough."
            play sound "audio/SFX/sfx punch.mp3"
            "The impact sends you flying and you land on our back with a {i}crack{/i}."
            "You're not sure if you broke a bone or just landed on a twig and you're in too much pain to care."
            $ show_point_gained("-FIGHT")

        "Dive out of the way!": # +FIGHT
            $ hide_character()
            "You dive out of the way just in time to avoid her!"
            "You try to scramble back to your feet but another inmate kicks you back down."
            $ mission_current_value += 1
            $ show_point_gained("+FIGHT")
            $ show_character("mona", "angry")
            left_mona "{i}Uff!{/i}"
            left_mona "Can't finish the job yourself?"
            left_mona "Need your minions to come save your ass?"

        "Scream!": # -FIGHT
            jump ch1_scene3_fight_scream

    $ ch1_mona_won_fight = completed_mission(mission_required_value, mission_current_value)
    jump ch1_scene3_end_fight

label ch1_scene3_fight_scream:
    $ hide_character()
    "Eyes open wide, you see the world in slow motion as she comes barrelling towards you."
    play sound "audio/SFX/sfx punch.mp3"
    "You let out a blood-curdling scream as her body makes contact with yours, sending you flying back."
    $ show_point_gained("-FIGHT")

    jump ch1_scene3_end_fight

label ch1_scene3_end_fight:
    $ timeout_label = None
    $ hide_character()
    "Next thing you know, she's on top of you, her hands squeezing your throat shut."

    $ show_character("jacqueline", "angry")
    jacqueline "Argh!"

    $ hide_character()
    "You claw at her face desperately, gasping for air."

    $ show_character("mona", "surprised")
    left_mona "N...o-- Le..t ...m...e--"

    $ hide_character()
    "Your eyes start to lose focus. You try desperately to stay awake as your body feels heavier and heavier."
    "As the world slowly fades to black you're left with a single haunting thought..." 
    "{i}No one is coming to save you.{/i}"

    scene black with dissolve
    pause 2.0

    $ ch1_done = True

    jump ch1_end_stats

label ch1_end_stats:

    $ center_voice = "CHAPTER STATS"

    if ch1_trail_mission_successful:
        end_stats "You successfully completed your last training mission."
    else:
        end_stats "You botched your last training mission."
    
    if ch1_ingrid_scene:
        end_stats "You celebrated your new role as a fully fledged Phantom Agent with Ingrid."
    else:
        end_stats "You chose not to celebrate your new role as a fully fledged Phantom Agent with Ingrid."

    end_stats "You have recruited Mona as an informant."

    if ch1_ingrid_truth:
        end_stats "You chose to tell Ingrid the truth about your past with the Mercy Park Crew."
    else:
        end_stats "You chose not to tell Ingrid the truth about your past with the Mercy Park Crew."

    end_stats "ALLIES\nIngrid ... Alive & Recruited\nMona ... Alive & Recruited"

    end_stats "POINTS\n{color=[red]}SUAVE{/color} [suave_points] out of [maximum_suave_points]\n{color=[blue]}SERIOUS{/color} [serious_points] out of [maximum_serious_points]"

    $ center_voice = "TUTORIAL"

    jump end_of_chapter
    #jump end_of_demo