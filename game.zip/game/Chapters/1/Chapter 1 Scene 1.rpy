label trail_jones_training_generic:

    $ show_character("ingrid", "happy", "holo")
    ingrid_holo "Oooh, so professional!"
    ingrid_holo "You know this is just a {i}training{/i} mission, right?"

    $ show_character("ellie")
    ellie "Yes. Our {i}last{/i} training mission."
    ellie "It's the last opportunity to test our skills. I will give it my all."

    $ show_character("ingrid", "happy", "holo")
    ingrid_holo "Always a high achiever. Do you ever stop?"

    $ show_character("ellie")
    $ timeout_label = None

    menu:
        with dis

        ellie "You mean after being..."

        "Valedictorian?": 
            $ ellie_valedictorian = True
            $ ch1_trail_jones_left = True

            $ show_character("ellie", "happy")
            ellie "No chance."

            $ show_character("ingrid", "happy", "holo")
            ingrid_holo "Ugh, don't remind me. I can't believe I lost to you."

        "Salutorian?": 
            ellie "Are you kidding me? I am never losing to you again."

            $ show_character("ingrid", "happy", "holo")
            ingrid_holo "Heh, good times."

    $ show_character("ingrid", "neutral", "holo")
    ingrid_holo "We weren't even friends back in high school."

    $ show_character("ellie")
    menu:
        with dis
        ellie "Good thing we..."

        "Patched things up senior year.":
            if ellie_valedictorian:
                $ ellie_ingrid_friends_hs = True
            else:
 
                $ show_character("ingrid", "neutral", "holo")
                ingrid_holo "I dedicated my speech to you and all. I meant every word."

        "Are friends now.":
            $ ellie_ingrid_friends_hs = False
    
    $ show_character("ellie", "happy")
    ellie "We work much better as a team."
    $ hide_character()

    if ch1_trail_jones_left:
        jump trail_jones_left_end
    else:
        jump trail_jones_right_end

label chapter1_scene1:
    ##initalizing chapter variables
    $ middle = False
    $ regular = True
    $ who_old = "NOT VOICE"
    $ playable_character = "ELLIE"
    $ playing_as = capsEllie

    $ setup_complete = True

    # restore default values for chapter variables variables
    $ maximum_serious_points = 0
    $ maximum_suave_points = 0
    $ suave_points = 0
    $ serious_points = 0
    $ serious_points_old = 0
    $ suave_points_old = 0
    $ current_li = None
    $ current_speaker = None
    $ ch1_trail_jones_left = False
    $ ch1_trail_jones_bartender = False
    $ ch1_trail_jones_freeze = False
    $ ch1_trail_mission_successful = False
    $ ch1_trail_jones_bouncer = False
    $ ch1_ingrid_scene = False
    $ ch1_drink = None
    $ ch1_ingrid_cat = False
    $ ch1_officer_suave_point = False
    $ ch1_grey_sign_off = False
    $ ch1_talk_logan_out_of_it = False
    $ ch1_arrest_logan = False
    $ ch1_mona_trusted = False
    $ ch1_mona_liar = False
    $ ch1_mona_dont_care = False
    $ ch1_mona_i_know = False
    $ ch1_ingrid_truth = False
    $ ch1_not_going_rogue = False
    $ ch1_mona_won_fight = False
    $ ch1_done = False
    $ ellie_valedictorian = False
    $ ellie_ingrid_friends_hs = False
    $ ellie_codename = None
    $ ellie_young_first_kiss = None
    $ ellie_prom = None
    $ ellie_prom_love = False
    $ change_ellie_outfit("casual", ellie_default_outfit)
    $ change_ingrid_outfit("casual", 1)
    $ save_relationship_system_scores()

    if renpy.music.get_playing("music") != "audio/TPA/spy investigate.mp3":
        play music "audio/TPA/spy investigate.mp3" fadein 1.0
    
    $ playable_character = "ELLIE"
    $ playing_as = capsEllie
    scene black with fade

    #"This book contains disturbing images, as well as depictions of violence and trauma. Reader discretion advised…"
    $ who_old = "TUTORIAL"
    scene new york street night at mid_left with fade
    show screen location_title("new york text") with dissolve
    show screen settingsUI
    $ renpy.pause(2, hard=True)
    hide screen location_title with dissolve

    $who_old = "TUTORIAL"
    $center_voice = "TUTORIAL"
    show screen suave_and_serious_points
    tutorial "Now playing as [Ellie] [Wheeler]."
    $center_voice = "TUTORIAL"

    $ playing_as = capsEllie

    "You watch your target step out of a building in New York, taking care not to stand out too much from the crowd."

    $ show_character("jones")
    jones "..."
    $ hide_character()

    "[AgentJones] [Jones] continues to the {color=#23a997}right{/color}, disappearing out of sight."

    "You touch your earpiece and hear it crackle to life."

    tutorial "You're about to encounter your first choice! Choose carefully."

    $ timeout_label = None
    $ middle = False
    $ bottom = False
    $ quick_menu = False

    $ mission_required_value = 2
    $ mission_current_value = 0

    $ achievement_success_title ="PIECE OF CAKE"
    $ achievement_success_text = "You completed the trailing mission!"

    $ achievement_failure_title = "SHAKEN, NOT DETERRED"
    $ achievement_failure_text = "Agent [Jones] almost evaded you."

    $ show_character("ellie", with_mood="surprised")
    menu:

        ellie "Target is on the move. I'm in pursuit, going..."

        "Left": # -CHASE
            $ hide_character()
            $ ch1_trail_jones_left = True
            jump trail_jones_left
            
        "Right": # +CHASE
            $ hide_character()
            $ ch1_trail_jones_left = False
            jump trail_jones_right

label trail_jones_left:
    "You dart to the left."

    scene new york street night at mid_left_to_left

    "You keep your head high, trying to get a glimpse of your target."

    "Your earpiece crackles once again and you hear your partner, {color=[highlight]}Agent Ingrid Delaney{/color}, in your ear."

    $ show_character("ingrid", "neutral", "holo")
    ingrid_holo "The contact is moving away from your location. Are you sure you're going the right away?"

    $ show_character("ellie", "angry")
    ellie "Damn it! I lost the target."

    $ show_point_gained("-CHASE")

    $ my_notify_func("gui/notify.png", "ON THE FIRST CHOICE?", "Seriously??")

    $ show_character("ingrid", modifier="holo")
    ingrid_holo "They must have gone to the right. Circle back."

    $ show_character("ellie")
    ellie "Copy that."
    $ hide_character()

    #jump trail_jones_training_generic

    $ show_character("ingrid", "happy", "holo")
    ingrid_holo "Oooh, so professional!"
    ingrid_holo "You know this is just a {i}training{/i} mission, right?"

    $ show_character("ellie")
    ellie "Yes. Our {i}last{/i} training mission."
    ellie "It's the last opportunity to test our skills. I will give it my all."

    $ show_character("ingrid", "happy", "holo")
    ingrid_holo "Always a high achiever. Do you ever stop?"

    $ show_character("ellie")
    $ timeout_label = None

    menu:
        with dis

        ellie "You mean after being..."

        "Valedictorian?": 
            $ ellie_valedictorian = True
            $ ch1_trail_jones_left = True

            $ show_character("ellie", "happy")
            ellie "No chance."

            $ show_character("ingrid", "happy", "holo")
            ingrid_holo "Ugh, don't remind me. I can't believe I lost to you."

        "Salutorian?": 
            ellie "Are you kidding me? I am never losing to you again."

            $ show_character("ingrid", "happy", "holo")
            ingrid_holo "Heh, good times."

    $ show_character("ingrid", "neutral", "holo")
    ingrid_holo "We weren't even friends back in high school."

    $ show_character("ellie")
    menu:
        with dis
        ellie "Good thing we..."

        "Patched things up senior year.":
            if ellie_valedictorian:
                $ ellie_ingrid_friends_hs = True
            else:
 
                $ show_character("ingrid", "neutral", "holo")
                ingrid_holo "I dedicated my speech to you and all. I meant every word."

        "Are friends now.":
            $ ellie_ingrid_friends_hs = False
    
    $ show_character("ellie", "happy")
    ellie "We work much better as a team."
    $ hide_character()

    jump trail_jones_left_end

label trail_jones_left_end:
    "You retrace your steps back to the building where you first saw the target exit from and then continue on to the right."

    scene new york street night at left_to_right

    "You make it just in time to see the target step past the bouncer into a private club."

    jump trail_jones_club_outside

label trail_jones_right:
    if jones_pronoun_she == "they":
        "You trail Agent [Jones] from a safe distance, taking care not to be noticed when [jones_pronoun_she] glance back."
    else:
        "You trail Agent [Jones] from a safe distance, taking care not to be noticed when [jones_pronoun_she] glances back."

    scene new york street night at mid_left_to_mid_right
    
    "Your earpiece crackles once again and you hear your partner, {color=[highlight]}Agent Ingrid Delaney{/color}, in your ear."

    $ show_character("ingrid", "neutral", "holo")
    ingrid_holo "I see Agent [Grey]. [grey_pronoun_she!c] came in through the back."
    ingrid_holo "You're almost at the drop location. Keep trailing [jones_pronoun_her]."

    $ show_character("ellie")
    ellie "Copy that."
    $ mission_current_value += 1
    $ show_point_gained("+CHASE")
    $ ch1_trail_jones_left = False
    $ hide_character()

    $ show_character("ingrid", "happy", "holo")
    ingrid_holo "Oooh, so professional!"
    ingrid_holo "You know this is just a {i}training{/i} mission, right?"

    $ show_character("ellie")
    ellie "Yes. Our {i}last{/i} training mission."
    ellie "It's the last opportunity to test our skills. I will give it my all."

    $ show_character("ingrid", "happy", "holo")
    ingrid_holo "Always a high achiever. Do you ever stop?"

    $ show_character("ellie")
    $ timeout_label = None

    menu:
        with dis

        ellie "You mean after being..."

        "Valedictorian?": 
            $ ellie_valedictorian = True
            $ ch1_trail_jones_left = True

            $ show_character("ellie", "happy")
            ellie "No chance."

            $ show_character("ingrid", "happy", "holo")
            ingrid_holo "Ugh, don't remind me. I can't believe I lost to you."

        "Salutorian?": 
            ellie "Are you kidding me? I am never losing to you again."

            $ show_character("ingrid", "happy", "holo")
            ingrid_holo "Heh, good times."

    $ show_character("ingrid", "neutral", "holo")
    ingrid_holo "We weren't even friends back in high school."

    $ show_character("ellie")
    menu:
        with dis
        ellie "Good thing we..."

        "Patched things up senior year.":
            if ellie_valedictorian:
                $ ellie_ingrid_friends_hs = True
            else:
 
                $ show_character("ingrid", "neutral", "holo")
                ingrid_holo "I dedicated my speech to you and all. I meant every word."

        "Are friends now.":
            $ ellie_ingrid_friends_hs = False
    
    $ show_character("ellie", "happy")
    ellie "We work much better as a team."
    $ hide_character()

    #jump trail_jones_training_generic
    jump trail_jones_right_end

label trail_jones_right_end:

    scene new york street night at mid_right_to_right

    if jones_pronoun_she == "they":
        "You follow Agent [Jones] for a couple more blocks until they stop by what seems to be a private club."
    else:
        "You follow Agent [Jones] for a couple more blocks until [jones_pronoun_she] stops by what seems to be a private club."

    if jones_pronoun_she == "they":
        "[jones_pronoun_she!c] stop for a minute to greet the bouncer before going in."
    else:
        "[jones_pronoun_she!c] stops for a minute to greet the bouncer before going in."

    jump trail_jones_club_outside

label trail_jones_club_outside:
    $ show_character("ingrid", "neutral", "holo")
    ingrid_holo "I have eyes on both the target and the contact. You better get inside, [Wheeler]."

    $ show_character("ellie", "surprised")
    ellie "You've been waiting inside, how did you get past the bouncer?"

    $ show_character("ingrid", "happy", "holo")
    ingrid_holo "Wouldn't you like to know."

    $ hide_character()

    "You roll your eyes."

    $ show_character("ellie")
    ellie "Oh Supreme Master Phantom Agent Delaney, any ideas how I can get in?"

    $ show_character("ingrid", "neutral", "holo")
    ingrid_holo "No clue. Whatever you do, do it quickly."
    ingrid_holo "I can't trail them both."
    $ hide_character()

    "You scan the area for entry options."

    $ show_character("ellie")
    ellie "(I could take a page out of [Jones]'s book and smooth talk the bouncer.)"
    ellie "(Or maybe there's another way in?)"

    $ show_character("ellie")

    menu:
        with dis
        ellie "(I should...)"
        "Try the back entrance.": # +SERIOUS
            $ maximum_suave_points += 1
            $ hide_character()
            jump trail_jones_club_another_entrance
            
        "Trick the bouncer.": # +SUAVE
            $ maximum_suave_points += 1
            $ hide_character()
            $ ch1_trail_jones_bouncer = True
            jump trail_jones_club_charm

label trail_jones_club_another_entrance:
    "You circle around the building and almost immediately spot the unguarded service entrance."

    $ show_character("ellie", "happy")
    $ suave_points += 1
    ellie "(Bingo!)"
    $ hide_character()

    pause 0.2

    tutorial "You just earned an action point! Some choices require a certain amount of action points to be unlocked. You can earn {color=[blue]}SERIOUS{/color} or {color=[red]}SUAVE{/color} action points by choosing the correct answers on some choices."

    jump trail_jones_club_inside

label trail_jones_club_charm:
    "The bouncer arches an eyebrow at you as you approach."

    $ show_character("m bodyguard")
    bodyguard "This is a private club."

    $ show_character("ellie", "happy")
    ellie "Clearly. I'm expected here."

    $ show_character("m bodyguard")
    bodyguard "Oh? Who are you? Who is expecting you?"

    $ show_character("ellie", "happy")
    ellie "I'm [AgentGrey] [Grey]. [AgentJones] [Jones] is expecting me."

    if not grey_female:
        $ hide_character()
        "The bouncer squints at you."
        $ show_character("m bodyguard")
        bodyguard "[AgentGrey] [Grey]? I thought you were a man."

        $ show_character("ellie", "angry")
        ellie "Are all bouncers rude or is it just you?"
        ellie "If you don't like my name go complain to my parents. Step aside."

    $ hide_character()
    "The bouncer hesitates for only a moment before letting you through."

    $ suave_points += 1
    $ show_character("m bodyguard")
    bodyguard "Go right ahead, Miss."
    $ hide_character()
    
    pause 0.2

    tutorial "You just earned an action point! Some choices require a certain amount of action points to be unlocked. You can earn {color=[blue]}SERIOUS{/color} or {color=[red]}SUAVE{/color} action points by choosing the correct answers on some choices."

    jump trail_jones_club_inside

label trail_jones_club_inside:

    scene interior bar artedecor at left with fade

    $ show_character("jones")
    jones "..."
    $ mission_current_value += 1
    $ show_point_gained("+CHASE")
    $ hide_character()

    "You spot the target passing by the bar and follow after [jones_pronoun_her]."

    scene interior bar artedecor at mid_left_to_mid_right
    
    play sound "audio/SFX/sfx glass shatter.mp3"

    "The commotion at the bar draws your attention momentaneously!"

    $ show_character("bartender sur")
    bartender "I am so sorry! Let me clean that for you."
    $ hide_character()

    "The bar is chaotic, with multiple people ordering drinks and just the lone bartender trying to appease everyone."
    "As the bartender starts cleaning up the broken glass, you turn back to your target... Only to find [jones_pronoun_her] moving to another room!"

    tutorial "Some choices are timed. Choose before the timer runs out."

    $ show_character("ellie")
    $ timeout_label = "trail_jones_freeze"
    menu:
        with dis
        ellie "I have to..."

        "Follow the target!": # +CHASE
            $ show_point_gained("+CHASE")
            $ mission_current_value += 1
            $ hide_character()
            jump trail_jones_follow
        "Help the bartender!": # -CHASE, +SUAVE
            $ ch1_trail_jones_bartender = True
            $ hide_character()
            jump trail_jones_bartender
        "Freeze!": # -CHASE
            jump trail_jones_freeze

label trail_jones_bartender:
    "You circle back to the bar."

    $ show_character("ellie")
    ellie "Let me give you a hand."

    $ show_character("bartender sur")
    bartender "You don't have to!"

    $ show_character("ellie", "happy")
    ellie "It's no trouble. You looked like you could use a pick me up."

    $ show_character("bartender hap")
    bartender "You're sweet."
    $ hide_character()

    "You help him clean up the remainder of the glass shards."
    "Afterwards, the bartender scribbles something on a napkin and hands it to you."

    $ timeout_label = None
    show screen item("napkin", "A phone number")
    $ regular = False
    $ bottom = True
    menu:
        with dis
        "I'll take it.":
            $ bottom = False
            $ regular = True

    hide screen item with dis

    $ show_character("bartender hap")
    bartender "Give me a call if you ever want to {i}pick me up{/i} for something else."

    $ show_character("ellie", "happy")
    ellie "Will do."
    $ suave_points += 1

    $ show_character("ingrid", "neutral", "holo")
    ingrid_holo "Barf. Do you have to flirt with your mic on?"

    $ show_character("ingrid", "happy", "holo")
    ingrid_holo "Also, what happened to the {i}being professional{/i} and {i}testing our skills{/i} mambo jumbo?"
    
    $ show_character("ellie", "happy")
    ellie "A girl's gotta do what a girl's gotta do."
    $ show_point_gained("-CHASE")
    $ hide_character()

    "You pocket the bartender's number."

    $ show_character("ellie")
    ellie "Back to being professional now."
    $ hide_character()

    jump trail_jones_follow

label trail_jones_freeze:
    $ hide_character()
    $ ch1_trail_jones_freeze = True
    "You stay rooted in the same spot."

    $ show_character("ingrid", "surprised", "holo")
    ingrid_holo "Ummm, Earth to [Ellie]? What are you doing? Where are you?"

    $ show_character("ellie", "surprised")
    ellie "Sorry, I got distracted!"
    $ show_point_gained("-CHASE")

    $ show_character("ellie")
    ellie "I'm on it."
    $ hide_character()

    jump trail_jones_follow

label trail_jones_follow:

    scene interior bar artedecor at mid_right_to_right
    $ hide_character()
    "You move on the next room."

    scene nightclub vip at left_to_right with fade

    "... And step right into the VIP lounge of the private club."

    $ ch1_trail_mission_successful = completed_mission(mission_required_value, mission_current_value,
                                                        achievement_success_title, achievement_success_text,
                                                        achievement_failure_title, achievement_failure_text)

    $ maximum_serious_points += 1
    $ maximum_suave_points += 1

    stop music

    play music "audio/TPA/default chill.mp3"

    if ch1_trail_mission_successful:
        # Gray is happy -> +SERIOUS ?

        $ show_character("jones", "happy")
        jones "[Wheeler]! You're the first one here."
        jones "Did I go too easy on you?"
        $ serious_points += 1

        $ show_character("ellie", "happy")
        ellie "No, I'm just that good."

        #$ lr("ellie", "jones")
        $ show_character("jones", "happy")
        jones "How did you get inside?"

        if ch1_trail_jones_bouncer:
            $ jones_ellie_fav_child = True

            $ show_character("ellie", "happy")
            ellie "Easy. I just asked the bouncer to let me in."

            $ show_character("jones", "surprised")
            jones "And he let you in just like that?"

            $ show_character("ellie", "happy")
            ellie "Yes."
            ellie "... After I convinced him I was Agent [Grey]."

            #$ show_character("grey", "neutral")
            #grey "You impersonated me?"
            #$ hide_character()

            $ center_voice = AgentGrey.upper()
            center_grey "You impersonated me?"
            $ center_voice = "TUTORIAL"

            $ hide_character()
            "You turn around and find Agent [Grey] behind you."

            $ show_character("grey")
            grey "Can't say I approve of your methods."

            $ show_character("jones", "happy")
            jones "I do."

            $ show_character("grey")
            grey "Of course you do."

            $ hide_character()
            
            "Agent [Grey] rolls [grey_pronoun_pos_her] eyes at Agent [Jones] in fake annoyance."
            
            if jones_grey_dating:
                $ show_character("jones", "happy")
                jones "One of us needs to be the cool parent, [grey_darling]."
            else:
                $ show_character("jones", "happy")
                jones "One of us needs to be the cool parent."
        
        else:
            $ show_character("ellie", "happy")
            ellie "The back door was unguarded."

            $ show_character("jones")
            jones "That's it? That's not very creative of you."

            $ center_voice = capsAgentGrey
            center_grey "It's the right way."
            $ center_voice = "TUTORIAL"

            $ hide_character()
            "You turn around and find Agent [Grey] behind you."

            $ show_character("grey", "neutral")
            grey "Simple and undetected."

            if jones_grey_dating:
                $ show_character("jones", "happy")
                jones "Boring. One of us needs to be the cool parent, [grey_darling]."
            else:
                $ show_character("jones", "happy")
                jones "Boring. One of us needs to be the cool parent."

    else:
        $ show_character("jones")
        jones "[Wheeler], nice of you to join us."
        jones "What took you so long?"

        $ show_character("ellie")
        ellie "Sorry for the delay."

        if ch1_trail_jones_left: # made a wrong turn
            ellie "I lost track of you in the streets."

            $ show_character("jones", "happy")
            jones "You should never loose sight of your parents."

        if ch1_trail_jones_freeze: # got distracted for a minute there
            ellie "There was a commotion at the bar that startled me."

            $ show_character("jones", "happy")
            jones "And you didn't stop to help? We raised you better than that."

        if ch1_trail_jones_bartender: # Jones high five

            $ show_character("ellie", "happy")
            ellie "The good news is that I got the bartender's number."

            $ show_character("grey")
            grey "I'm sorry, how is that good news?"

            $ show_character("jones", "happy")
            jones "You've taken my lessons to heart, I see."
            jones "This is why you've always been my favourite child."
            $ jones_ellie_fav_child = True

    $ show_character("grey", "neutral")
    if jones_grey_dating:
        grey "We aren't her parents, [jones_darling]."
    else:
        grey "We aren't her parents."
    
    $ hide_character()
    "[AgentJones] promptly ignores [grey_pronoun_her]."

    $ show_character("jones", "happy")
    jones "Speaking of, where is our other child?"
    $ hide_character()

    $ middle = True
    $ regular = False

    $ center_voice = "INGRID"
    center_ingrid "Right here."
    $ center_voice = "TUTORIAL"

    jump ingrid_presentation

label ingrid_presentation:

    $ middle = False
    $ bottom = True
    $ regular = False
    $ timeout_label = None

    $ ingrid_mood = "happy"
    show big ingrid with dissolve

    menu:
        b3 "Wow, Ingrid you look..."

        "Like a Barbie puked on you.": # -INGRID
            $ ingrid_barbie_puke = True
            $ middle = False
            $ bottom = False
            $ regular = True
            hide big ingrid with dissolve
            pause 0.2

            if not ch1_trail_mission_successful:
                $ show_character("ingrid")
                ingrid "You know what else I look like?"
                $ notify_relationship_point("-INGRID")
                $ ingrid_relationship -= 2
                ingrid "The better spy."
                #$ my_notify_func("gui/notify.png", "LONE WOLF", "You're not here to make any friends.")

            else:
                $ show_character("ingrid")
                ingrid "You really know how to make a girl feel special, don't you?"
                $ notify_relationship_point("-INGRID")
                $ ingrid_relationship -= 2
                #$ my_notify_func("gui/notify.png", "LONE WOLF", "You're not here to make any friends.")

                if ch1_trail_jones_bartender:
                    ingrid "Your \"charm\" only works on bartenders, it seems."

            $ hide_character()

        "Great.": # +INGRID
            $ middle = False
            $ bottom = False
            $ regular = True
            hide big ingrid with dissolve
            pause 0.2

            $ show_character("ingrid", "happy")
            ingrid "I told you I'd dye my hair when we started ghosting for real."

            $ show_character("ellie", "happy")
            ellie "You need to stop referring to being a Phantom Agent as \"ghosting\"."

            $ show_character("ingrid", "happy")
            $ ingrid_relationship += 2
            ingrid "Do I? I think not."

            $ hr("ingrid")
        
        "{image=heart_ingrid} So hot.": # +INGRID
            $ middle = False
            $ bottom = False
            $ regular = True
            hide big ingrid with dissolve
            pause 0.2
            
            if ch1_trail_jones_bartender:
                $ show_character("ingrid", "happy")
                ingrid "Cool. Do you want me to write my number on that dirty napkin too?"

                $ show_character("ellie", "happy")
                ellie "No, thank you. I already have your number."

                $ show_character("ingrid", "neutral")
                ingrid "You do."
                $ ingrid_romance += 1
                #$ notify_relationship_point("+{image=heart_ingrid} INGRID")
                $ show_character("ingrid", "happy")
                ingrid "And you don't look half-bad either."

            else:
                $ show_character("ingrid", "happy")
                ingrid "Don't stop there, keep the compliments coming."

                $ show_character("ellie", "happy")
                ellie "I don't think your ego needs any more stroking."

                $ show_character("ingrid", "happy")
                ingrid "You're no fun."
                $ ingrid_romance += 1
                ingrid "And, you know, same."

            $ ingrid_flirt = True
            $ hide_character()

    $ middle = False
    $ bottom = False
    $ regular = True

    $ hide_character()
    tutorial "Your relationship with Ingrid was affected!"
    tutorial "Some choices affect how other characters perceive you. Their perception of you can have consequences on their reactions."

    jump ch1_vip_lounge

label ch1_vip_lounge:
    
    "[AgentGrey] clears [grey_pronoun_her] throat."

    $ show_character("grey")
    grey "Now that we are all here..."

    $ show_character("grey", "happy")
    grey "[AgentJones] and I wanted to congratulate you both on becoming fully fledged Phantom Agents."

    $ show_character("grey")
    grey "Even though {i}some{/i} of you didn't take this last mission seriously."

    $ show_character("jones")
    jones "We booked the lounge for you."

    $ show_character("jones", "happy")
    jones "Enjoy your night, kids."

    $ show_character("grey", "neutral")
    grey "But don't enjoy it too much."
    grey "As your mentors, we asked to be the ones to deliver you this."
    $ hide_character()

    "[AgentGrey] hands you a case folder."

    show screen item("file_secret", "Our first official case")
    $ regular = False
    $ bottom = True
    menu:
        with dis
        "Now we're real secret agents.":
            $ bottom = False
            $ regular = True
    
    hide screen item with dis

    $ show_character("grey")
    grey "Don't get too excited."
    grey "It's a minor investigation. You have to work your way up to the bigger cases."

    if ch1_trail_mission_successful:
        $ show_character("jones", "happy")
        jones "I have no doubt you'll be catching bigger fish in no time."

    else:
        grey "Given how this training mission went I'd suggest you work harder."

    $ show_character("ellie")
    ellie "We'll make you proud."

    $ show_character("jones")
    jones "It was a pleasure mentoring you both."

    if jones_ellie_fav_child:
        $ hide_character()
        "[AgentJones] winks at you."

        $ show_character("jones", "happy")
        jones "Definitely not playing favorites."
    
    $ show_character("grey")
    grey "Right."
    grey "Do read the case file when you get out of here."
    grey "We'll check in with you tomorrow."
    $ hide_character()

    "[AgentJones] and [AgentGrey] bid you goodbye."
    "Ingrid looks around at the empty lounge, reserved just for the two of you."

    $ show_character("ingrid", "neutral")
    ingrid "They really didn't let anyone else in this room?"
    ingrid "I guess it makes sense with the whole {i}giving us our first case{/i} thing."

    $ show_character("ellie", "happy")
    ellie "Who could have guessed the downside of having a top secret job was that no one could know about it?"

    $ show_character("ingrid", "happy")
    ingrid "Right? I would have never signed up for this if I had known."

    $ show_character("ingrid", "happy")
    ingrid "I don't know about you but I'm going to celebrate the Hell out of this."
    
    if ingrid_barbie_puke:
        $ show_character("ingrid")
        ingrid "I'd tell you to celebrate with me but you probably don't want to be around and my puked-up Barbie hair."

        $ show_character("ellie")
        ellie "I think it suits you."

        $ show_character("ellie", "happy")
        ellie "Your new codename could be Barf Barbie. Barfie, if you will."
        $ ingrid_codename_barfie = True
        $ ingrid_codename = "Barfie"
        $ hide_character()

        "Ingrid clears her throat as she tries (and fails) to hide a smile."

        $ show_character("ingrid", "happy")
        ingrid "You're insufferable."
        ingrid "If I ask you to stay will you stop with the bad jokes?"

        $ show_character("ellie", "happy")
        ellie "Never."

        $ show_character("ingrid", "happy")
        ingrid "Whatever."

    ingrid "Are you staying or not?"
    $ hide_character()

    tutorial "Stay and celebrate your new position as Phantom Agent with Ingrid to improve your relationship (and for a chance at romance)." 

    $ middle = False
    $ bottom = True
    $ regular = False
    $ timeout_label = None

    $ ingrid_mood = "neutral"
    show big ingrid with dissolve

    menu:
        with dis
        b "I will..."
        "Stay and celebrate.":
            hide big ingrid
            $ ingrid_mood = "happy"
            show big ingrid
            pause 1.5
            hide big ingrid with dissolve
            $ middle = False
            $ bottom = False
            $ regular = True
            jump ch1_scene1_ingrid_diamond_scene

        "Turn in early.":
            $ middle = False
            $ bottom = False
            $ regular = True
            hide big ingrid with dissolve
            
            $ show_character("ellie")
            ellie "I'm beat. I think I'll just go home and take a look at the mission files."

            $ show_character("ingrid")
            ingrid "Suit yourself."
            ingrid "I'll drink for the both of us."

            $ show_character("ellie")
            ellie "See you tomorrow."
            $ hide_character()

            jump ch1_scene1_turn_in

label ch1_scene1_ingrid_diamond_scene:

    stop music
    $ ch1_ingrid_scene = True
    play music "audio/bachata.mp3" # FIND AUDIO FOR THIS TODO

    $ show_character("ingrid", "happy")
    ingrid "Hell yeah, [Wheeler]!"
    $ ingrid_relationship += 2
    $ notify_relationship_point("+INGRID")

    $ show_character("ellie", "happy")
    ellie "It's {i}Agent{/i} [Wheeler] now."

    $ show_character("ingrid", "happy")
    ingrid "Well, {i}Agent{/i}... I say we throw out our metaphorical spy training wheels with a little game of Lie Detector."

    $ show_character("ellie")
    ellie "Oof, we haven't played that since college."

    $ show_character("ingrid", "happy")
    ingrid "Are you chickening out?"

    $ show_character("ellie", "happy")
    ellie "Never."
    $ hide_character()

    "You and Ingrid take a couple of bottles from the deserted bar and move on to the sitting area."

    $ show_character("ellie")

    menu:
        ellie "(I'll take the...)"

        "Vodka":
            $ ch1_drink = "vodka"
            $ hide_character()
            "Ingrid grabs the whiskey bottle and takes a swig."

        "Whiskey":
            $ ch1_drink = "whiskey"
            $ hide_character()
            "Ingrid grabs the vodka bottle and takes a swig."

        "Water":
            $ ch1_drink = "water"
            $ show_character("ingrid", "sad")
            ingrid "Seriously?"
            
            $ show_character("ellie", "happy")
            ellie "One of us needs to be responsible."

            $ show_character("ingrid", "happy")
            ingrid "Happy to delegate that to you."
            $ hide_character()

            "Ingrid grabs the vodka bottle and takes a swig."

    scene nightclub vip at right_to_left

    $ show_character("ingrid")
    ingrid "Let's agree on the rules first."
    $ show_character("ingrid", "happy")
    ingrid "We don't need another drunk argument about why your rules suck."

    $ show_character("ellie", "happy")
    ellie "My rules are perfect, thank you very much."
    $ show_character("ellie")
    ellie "Alright, so we take turns saying something about yourselves and the other needs to decide if it's true or a lie."

    $ show_character("ingrid")
    ingrid "We can ask one follow-up question."

    $ show_character("ellie")
    ellie "Fine. But it needs to be a yes or no question. And you can't lie on the follow up question."

    $ show_character("ingrid", "happy")
    ingrid "You always play on hard mode, don't you?"
    $ show_character("ingrid")
    ingrid "If we're using that rule then we can only say stuff about our time as G.A.I.A. trainees."

    $ show_character("ellie")
    ellie "Works for me."

    $ show_character("ingrid", "happy")
    ingrid "I'll start."
    ingrid "Don't judge me but..."
    $ show_character("ingrid", "neutral")
    ingrid "I once blew my cover at a training exercise because of a cat."
    $ hide_character()

    "She looks at you expectantly."

    $ mission_current_value = 0
    $ mission_required_value = 3
    $ achievement_success_title = "LIE DETECTOR"
    $ achievement_success_text = "You won the Lie Detector game!"
    $ achievement_failure_title = "COLD HARD TRUTH"
    $ achievement_failure_text = "You lost the Lie Detector game!"

    $ show_character("ellie")
    ellie "(Ingrid has always been very good at blending in. I don't remember her ever blowing her cover.)"
    ellie "(But I never did see all her training exercises.)"
    ellie "Interesting..."
    
    menu:
        ellie "Follow up question..."

        "Did you meow back at the cat?":
            $ hide_character()
            "You watch her jaw tense for the briefest second, as if she's contemplating lying to you."

            $ show_character("ellie")
            ellie "Don't even think about breaking the \"can't lie on follow up question\" rule."

            $ show_character("ingrid")
            ingrid "... Yes. Yes, I did meow back."
            $ meow_back = True

        "Did the cat physically compromise your disguise?":
            $ hide_character()
            $ meow_back = False
            $ show_character("ingrid")
            ingrid "Like scratch out my clothes or something?"
            $ show_character("ingrid", "happy")
            ingrid "No."
    
    $ show_character("ellie", "happy")
    menu: 
        ellie "I think you're..."

        "Telling the truth.":
            $ show_character("ingrid", "happy")
            if meow_back:
                ingrid "As if you didn't know exactly what you were doing when you asked me if I meowed back."
            
            $ mission_current_value += 1
            $ show_point_gained("+LIE DETECTOR")
            ingrid "You know me too well."

            $ hide_character()
            "Ingrid takes another sip of her bottle."

        "Lying.":
            if meow_back:
                $ show_character("ingrid", "surprised")
                ingrid "Really?"
                ingrid "I thought you had me figured out for sure with that question about meowing."
            
            $ show_character("ingrid", "happy") 
            $ show_point_gained("-LIE DETECTOR")
            ingrid "Drink up, partner."

            $ show_character("ellie", "surprised")
            ellie "Wait really?"
        
    $ show_character("ellie", "surprised")
    ellie "How did I never hear about this?"

    $ show_character("ingrid", "happy")
    ingrid "Because I bribed the only witness to that spectacular lapse."
    $ show_character("ingrid")
    ingrid "It was a trailing mission."
    ingrid "I was following my target, living my best Phantom-in-training life."
    ingrid "And then there's this cat on a bench a couple feet away from me."
    $ show_character("ingrid", "happy")
    ingrid "It meows at me. I meow back. Anyone would have meowed back, it's the polite thing to do."
    ingrid "The target heard me and that was the end of it."
    $ show_character("ingrid", "happy")
    ingrid "Fortunately [AgentJones] wasn't too disappointed. [jones_pronoun_she!c] was too busy doubling over laughing."

    $ show_character("ellie", "happy")
    ellie "Why would you meow back? You're usually so focused."

    $ show_character("ingrid", "surprised")
    ingrid "It was reflexive!"
    $ show_character("ingrid", "happy")
    ingrid "It's what I do with my cat."
    $ ch1_ingrid_cat = True

    $ show_character("ingrid", "happy")
    ingrid "Your turn, [Ellie_nickname!c]."

    $ show_character("ellie")
    ellie "Let me think..."

    menu:
        ellie "(I should tell her a...)"

        "Lie.":
            $ show_character("ellie", "happy")
            ellie "One time I tried to intimidate a target but ended up taking them on a date instead."
            
            if ch1_trail_jones_bartender:
                $ show_character("ingrid", "happy")
                ingrid "You would."

                $ show_character("ellie", "happy")
                ellie "Is that your final answer?"

                $ show_character("ingrid", "happy")
                ingrid "Nuh uh, I have my follow-up question and I intend on using it."

            $ show_character("ingrid")
            ingrid "Let's see..."
            ingrid "Did you hook up with them after the date?"

            $ show_character("ellie", "neutral")
            ellie "No, I didn't."
            
            $ show_character("ingrid", "happy")
            ingrid "You only take people on dates if you're going to hook up with them after. Or if you're in a relationship. And you haven't been in a relationship since, what, high school?"
            $ show_point_gained("-LIE DETECTOR")
            ingrid "So you're lying. Final answer."
            $ hide_character()

            "You sigh and take a sip."

            $ show_character("ellie")
            ellie "You got me."
            $ show_character("ellie", "happy")
            ellie "I did butcher that intimidation, but we never went on a date."

        "Truth.":

            $ show_character("ellie", "happy")
            ellie "One time I tried to intimidate a target but they ended up flirting with me instead."

            $ show_character("ingrid", "surprised")
            ingrid "You weren't the one flirting?"

            $ show_character("ellie", "happy")
            ellie "Nope."
            ellie "And you just wasted your follow-up question."

            $ show_character("ingrid", "surprised")
            ingrid "Wait, no--"

            $ show_character("ellie", "happy")
            ellie "Tsk... Follow the rules, Delaney."
            
            $ show_character("ingrid", "happy")
            ingrid "You're the worst."
            ingrid "You know what? You're bullshitting me."
            ingrid "This is a lie, final answer."

            $ show_character("ellie", "happy")
            if ingrid_codename_barfie:
                ellie "Take a sip, Barfie."
            else:
                ellie "Take a sip."
            
            $ show_point_gained("+LIE DETECTOR")
            $ mission_current_value += 1

            $ hide_character()
            "She takes a sip."

    $ show_character("ingrid", "surprised")
    ingrid "What? How? What happened?"
    $ hide_character()

    $ show_character("ellie", "neutral")
    ellie "You know that death glare that [AgentGrey] has?"
    ellie "I was going for that but apparently it was more of a smoldering gaze."
    $ show_character("ellie", "happy")
    ellie "They really got the wrong idea."
    $ hide_character()

    "Ingrid snorts."

    $ show_character("ingrid", "happy")
    ingrid "What was your glare like?"

    $ show_character("ellie", "happy")
    menu:
        ellie "Let me show you..."

        "{image=heart_ingrid} [[Look her straight in the eye.]":
            $ hide_character()
            "You try to channel your inner [AgentGrey] [Grey] just like you did in training."
            "But when your eyes meet hers your gaze shifts to something else. Not a glare, but not a stare either - more like a slow burn."
            "You feel the tension settling in as she leans forward and visibly swallows."
            $ show_character("ingrid")
            $ ingrid_romance += 1
            ingrid "..."

        "[[\"Glare\" at the bottle]":
            $ hide_character()
            "You try to channel your inner [AgentGrey] [Grey] just like you did in training."
            "The [ch1_drink] bottle seems as unimpressed by your glare as your last victim."
    
    $ show_character("ingrid", "surprised")
    ingrid "I don't know, seems pretty intimidating to me."

    if ch1_trail_jones_bartender and ingrid_flirt:
        $ show_character("ingrid", "happy")
        ingrid "Did you \"intimidate\" the bartender?"

        $ show_character("ellie", "happy")
        menu:
            ellie "You're very focused on that..."

            "{image=heart_ingrid} Almost seems like you're jealous.":
                $ show_character("ingrid")
                ingrid "In your dreams."
                $ show_character("ingrid", "surprised")
                ingrid "I'm just curious how you do it."

                $ show_character("ellie", "happy")
                ellie "Purely educational, huh?"

                $ show_character("ingrid", "surprised")
                ingrid "Yes. Exactly. Educational."
                ingrid "Purely intelectual curiosity."
                $ ingrid_romance += 1
                $ show_character("ingrid")
                ingrid "... I'm going to stop talking now."

            "I can introduce you, if you want.":
                $ show_character("ingrid")
                ingrid "Hard pass."

                $ show_character("ellie")
                ellie "Suit yourself."

    $ show_character("ellie")
    ellie "It's your turn now."

    $ show_character("ingrid", "surprised")
    ingrid "Right!"
    $ show_character("ingrid")
    ingrid "Ok, I got one..."
    $ hide_character()
    "Ingrid {color=[highlight]}hesitates{/color} for the briefest second before cracking a smile."
    $ show_character("ingrid", "happy")
    ingrid "Last year's VR simulated exam, I reprogrammed it to skip the hard parts but I was caught and they gave me a zero for that."

    $ show_character("ellie")
    ellie "I remember you failing that exam."

    $ show_character("ingrid", "happy")
    ingrid "I remember you acing that exam."

    $ show_character("ellie")

    menu:
        ellie "Tell me..."

        "Did you only reprogram it to skip the hard parts?":
            $ show_character("ingrid", "happy")
            ingrid "As if you'd think any part was hard."
            ingrid "But yes, just the hard parts."

        "Did you really cheat on the exam?":
            $ show_character("ingrid")
            ingrid "One hundred percent."
            $ show_character("ingrid", "surprised")
            ingrid "I mean. {i}Allegedly{/i}. Don't quote me on that."

    $ show_character("ellie")
    ellie "Hm..."

    menu: 
        ellie "I think it's..."

        "True":
            $ show_character("ingrid", "happy")
            ingrid "You think I'd fail a rigged exam?"
            ingrid "No, honey, it's worse than that."

        "A lie":
            $ show_character("ingrid", "happy")
            ingrid "Bingo!"
            $ show_point_gained("+LIE DETECTOR")
            $ mission_current_value += 1
    
    $ show_character("ingrid")
    ingrid "I did cheat on the exam and I did reprogram it to skip the hard parts but I wasn't caught."
    ingrid "I failed because I forgot to save the recording."
    $ show_character("ingrid", "happy")
    ingrid "Don't even think about laughing, [Wheeler]! I already got enough bullying from Vivian."
    $ hide_character()

    "The two of you go back and forth trading stories..."

    scene nightclub vip at left with fade

    $ show_character("ellie", "happy")
    ellie "I thought I picked up the right briefcase but it turned out to be a record player."
    $ hide_character()

    scene nightclub vip at left with fade

    $ show_character("ingrid", "happy")
    ingrid "Oh my God, one time I got the codeword wrong and then I made up an acronym on the spot to cover it up."
    $ hide_character()

    scene nightclub vip at left with fade

    "... Until the bottles are empty."

    $ won_game = completed_mission(mission_required_value, mission_current_value,
                                    achievement_success_title, achievement_success_text,
                                    achievement_failure_title, achievement_failure_text)

    if won_game:
        $ show_character("ingrid", "happy")
        ingrid "Damn, you really destroyed me at this."
        $ ingrid_relationship += 2
        $ notify_relationship_point("+INGRID")
        ingrid "Name your prize."
        
        $ show_character("ellie", "happy")
        ellie "How about I pick your codename?"

        if ingrid_codename_barfie:
            ellie "I'm sure I can come up with something better than Barfie."

            $ show_character("ingrid")
            ingrid "I'm sure you can come up with something {i}worse{/i}."

        $ show_character("ingrid")
        ingrid "You're the winner. I'll allow it."

        $ show_character("ellie", "happy")

        menu:
            ellie "In that case, I'll name you..."

            "Pink Panther":
                $ hide_character()
                "Ingrid stares at you."

                $ show_character("ellie")
                ellie "You don't like it?"
                ellie "I thought it was on theme with the hair and the meowing at cats."

                $ hide_character()

                "Ingrid throws back her head in a laugh."

                $ show_character("ingrid", "happy")
                ingrid "I wasn't complaining."
                $ ingrid_relationship += 2
                $ notify_relationship_point("+INGRID")
                ingrid "It's actually one of my favorite movies."

                $ ingrid_codename = "Pink Panther"

            "Blush Bruiser":
                $ show_character("ingrid")
                ingrid "I suppose it could be worse."

                $ show_character("ellie", "happy")
                if ingrid_codename_barfie:
                    ellie "I can always go back to Barfie."

                    $ show_character("ingrid", "surprised")
                    ingrid "No, thank you."

                else:
                    ellie "You're welcome."

                $ ingrid_codename = "Blush Bruiser"
            
            "{image=heart_ingrid} Aphrodite":
                $ hide_character()
                "Ingrid blinks."

                $ show_character("ingrid")
                ingrid "Like... The goddess of love?"

                $ show_character("ellie", "happy")
                ellie "And beauty."

                $ show_character("ingrid", "neutral")
                ingrid "..."
                $ show_character("ingrid", "happy")
                $ ingrid_romance += 1
                $ ingrid_codename = "Aphrodite"
                ingrid "Maybe losing my crown as Lie Detector champion wasn't all that bad."

    else:
        $ show_character("ingrid", "happy")
        ingrid "And I am still the reigning champion of Lie Detector."
        ingrid "Can I pick my prize?"

        $ show_character("ellie")
        ellie "I'm going to regret this, but sure."

        $ show_character("ingrid", "happy")
        ingrid "I get to choose your codename."

        if ingrid_codename_barfie:
            $ show_character("ellie", "happy")
            ellie "Fair enough, Barfie."
        else:
            $ show_character("ellie", "surprised")
            ellie "Oh no--"
        
        $ ellie_codename = "Flynn Rider"
        $ show_character("ingrid", "happy")
        ingrid "I now dub thee [ellie_codename]."
        $ show_character("ingrid")
        ingrid "Because of the smolder."

        $ show_character("ellie", "happy")
        ellie "Of course."

    $ show_character("ingrid", "happy")
    ingrid "This was fun."
    $ ingrid_relationship += 2
    $ notify_relationship_point("+INGRID")
    ingrid "We should do this more often."

    $ show_character("ellie", "happy")
    ellie "Agreed."

    $ show_character("ellie")
    ellie "But it's enough for tonight."
    ellie "I'm beat. I think I'll just go home."

    if ch1_drink is not "water":
        $ show_character("ingrid")
        ingrid "Alright... Be safe on the way back."
    else:
        $ show_character("ingrid")
        ingrid "Already?"
        ingrid "Well, you are the responsible one. I'll call it a night too."

    $ show_character("ellie")
    ellie "See you tomorrow."

    jump ch1_scene1_turn_in

label ch1_scene1_turn_in:
    if renpy.music.get_playing("music") != "audio/TPA/default chill.mp3":
        play music "audio/TPA/default chill.mp3" fadein 1.0

    scene hallway apartment at center with dis

    "You leave the club and head on home to your apartment."

    scene apartment night at center with dis

    "You change into your comfy pajamas and plop down on the living room couch with a sigh."

    $ change_ellie_outfit("pjs", 1)
    $ show_character("ellie")
    ellie "(I should take a look at the case file...)"
    $ hide_character()

    show screen item("file_secret", "The case file")
    $ regular = False
    $ bottom = True
    menu:
        with dis
        "Let's see what we have here...":
            $ bottom = False
            $ regular = True
            hide screen item

    $ nvl_mode = "lore"
    hide screen settingsUI
    hide screen suave_and_serious_points

    lore "{cps=0}{b}Debrief Report: Operation Velvet Jackals{/b}{p=0}{p}{b}Classification: TOP SECRET – AUTHORIZED PERSONNEL ONLY {/b}{p=0}{p}{b}Mission Overview{/b}: Intel confirms the existence of a high-tier criminal cell, codenamed Velvet Jackals, responsible for a wave of coordinated luxury vehicle thefts across the United States of America. Their targets include brands such as Bentley, Lamborghini, Bugatti, and bespoke Rolls-Royce models, as well as up-and-comer luxury electry vehicles brand Halo. The crew demonstrates precision logistics, minimal traceable signatures, and a deep understanding of international fencing networks.{p=0}{p}{b}Modus Operandi{/b}: Surveillance begins weeks in advance using drones masked as delivery devices. Theft operations conducted in less than 3 minutes per vehicle, often during diplomatic receptions or luxury expos. Vehicles are retrofitted with new VINs, then sold to private collectors in regions with weak extradition treaties."
    nvl clear
    show screen settingsUI
    show screen suave_and_serious_points
    hide screen nvl

    $ show_character("ellie", "sad")
    ellie "(Of course my first official mission would have something to do with grand theft auto.)"
    $ hide_character()

    "You continue to read the debrief."

    hide screen settingsUI
    hide screen suave_and_serious_points

    lore "{cps=0}{p}{b}Mission Objectives:{/b}{p}1. Conduct reconnaissance at upcoming New York Auto Show — crew may target prototype reveals.{p}2. Engage local contacts to identify luxury garages with suspicious modification records."

    lore "{cps=0}{p=0}{p}{b}Known Crewmembers:{/b}{p=0}{p}- “Ghost” (Leader): Former Automotive engineering or mechanics background. Orchestrates timing and routes; maintains anonymity even among crew.{p}- “Silk” (Infiltrator): Expert in bypassing biometric and RFID security systems. Known to wear high-end fashion to blend in with elite circles.{p}- “Torque” (Wheelman): Drives stolen vehicles to secure drop points. Known for high-speed evasion, often using underground tunnels and blind zones.{p}- “Pixel” (Tech): Disrupts CCTV, GPS, and license plate tracking with signal jammers and cloned chipsets. Allegedly wrote custom software that mimics dealership maintenance routines.{/cps}"

    hide screen nvl
    nvl clear
    show screen settingsUI
    show screen suave_and_serious_points

    "You turn to the last page of the document to find the attached photos of the crew."

    "Most of them are very low resolution surveillance images of speeding cars with the drivers barely visible."

    "One of the photos catches your eye."

    "Despite the low resolution, you can make out the features of the man behind the wheel."

    jump logan_character_selection

label logan_character_selection:
    tutorial "Who do you see in the photo?"
    call screen race_logan with dissolve

    $ logan_mood = "happy"
    show big logan with dissolve:
        pos(0, 0)
        zoom 1.0
    show item chosen with dissolve
    pause 2.0
    hide item chosen with dissolve

    hide big logan with dissolve

    jump ch1_rod_flashbacks

label ch1_rod_flashbacks:
    stop music
    play music "audio/TPA/chill downtime.mp3"

    "You squint at the photo."
    "{color=[highlight]}Torque{/color}. The Wheelman."

    $ show_character("ellie", "surprised")
    ellie "(No, it can't be...)"
    $ hide_character()

    scene parking school day sepia at left with fade
    "You close your eyes, remembering how you met him a decade ago."

    "Senior year of highschool. You ran into him and fell down, your books spread all over the place."

    "He looked down at you with a crooked eyebrow. You remember your annoying rich schoolmate - Brent - making some sort of comment that got you all red in embarassment."

    "He offered you a hand to pull you back to your feet."

    $ show_character("logan", modifier="young")
    logan "You know, there are easier ways to get my attention."
    $ hide_character()

    scene apartment night at center

    $ show_character("ellie", "surprised")
    ellie "(It's him...)"
    ellie "(It's {color=[highlight]}Logan{/color}...)"
    $ hide_character()
    $ persistent.spoilers = True

    #jump title_cutscene
    jump title_screen_for_demo

label chapter1_after_title_cutscene:

    v "Chapter 1: [ch1_title]"

    #jump end_of_demo
    jump ch1_rod_setup_logan

label ch1_rod_setup_logan:
    stop music
    play music "audio/TPA/chill downtime.mp3"
    show screen suave_and_serious_points
    show screen settingsUI

    scene apartment night at center with dissolve

    tutorial "Some choices will determine [Ellie]'s past within the Ride or Die storyline."

    $ show_character("ellie", "surprised")
    ellie "The {color=[highlight]}Mercy Park Crew{/color}... I haven't thought about them in a while."
    $ hide_character()

    "More like you haven't wanted to think about them in a while."
    "Your mind flashes to Logan once again."

    $ show_character("ellie")
    menu:
        ellie "(Logan was...)"

        "My first kiss.":
            $ ellie_young_first_kiss = "Logan"
            scene black with fade
            $ show_character("logan", modifier="young")
            logan "Okay, watch my feet. Gas... brake... and clutch pedals. And this lever between us is the gear shift."
            $ show_character("ellie")
            ellie "(He was so much more experienced than me...)"

        "Sketchy.":
            $ hide_character()
            scene black with fade
            $ show_character("logan", modifier="young")
            logan "Sorry I'm late. I had some business to handle, and there was trouble with... the logistics."
    
    $ hide_character()
    scene apartment night at center with dissolve
    $ show_character("ellie")
    ellie "(He taught me how to drive.)"

    $ hide_character()
    scene black with fade
    $ show_character("logan", modifier="young")
    logan "Okay, watch my feet. Gas... brake... and clutch pedals. And this lever between us is the gear shift."
    $ show_character("logan", "happy", modifier="young")
    logan "{i}...It's now or never, [Ellie_nickname]. Do you trust me?"
    $ hide_character()

    scene apartment night at center with dissolve
    $ show_character("ellie")
    ellie "(Driving with the crew was the most free I ever felt in my life.)"
    ellie "(That's what made me accept the recruitment offer from G.A.I.A. To feel that adrenaline again.)"

    $ show_character("ellie", "sad")
    ellie "(But he only got close to me because of my father. He was investigating them.)"
    $ hide_character()
    
    scene black with fade
    $ show_character("logan", "sad", modifier="young")
    logan "Let me be honest for once. Whether you believe me or not... whether you forgive me or not... please at least let me explain."
    $ hide_character()

    scene apartment night at center with dissolve
    $ show_character("ellie", "sad")     

    menu:
        ellie "(Logan was using me.)"

        "I never forgave him for it.":
            $ logan_young_forgiven = False
            $ show_character("ellie", "angry")
            ellie "(I can't believe he's still out there pulling the same stuff he pulled with me.)"
            
            pass
        "I forgave him for it.":
            $ logan_young_forgiven = False
            $ show_character("ellie", "sad")
            ellie "(I thought he might have stopped after all that happened.)"

            $ hide_character()
            tutorial "The next question will determine your past relationship with Logan."

            $ show_character("ellie", "sad")
            menu:
                ellie "(I was in love with...)"

                "{image=heart_logan} Him.":
                    $ ellie_prom = "Logan"
                    $ ellie_prom_love = True

                    $ hide_character()
                    scene hotel suit sepia at left with fade
                    $ show_character("logan", modifier="young")
                    $ my_notify_func("gui/notify.png", "A BAD BOY ROMANCE", f"You went to prom with Logan!")
                    logan "How did I survive before I knew you?"
                    logan "I was a fool to think I could stay away from you, [Ellie_nickname]."
                    logan "I already told you how I feel. I love you, [Ellie_nickname]."
                    $ hide_character()
                    scene apartment night at center with fade

                "Someone else.":
                    $ show_character("ellie")
                    ellie "(I think he might have had a crush on me.)"

    $ show_character("ellie", "angry")
    ellie "(I need to find him.)"

    $ hide_character()
    "You glance at the time."

    $ show_character("ellie")
    ellie "(It's late. Logan will have to wait until tomorrow.)"

    if ch1_drink:
        if ch1_drink != "water":
            ellie "(Besides I'm in no state to drive after drinking a whole bottle of [ch1_drink].)"

    $ hide_character()
    "You make your way to bed."
    "You dream of the Mercy Park Crew and what became of them. When morning finally comes, you know exactly where to start looking."

    "You pick up your phone and dial the number. It rings three times before a voice comes through."

    $ show_character("officer", modifier="holo")
    officer "Los Angeles State Women's Penitentiary, what can we do for you?"

    $ show_character("ellie")
    ellie "Good morning."
    ellie "I need to schedule a visit with one of your inmates."

    $ hide_character()
    scene black with dissolve
    pause 1.5
    
    jump ch1_scene2