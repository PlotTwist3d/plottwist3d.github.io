label start:
    #jump chapter1_scene_test
    $ current_chapter = 1
    $ playing_from_beginning = True
    $ setup_complete = False
    $ center_voice = "TUTORIAL"
    scene black with fade
    show screen settingsUI
    #jump customization_end
    
    play music "audio/TPA/spy theme.mp3" fadein 1.0

    #show driving bg animation
    #show car driving animation

    "Wake up, Rookie."
    "It's show time. Hope you remember the debrief we gave you."
    "Let me ask you a couple of questions, just to be safe."

    scene blur summer background with dissolve
    
    jump jones_customization

label jones_customization:
    $ who_old = "TUTORIAL"

    $ bottom = False
    $ middle = True
    $ shuffle_choices = True
    menu:
        tutorial "What are your target's pronouns?"

        "She/her":
            $ middle = False
            $ jones_pronoun_she = "she"
            $ jones_pronoun_her = "her"
            $ jones_pronoun_pos_her = "her"
            $ jones_pronoun_pos_hers = "hers"
            $ jones_herself = "herself"
            $ jones_partner = "girlfriend"
            $ jones_daughter = "daughter"
            $ jones_race = 1

        "He/him":
            $ middle = False
            $ jones_pronoun_she = "he"
            $ jones_pronoun_her = "him"
            $ jones_pronoun_pos_her = "his"
            $ jones_pronoun_pos_hers = "his"
            $ jones_self = "himself"
            $ jones_partner = "boyfriend"
            $ jones_daughter = "son"
            $ jones_race = 1

        "They/them":
            $ middle = False
            $ jones_pronoun_she = "they"
            $ jones_pronoun_her = "them"
            $ jones_pronoun_pos_her = "their"
            $ jones_pronoun_pos_hers = "theirs"
            $ jones_herself = "themselves"
            $ jones_partner = "significant other"
            $ jones_daughter = "child"
            $ jones_race = 1

    jump jones_character_selection

label jones_character_selection:
    #hide big jones hap with dissolve
    $ jones_mood = "neutral"

    scene blur summer background
    v "Choose your target's body type..."
    call screen body_jones with dissolve
    $ jones_mood = "happy"
    if jones_body == 2:
        $ jones_female = False
    else:
        $ jones_female = True
        
    show big jones with dissolve:
        pos(0, 0)
        zoom 1.0
    show item chosen with dissolve
    pause 2.0
    hide item chosen with dissolve
    hide big jones with dissolve
    $ jones_mood = "neutral"

    v "Choose your target's face..."
    call screen race_jones with dissolve
    $ jones_mood = "happy"
    show big jones with dissolve:
        pos(0, 0)
        zoom 1.0
    show item chosen with dissolve
    pause 2.0
    hide item chosen with dissolve
    hide big jones with dissolve
    $ jones_mood = "neutral"

    v "Choose your target's hair..."
    call screen hair_jones with dissolve
    scene blur summer background

    $ jones_mood = "happy"
    show big jones with dissolve:
        pos(0, 0)
        zoom 1.0
    show item chosen with dissolve
    pause 2.0
    hide item chosen with dissolve
    #hide big jones with dissolve
    #$ jones_mood = "neutral"

    $ quick_menu = True

    $ AgentJones = renpy.input("Enter [jones_pronoun_pos_her] first name.", length=11, default="Elliot")
    
    if not AgentJones:
        $ AgentJones = "Elliot"

    $ AgentJones = AgentJones.strip()

    $ capsAgentJones = AgentJones.upper() 

    $ Jones = renpy.input("Enter [jones_pronoun_pos_her] last name.", length=11, default="Jones")

    if not Jones:
        $ Jones = "Jones"

    $ capsJones = Jones.upper()

    $ jones_mood = "happy"
    show big jones with dissolve:
        pos(0, 0)
        zoom 1.0
    show item chosen with dissolve
    pause 2.0
    hide item chosen with dissolve
    #hide big jones hap with dissolve

    $ bottom = True
    $ middle = False
    menu:
        with dis
        b "Is this Agent [AgentJones] [Jones]?"
        "Yes!":
            hide big jones with dissolve
            jump grey_customization
        "No, let me think again...":
            hide big jones with dissolve
            jump jones_customization
        

    #jump grey_customization

label grey_customization:
    $who_old = "NOT VOICE"

    $ bottom = False
    $ middle = True
    menu:
        "Who is your target meeting? It's a..."

        "Woman":
            $ middle = False
            $ grey_female = True
            $ grey_pjs = 1
            $ grey_pronoun_she = "she"
            $ grey_pronoun_her = "her"
            $ grey_pronoun_pos_her = "her"
            $ grey_pronoun_pos_hers = "hers"
            $ grey_herself = "herself"
            $ grey_partner = "girlfriend"
            $ grey_daughter = "daughter"
            $ grey_race = 1
            jump grey_character_selection

        "Man":
            $ middle = False
            $ grey_female = False
            $ grey_pjs = 2
            $ grey_pronoun_she = "he"
            $ grey_pronoun_her = "him"
            $ grey_pronoun_pos_her = "his"
            $ grey_pronoun_pos_hers = "his"
            $ grey_herself = "himself"
            $ grey_partner = "boyfriend"
            $ grey_daughter = "son"
            $ grey_race = 1
            jump grey_character_selection

label grey_character_selection:
    #hide big grey hap with dissolve
    v "Choose Agent Gray's face..."
    call screen race_grey with dissolve
    scene blur summer background
    $ quick_menu = True

    $ grey_mood = "happy"
    show big grey with dissolve:
        pos(0, 0)
        zoom 1.0
    show item chosen with dissolve
    pause 2.0
    hide item chosen with dissolve

    if grey_female:
        $ AgentGrey = renpy.input("Enter her first name.", length=11, default="Samara")
    else:
        $ AgentGrey = renpy.input("Enter his first name.", length=11, default="Callum")

    if not AgentGrey:
        if grey_female:
            $ AgentGrey = "Samara"
        else:
            $ AgentGrey = "Callum"

    $ AgentGrey = AgentGrey.strip()

    $ capsAgentGrey = AgentGrey.upper()

    $ Grey = "Gray"

    $ capsGrey = Grey.upper()

    "Agent [AgentGrey] Gray, that's right. One more thing..." 
    
    $ bottom = True
    $ middle = False
    menu:
        b "What is their relationship?"

        "[Jones] and [Grey] are partners.":
            $ jones_grey_dating = False

        "[Jones] and [Grey] are dating.":
            $ jones_grey_dating = True
            menu:
                b3 "What does [Grey] call [Jones]?"
                "Honey":
                    $ jones_darling = "honey"
                "Babe":
                    $ jones_darling = "babe"
                "Sweetheart":
                    $ jones_darling = "sweetheart"


    #hide big grey hap with dissolve

    $ bottom = True
    $ middle = False
    menu:
        b "Is this the taget's contact?"
        "Yes!":
            hide big grey with dissolve
            jump ellie_character_selection

        "No, let me think again...":
            hide big grey with dissolve
            jump grey_customization

label ellie_character_selection:
    #hide big jones hap with dissolve
    $ ellie_mood = "neutral"
    $ ellie_outfit_style = "casual"
    
    "Alright, you seem to have everything in order."

    "Don't forget to bring an appropriate outfit for the mission. Wouldn't want to stick out from the crowd too much."

    scene closet with dissolve
    v "Choose your face..."
    call screen race_ellie with dissolve

    $ ellie_mood = "happy"
    show big ellie undies with dissolve:
        pos(0, 0)
        zoom 1.0
    show item chosen with dissolve
    pause 2.0
    hide item chosen with dissolve
    hide big ellie undies with dissolve
    $ ellie_mood = "neutral"

    v "Choose your hairstyle..."
    call screen hair_ellie with dissolve
    #scene closet

    $ ellie_mood = "happy"
    show big ellie undies with dissolve:
        pos(0, 0)
        zoom 1.0
    show item chosen with dissolve
    pause 2.0
    hide item chosen with dissolve
    hide big ellie undies with dissolve
    $ ellie_mood = "neutral"

    v "Choose a tattoo. You may have to hide the panel to see them."
    call screen tattoo_ellie with dissolve
    #scene closet

    $ ellie_mood = "happy"
    show big ellie undies with dissolve:
        pos(0, 0)
        zoom 1.0
    show item chosen with dissolve
    pause 2.0
    hide item chosen with dissolve
    hide big ellie undies with dissolve
    $ ellie_mood = "neutral"

    v "Choose your outfit..."
    call screen outfit_ellie with dissolve
    #scene blur summer background

    $ ellie_mood = "happy"
    show big ellie with dissolve:
        pos(0, 0)
        zoom 1.0
    $ ellie_default_outfit = ellie_outfit # default casual outfit
    $ ellie_outfit_style = "casual"
    show item chosen with dissolve
    pause 2.0
    hide item chosen with dissolve
    hide big ellie with dissolve

    $ quick_menu = True

    $ Ellie = renpy.input("Enter your first name.", length=11, default="Eleanor")
    
    if not Ellie:
        $ Ellie = "Eleanor"

    $ Ellie = Ellie.strip()

    $ capsEllie = Ellie.upper() + " "

    $ Wheeler = renpy.input("Enter your last name.", length=11, default="Wheeler")

    if not Wheeler:
        $ Wheeler = "Wheeler"

    $ capsWheeler = Wheeler.strip().upper()

    tutorial "Enter your nickname. If you don't want a nickname enter the same as your first name."

    $ Ellie_nickname = renpy.input("Enter your nickname.", length=11, default="Ellie")
    
    if not Ellie_nickname:
        $ Ellie_nickname = "Ellie"

    $ Ellie = Ellie.strip()

    $ ellie_mood = "happy"
    show big ellie with dissolve:
        pos(0, 0)
        zoom 1.0
    show item chosen with dissolve
    pause 2.0
    hide item chosen with dissolve
    #hide big jones hap with dissolve

    $ bottom = True
    $ middle = False
    menu:
        with dis
        b "Is this you, [Ellie] [Wheeler]?"
        "Yes!":
            hide big ellie with dissolve
            jump customization_end

        "No, let me try again.":
            hide big ellie with dissolve
            jump ellie_character_selection
    
label customization_end:
    "Good luck, Agent [Wheeler]."
    
    if ellie_tattoo == 5 or ellie_tattoo == 6 or ellie_tattoo == 7:
        $ ellie_young_tattoo = True

    if ellie_tattoo == 0:
        $ ellie_no_tattoo = False
    else:
        $ ellie_no_tattoo = True

    if ellie_tattoo == 1 or ellie_tattoo == 2 or ellie_tattoo == 3:
        $ ellie_tattoo_flowers = True

    if ellie_tattoo == 1 or ellie_tattoo == 3 or ellie_tattoo == 4 or ellie_tattoo == 5:
        $ ellie_tattoo_visible = True

    stop music fadeout 1.0

    jump chapter1_scene1