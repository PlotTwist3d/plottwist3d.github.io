transform sepia:
    matrixcolor SepiaMatrix()

image serious_point_image = Transform("images/serious_point.png", zoom=0.5)
image suave_point_image = Transform("images/suave_point.png", zoom=0.5)

label chapter1_scene_test:
    ##initalizing chapter variables
    
    $ playable_character = "ELLIE"
    scene black with fade

    #"This book contains disturbing images, as well as depictions of violence and trauma. Reader discretion advised…"
    $who_old = "TUTORIAL"
    scene new york street night #at left with fade
    show screen settingsUI
    show screen suave_and_serious_points

    $who_old = "TUTORIAL"
    $center_voice = "TUTORIAL"
    tutorial "Now playing as [Ellie] [Wheeler]."
    $center_voice = "TUTORIAL"

    scene new york street night #at left_to_mid

    $ playing_as = capsEllie
    $ regular = True
    $ middle = False
    $ bottom = False

    
    mona "Say something."

    show mona
    mona "Say another thing."

    show ellie
    ellie "On the left."

    hide mona
    hide ellie

    $ playable_character = "MONA"
    $ playing_as = "MONA"

    tutorial "Now playing as Mona."

    show mona
    mona "I am the PC."
    hide mona

    show ellie
    ellie "I'm not the PC"
    hide ellie

    "The narrator doesn't need anything to work."

    $ show_character("mona", with_mood="happy")
    left_mona "I'm still the PC."

    $ show_character("ellie", modifier="NPC")
    right_ellie "I'm still not the PC."

    $ timeout_label = None
    $ middle = False
    $ bottom = False
    $ quick_menu = False

    menu:
        with dis
        ellie "This is a choice"
        "yeah [Ellie]":
            $ ellie_mood = "happy"
            $ suave_points += 1
            $ ssl("ellie")
        "yup [Ellie]":
            $ ellie_mood = "sad"
            $ serious_points += 1
            $ ssl("ellie")
        "Not an option [Ellie]" (suave=True, points=10):
            jump timeout_1

    ellie "idk man, seems funky"

    $ lr("ellie", "jones holo")
    jones_holo "Seems fine so far."

    $ jones_mood = "happy"
    $ ssr("jones")
    jones_holo "The kid's nuts."

label title_cutscene:
    $ hide_character()
    scene black with fade
    pause 0.2

    #stop music with fadeout 0.5
    stop sound

    play music "audio/TPA/spy theme.mp3" fadein 0.5

    hide screen settingsUI
    hide screen suave_and_serious_points
    show title_cutscene
    $ renpy.pause(9, hard=True)

    hide title_cutscene with fade
    pause 0.5
    
    show screen settingsUI
    show screen suave_and_serious_points

    $ renpy.jump("chapter" + str(current_chapter) + "_after_title_cutscene")

label title_screen_for_demo:
    $ hide_character()
    scene black with fade
    pause 0.2

    stop music fadeout 0.5
    stop sound

    play music "audio/TPA/spy theme.mp3" fadein 0.5

    hide screen settingsUI
    hide screen suave_and_serious_points

    scene main menu with dissolve
    pause 0.5

    $ renpy.jump("chapter" + str(current_chapter) + "_after_title_cutscene")

label end_of_chapter:
    hide screen settingsUI
    hide screen suave_and_serious_points
    
    stop music
    
    $ renpy.force_autosave()

    $ middle = True
    $ bottom = False

    $ disable_option = not (current_chapter < maximum_chapters)

    menu:
        v "You've reached the end of chapter [current_chapter]."
        "Next chapter.":
            $ renpy.jump("chapter" + str(current_chapter+1) + "_scene1")
            
        "Restart chapter [current_chapter]":
            $ restore_relationship_defaults()
            $ maximum_serious_points = maximum_serious_points_end_of_chapter
            $ maximum_suave_points = maximum_suave_points_end_of_chapter
            $ serious_points = serious_points_end_of_chapter
            $ suave_points = suave_points_end_of_chapter
            $ renpy.jump("chapter" + str(current_chapter) + "_scene1")
        "Restart game (skip setup)":
            jump chapter1_scene1
        "Restart game":
            jump start

label chapter5_scene1:
    jump end_of_chapter

label end_of_demo:
    hide screen settingsUI
    hide screen suave_and_serious_points

    tutorial "You've reached the end of the demo!"
    tutorial "Thank you for playing!"