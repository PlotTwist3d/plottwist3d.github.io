label ch2_scene3:
    $ show_character("colt", "happy")
    colt "Anybody want to take it for a spin?"

    $ maximum_suave_points += 1

    $ achievement_success_title = "SMOOTH OPERATOR"
    $ achievement_success_text = "You maintained your cover\nat the Auto Show!"

    $ achievement_failure_title = "YOU HAD ONE JOB"
    $ achievement_failure_text = "And it was literally just\npretending to be someone else."

    $ hide_character()
    "You attempt to hide behind Ingrid before Colt can notice you."

    $ ch2_maintained_cover = completed_mission(mission_required_value, mission_current_value)

    if ch2_maintained_cover:
        $ show_character("giorgio", "happy")
        giorgio "Ms. Levanov, please grace us with your driving skills!"

        $ show_character("silk", "happy")
        mathilda "I sure would appreciate a show."

    else:
        $ show_character("greer", "happy")
        greer "Hey Wannabe Driver! Why don't you give it a go?"
        greer "Try not to fall flat on your ass."

        $ hide_character()
        "Greer and his two sidekicks snicker."

    $ completed_mission(mission_required_value, mission_current_value,
                        achievement_success_title, achievement_success_text,
                        achievement_failure_title, achievement_failure_text)
    
    if ch2_maintained_cover:
        $ suave_points += 1

    $ show_character("ellie", "surprised")
    ellie "(Great... Exactly what I needed, everyone's attention on me.)"

    $ hide_character()
    "Colt looks your way, but if he recognizes you his expression doesn't give it away."

    $ show_character("colt")
    colt "How about it?"
    colt "Once you ride this beast you'll never want to ride anything else."

    $ show_character("ellie")
    ellie "I prefer cars."

    $ show_character("colt", "happy")
    colt "Yeah, you know {i}all{/i} about cars, don't you?"
    colt "Lucky for us we're also showcasing a new car model."

    $ hide_character()
    "He fixes you with a knowing look."

    $ show_character("colt")
    colt "Would you like to see it?"

    $ show_character("grey", modifier="holo")
    grey "You can't really afford to say no here."
    grey "Best case scenario you learn where they keep the prototypes stored."

    $ show_character("ellie", "surprised")
    ellie "(And worst case scenario my cover gets blown to smithereens. No big deal.)"

    $ hide_character()
    "Ingrid doesn't seem to catch on to your hesitance."

    $ show_character("ingrid", "happy")
    ingrid "Well, I'm interested in seeing the best you have to offer."
    ingrid "Come along, Irina. I'll need your expertise."

    if not ch2_maintained_cover:
        $ hide_character()
        "Greer and his cronies snort loudly at that."

    $ show_character("ellie")
    ellie "... Yes, boss."

    $ show_character("colt", "surprised")
    colt "That's great, Miss... huh...?"

    $ show_character("ingrid")
    ingrid "Lawrence."

    $ show_character("colt")
    colt "Ms. Lawrence."
    colt "Unfortunately, I can only take one person to see the prototypes. Security concerns, I'm sure you'll understand."

    $ show_character("ingrid", "sad")
    ingrid "Can't you make an exception for me, Mr...?"

    $ hide_character()
    "Colt pointedly ignores her attempt at getting his name. You almost breathe a sigh of relief."

    $ show_character("colt")
    colt "So, which one of you will see it first?"

    $ show_character("ingrid")
    ingrid "You go, Irina. If it's worthless then there's no use in me {color=[highlight]}wasting my time{/color}."
    ingrid "I expect a full report."

    $ hide_character()
    "You give Ingrid a small nod of understanding."

    $ show_character("ellie")
    ellie "Of course, ma'am."
    $ show_character("ellie", "surprised")
    ellie "(I don't know how she managed to give me a codephrase completely in character.)"
    $ show_character("ellie")
    ellie "(I've got this. I know what to do if I need backup.)"

    $ hide_character()
    "Colt motions for you to follow. You fall in step with him."
    "He shoots you a smug smile."

    $ show_character("colt", "happy")
    colt "{i}Irina{/i}, huh?"

    $ show_character("ellie")
    menu:
        ellie "..."

        "I didn't catch your name.":
            if ch2_maintained_cover:
                $ hide_character()
                "His smile faulters for a second, as if he really is considering the possibility of having mistaken the actual Irina Levanov for you."
                "He quickly recovers."

                $ colt_relationship -= 2
                $ show_character("colt")
                colt "I'm sure you know it."

            else:
                $ colt_relationship -= 2
                $ show_character("colt")
                colt "Don't play coy now."

            $ show_character("ellie")
            ellie "I don't know what you're talking about."
        
        "Colt.":
            $ show_character("ellie")
            ellie "Didn't expect to see you here."

            $ colt_relationship += 2
            $ show_character("colt", "happy")
            colt "You don't have to pretend you're not happy to see me."

    $ show_character("colt")
    colt "What's your angle here, [Ellie]?"

    $ hide_character()
    "A ripple of static in your comms reminds you that your team is still listening to every word of your conversation with Colt."

    $ show_character("ellie")
    menu:
        ellie "(I should...)"

        "Keep my comms on.":
            $ ch2_disable_comms = False
            
            $ show_character("ellie")
            ellie "(I'll be careful with what I say.)"
        
        "Turn my comms off.":
            $ ch2_disable_comms = True

            $ hide_character()
            "You brush a strand of hair behind your ear, smoothly turning off your comms in the process."

    $ show_character("ellie", "surprised")
    ellie "My angle? What's {i}yours{/i}?"
    ellie "I'm just here to look at cars and make fun of rich people."

    $ show_character("colt")
    colt "With a fake name that your boss definitely doesn't know about?"

    $ show_character("ellie")
    ellie "You're gonna snitch on me?"

    $ show_character("colt", "happy")
    colt "Depends. How much is she worth?"

    $ show_character("ellie", "surprised")
    ellie "(He thinks I'm conning Ingrid! I can work with this.)"

    $ show_character("ellie", "happy")
    ellie "Why, you want a cut of the money?"

    $ show_character("colt", "happy")
    colt "No, just curious."

    $ show_character("ellie")
    ellie "... No?"

    $ show_character("colt", "happy")
    colt "It's called growth, [Ellie_nickname]. You should try it."

    $ show_character("ellie")
    ellie "{i}Ha. Ha.{/i}"
    ellie "You didn't answer me. What's your angle, Colt?"

    $ show_character("colt", "happy")
    colt "Why, you want a cut of the money?"

    $ show_character("ellie")
    ellie "Hm, really can see the growth there."

    $ hide_character()
    "He guides you through an {i}Employees Only{/i} door."

    scene auto show security at mid_right

    $ show_character("ellie")
    ellie "Where are we?"

    $ show_character("colt")
    colt "Backstage. This is the security room."

    $ hide_character()
    "You glance at the security feed."

    if ch2_disable_comms:
        "You spot Ingrid on the lounge. She keeps brushing her hair behind her ear, clearly panicking that you don't seem to be responding to your comms."
    else:
        "You spot Ingrid on the lounge. See eyes the camera like she knows you're watching her."

    "Colt blocks your line of sight to the screens."

    $ show_character("colt", "happy")
    colt "Keeping an eye on your target?"

    $ show_character("ellie")
    menu:
        ellie "Maybe..."

        "{image=heart_colt} I'm keeping my eye on you.":
            $ hide_character()

            if not ch2_disable_comms:
                "You hear Ingrid snort through the comms."

                if ch2_string_logan_along:
                    $ show_character("ingrid", "happy", modifier="holo")
                    ingrid_holo "I see you intend to string everyone along."
                    $ hide_character()

                $ show_character("mona", modifier="bruised holo")
                mona_holo "Not even a gun to my head could make me flirt with Colt."

                $ hide_character()

            "He steps closer to you."

            $ colt_romance += 1

            $ show_character("colt", "happy")
            colt "Maybe you need to keep a closer look."
        
        "I am. Can you blame me?":
            $ hide_character()
            "He studies you for a moment."
            $ colt_relationship += 2
            $ show_character("colt")
            colt "... No. No, I can't."

        "You shouldn't be showing me this.":
            $ hide_character()
            "He snorts."

            $ show_character("colt", "happy")
            colt "You're worried about it now?"

            $ show_character("ellie")
            ellie "Some lines shouldn't be crossed, don't you think?"
            ellie "Right, I forgot. You're not above kidnapping and murder."

            $ colt_relationship -= 2
            $ show_character("colt")
            colt "Neither are you."

    $ show_character("ellie")
    ellie "Enough games. What do you want from me?"

    $ show_character("colt")
    colt "I agree, [Ellie]... Enough games."

    play music "audio/TPA/tense fight.mp3" fadein 0.5

    play sound "audio/SFX/sfx gun cock.mp3"

    $ hide_character()
    "You hear a metallic {i}click{/i}, that pulls your attention to the gun in his hand."
    "He points it at you, hands firm and finger on the trigger."

    $ show_character("colt")
    colt "Or should I call you... {color=[highlight]}Ghost{/color}?"
    
    jump ch2_end_stats

label ch2_end_stats:
    $ hide_character()
    scene black with fade

    pause 1.0

    $ center_voice = "CHAPTER STATS"

    play music "audio/TPA/spy theme.mp3" fadein 0.5

    if ch2_mona_scene:
        end_stats "You and Mona went to the beach."
    else:
        end_stats "You didn't let Mona out of the safehouse on her first day of freedom."

    if ch2_racer_outfit:
        end_stats "You selected an appropriate outfit for your undercover mission."
    else:
        end_stats "You decided to wing your mission at the Auto Show on your normal clothes."

    if ch2_auto_show_challenge:
        if ch2_simulator_win:
            end_stats "You accepted Fabien's challenge and won!"
        else:
            end_stats "You accepted Fabien's challenge but were defeated."

        if ch2_recruited_fabian:
            end_stats "You convinced Fabien to help you in the future."

    else:
        end_stats "You didn't take Fabien's challenge."

    if ch2_maintained_cover:
        end_stats "You maintained your cover story throughout the mission at the Auto Show."
    else:
        end_stats "The guests of the Auto Show were suspicious of you."

    end_stats "You found Colt at the Auto Show."

    end_stats "He accused you of being the leader of the Jackals and held you at gunpoint!"

    $ allies = "ALLIES\nIngrid ... Alive & Recruited\nMona ... Alive & Recruited"
    if ch2_recruited_fabian:
        $ allies += "\nFabien ... Recruited"

    end_stats "[allies]"

    end_stats "POINTS\n{color=[red]}SUAVE{/color} [suave_points] out of [maximum_suave_points]\n{color=[blue]}SERIOUS{/color} [serious_points] out of [maximum_serious_points]"

    $ center_voice = "TUTORIAL"

    jump end_of_chapter
