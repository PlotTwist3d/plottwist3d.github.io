label chapter2_scene1:
    ##initalizing chapter variables
    $ middle = False
    $ bottom = False
    $ regular = True
    $ current_chapter = 2
    $ playable_character = "ELLIE"
    $ playing_as = capsEllie

    # restore chapter defaults
    $ maximum_suave_points_end_of_chapter = maximum_suave_points
    $ maximum_serious_points_end_of_chapter = maximum_serious_points
    $ suave_points_end_of_chapter = suave_points
    $ serious_points_end_of_chapter = serious_points
    $ ch2_break_protocol = False
    $ ch2_mona_no_friends = False
    $ ch2_mona_doesnt_care = False
    $ ch2_mona_is_helping = False
    $ ch2_mona_i_will = False
    $ ch2_mona_scene = False
    $ ch2_ellie_flirt_with_mona_in_front_of_ingrid = False
    $ ch2_ellie_flirt_with_ingrid_in_front_of_mona = False
    $ ch2_mona_diamond_scene_someone_else = False
    $ ch2_mona_diamond_scene_casual_fun = False
    $ ch2_mona_diamond_scene_not_good = False
    $ ch2_mona_diamond_scene_saved_ellie = False
    $ ch2_mona_diamond_scene_have_a_chance = False
    $ ch2_mona_real_name = False
    $ ch2_auto_show_challenge = False
    $ ch2_maintained_cover = False
    $ ch2_racer_outfit = False
    $ ch2_mona_broken_trust = False
    $ ch2_auto_show_mingle = False
    $ ch2_auto_show_cars = False
    $ ch2_auto_show_race = False
    $ ch2_irina = False
    $ ch2_stunts = False
    $ ch2_mathilda_suave_point = False
    $ ch2_idiots = False
    $ ch2_thrill = False
    $ ch2_what_it_seems = False
    $ ch2_recruited_fabian = False
    $ ch2_lawrence = False
    $ ch2_dont_string_logan_along = False
    $ ch2_string_logan_along = False
    $ ch2_disable_comms = False
    $ change_mona_outfit(0, 0, False) # prison outfit
    $ change_ellie_outfit("casual", ellie_default_outfit)
    $ change_ingrid_outfit("casual", 1)
    $ save_relationship_system_scores()

    if renpy.music.get_playing("music") != "audio/TPA/spy investigate.mp3":
        play music "audio/TPA/spy investigate.mp3" fadein 1.0

    $ playable_character = "ELLIE"
    scene black with fade

    $ who_old = "MONA"
    scene safehouse basic at right with fade
    show screen location_title("los angeles text") with dissolve
    show screen settingsUI
    $ renpy.pause(2, hard=True)
    hide screen location_title with dissolve

    $who_old = "TUTORIAL"
    $center_voice = "TUTORIAL"
    show screen suave_and_serious_points
    tutorial "Now playing as [Ellie] [Wheeler]."
    $center_voice = "TUTORIAL"

    scene safehouse basic at right_to_mid_right

    $ playing_as = capsEllie

    $ change_mona_outfit(0, 0, jacket=False) # prison outfit

    $ maximum_serious_points += 1

    $ hide_character()
    "You and Ingrid go over the protocol while an unconscious Mona sleeps on the couch nearby."

    $ show_character("ingrid")
    ingrid "Remember, you can't let her out of your sight."
    ingrid "And you'll need this."

    $ hide_character()

    $ timeout_label = None
    show screen item("injection", "Injectable tracker")
    $ regular = False
    $ bottom = True
    $ middle = False
    menu:
        with dis
        "I'll take that.":
            $ bottom = False
            $ regular = True
            $ middle = False

    hide screen item

    $ show_character("ellie")
    ellie "Right."
    ellie "The tracker needs to be injected in the arm."

    $ show_character("ingrid")
    ingrid "I still don't think this is a good idea but we're way past the point of no return."

    $ show_character("ellie")
    ellie "We had to do it, Ingrid."
    ellie "We almost didn't get her out of there in time."

    $ hide_character()
    "You hear a rustle coming from the couch, and turn to see Mona fully awake."

    $ show_character("mona", modifier="bruised")
    mona "I had everything under control."

    $ hide_character()
    "Ingrid crosses her arms. She leans on the table, eyeing Mona."

    if ch1_mona_won_fight:
        $ my_notify_func("gui/notify.png", "PRISON BREAK", "Mona held her own during the fight!")
        $ serious_points += 1
        $ show_character("ingrid")
        ingrid "If it had been a fair fight you would've won."
        ingrid "It's what the COs said, at least."

        ingrid "You don't seem that impressive to me."

        $ hide_character()
        "Mona smirks at her."

        $ show_character("mona", "happy", modifier="bruised")
        mona "Sorry, you're not my type. Not really looking to impress you."

        if mona_flirt or ellie_prom == "Mona":
            $ hide_character()
            "You notice her eyes dart to you when she says it."

        $ show_character("ingrid", "surprised")
        ingrid "That wasn't-- I wasn't--"

        $ show_character("mona", "happy", modifier="bruised")
        mona "I think your friend is short-circuiting."

        $ show_character("ellie")
        ellie "Would you two knock it off?"
    
    else:
        $ my_notify_func("gui/notify.png", "PRISON BROKEN", "Mona was injured in the fight!")

        $ show_character("ingrid")
        ingrid "You were lucky you didn't get killed."
        ingrid "You'd think someone with a rap sheet like yours could throw a punch."

        $ show_character("mona", "angry", modifier="bruised")
        mona "I can throw a punch at you, Barbie."

        if ingrid_codename_barfie:
            $ show_character("ellie", "happy")
            ellie "It's Barfie, actually."

            if ingrid_codename:
                $ show_character("ingrid", "surprised")
                ingrid "Absolutely not."
                ingrid "Besides, you changed it to [ingrid_codename]."

                $ show_character("ellie", "happy")
                ellie "Of course, my mistake."

            elif ellie_codename:
                $ show_character("ingrid", "surprised")
                ingrid "Zip it, [ellie_codename]!"

            $ hide_character()
            "Mona eyes the two of you as if you're both crazy."
        
        else:
            $ show_character("ellie")
            ellie "I'm legally required to tell you that if you punch her--"

            $ show_character("mona", modifier="bruised")
            mona "Yeah, yeah. Back to jail."

            $ show_character("ellie")
            ellie "No, actually."
            ellie "She'll kill you before I get the chance to take you back."

        $ show_character("mona", "surprised", "bruised")
        mona "If this is Hell I have to say it's a lot more confusing than I expected."

        $ show_character("ellie")
        ellie "C'mon, Mona... I told you I'd pick you up."

    ellie "This is my partner, Ingrid."

    if ellie_prom == "Mona":
        $ show_character("mona", modifier="bruised")
        mona "... Like, from high school?"
        mona "You two had a whole... Vibe."

        $ show_character("ingrid")
        ingrid "Vibe?"

        $ show_character("mona", modifier="bruised")
        mona "Yeah. Like you wanted to get in [Ellie_nickname]'s pants."

        $ hide_character()
        "Ingrid's eyes go wide and you swear you hear her choke on nothing."

        $ show_character("ingrid", "surprised")
        ingrid "That's-- I did not!"

        if ingrid_flirt:
            $ hide_character()
            "But you notice the glance she sneaks your way."

    $ show_character("mona", modifier="bruised")
    mona "Great. So you two are my handlers?"

    $ show_character("ingrid")
    ingrid "Nope, that's all [Ellie]."

    $ show_character("mona", "happy", "bruised")
    mona "Oh, so just like the good old days!"

    $ hide_character()
    "You step towards Mona and she eyes you with suspicion. Her look catches on the syringe in your hand."
    "She bolts off the couch."

    $ show_character("mona", "angry", "bruised")
    mona "What the Hell are you doing?"

    $ show_character("ellie")
    ellie "It's standard procedure."

    $ show_character("mona", "angry", modifier="bruised")
    mona "You're here to finish the job, aren't you?"
    mona "Well, tough luck. There's only two of you and I'll kill you both."

    $ show_character("ellie", "surprised")
    ellie "(She thinks the fight was a {color=[highlight]}hit{/color}?)"

    #jump title_cutscene
    jump title_screen_for_demo

label chapter2_after_title_cutscene:
    v "Chapter 2: [ch2_title]"

    if renpy.music.get_playing("music") != "audio/TPA/spy investigate.mp3":
        play music "audio/TPA/spy investigate.mp3" fadein 1.0

    show screen suave_and_serious_points
    show screen settingsUI
    scene safehouse basic at mid_right

    $ hide_character()
    "You and Ingrid share a look."
    
    $ show_character("ingrid")
    ingrid "She's your problem. How do you want to do this?"

    $ show_character("ellie")
    menu:
        ellie "Fine. We'll..."

        "Restrain her.":
            $ ch2_break_protocol = False
            jump ch2_restrain_her
        "Let her be.":
            $ ch2_break_protocol = True
            jump ch2_let_her_be

label ch2_restrain_her:
    $ show_character("ingrid", "happy")
    $ ingrid_relationship += 2
    ingrid "My pleasure."

    $ hide_character()
    "You see Mona's body tense when Ingrid takes a purposeful step towards her. You can't miss the panic in her eyes."

    $ show_character("mona", "surprised", "bruised")
    $ mona_relationship -= 2
    mona "We had a deal!"

    $ show_character("ellie")
    ellie "We still do. But I need to get this tracker on you and you're being difficult."

    $ show_character("mona", "surprised", "bruised")
    mona "What are you, the new Brotherhood?"

    jump ch2_scene1_phantom_agents

label ch2_let_her_be:
    $ show_character("ingrid", "angry")
    ingrid "Are you kidding me?!"
    $ ingrid_relationship -= 2
    ingrid "This is not protocol, [Ellie]--"

    $ show_character("mona", "angry", "bruised")
    mona "Protocol? You're dirty cops--"

    $ show_character("ellie", "surprised")
    ellie "Ooook! Everybody needs to chill!"

    $ hide_character()
    "You drop the syringe on the table."

    $ mona_relationship += 2
    $ show_character("ellie")
    ellie "Mona, it's just a tracker. We're not here to kill you."
    ellie "And - I've told you before - we're not cops."

    jump ch2_scene1_phantom_agents

label ch2_scene1_phantom_agents:
    $ show_character("ellie")
    ellie "... We're Phanthom Agents."
    ellie "You're safe here, Mona. I promise."

    $ hide_character()
    "Mona stares at you with an unreadable expression before slowly sitting back down on the couch."

    play music "audio/TPA/default chill.mp3" fadein 1.0

    $ show_character("mona", modifier="bruised")
    mona "... Where exactly is {i}here{/i}?"

    $ show_character("ellie")
    ellie "We're in one of GAIA's safehouses in L.A."
    ellie "There's a fresh change of clothes for you on the table."
    ellie "But I need to get this tracker in you first."

    $ show_character("mona", modifier="bruised")
    mona "Why?"

    $ show_character("ellie")
    ellie "Protocol."
    ellie "I told you this wasn't freedom."

    $ hide_character()
    "You stare each other down for a long moment before she looks away."

    $ show_character("mona", "angry", "bruised")
    mona "Fine. Get it over with."

    $ hide_character()
    "Without resistance, you make quick work of injecting the tracker into her arm."
    $ mona_tracker = True

    if mona_relationship < 60:
        "You notice the way her shoulders tense up as you push the plunger."

    else:
        "You catch her look as you push the plunger. She seems to relax."

    $ show_character("ellie")
    ellie "There..."
    ellie "Bathroom's on the left. You can change out of your prison uniform."

    $ hide_character()
    "Ingrid hands her the clothes."
    "Wordlessly, Mona disappears into the bathroom."

    $ show_character("ingrid")
    ingrid "Good call."
    $ ingrid_relationship += 2

    if ch2_break_protocol:
        ingrid "I shouldn't have doubted you."

    $ hide_character()
    "You and Ingrid move to the other side of the room."

    scene safehouse basic at mid_right_to_left
    pause 0.5

    $ show_character("ellie")
    ellie "This is what we know."

    $ hide_character()
    "You gesture at the evidence board."

    scene crew board with dissolve

    $ show_character("ellie")
    ellie "The four members of the Velvet Jackels."
    ellie "We need to gather information on each of them."

    $ show_character("ingrid")
    ingrid "And you said your contact knows something about Torque?"

    $ show_character("ellie")
    ellie "His name is Logan."

    $ hide_character()
    $ torque_found = True

    $ my_notify_func("gui/notify.png", "CREW IDENTIFIED!", "1 out of 4 members identified.")
    scene crew board with dissolve
    pause 1.5


    if ch1_ingrid_truth:
        $ show_character("ingrid")
        ingrid "Right. Your deliquent friend."

        $ show_character("ellie", "surprised")
        ellie "You say that but you flirted with him."

        $ show_character("ingrid", "surprised")
        ingrid "In my good old days of compulsory heterosexuality. It barely counts!"

        $ show_character("ellie", "happy")
        ellie "Hm hm, sure."

    else:
        $ show_character("ingrid", "surprised")
        ingrid "Why do I feel like I've seen him before?"

        $ show_character("ellie")
        ellie "... Because you have. In high school."

        $ hide_character()
        "You can almost see the gears turning in Ingrid's mind."

        $ show_character("ingrid", "surprised")
        ingrid "You have to be kidding me--"

        if ellie_prom == "Mona":
            ingrid "And that woman! I knew she seemed familiar--"

            $ hide_character()
            "You think back to prom night."

            scene prom sepia at center with dissolve
            "Slowly dancing with Mona, you suddenly bump into somebody else on the floor."
            $ young_ingrid_outfit = "prom"
            $ brent_outfit = "prom"
            $ young_mona_outfit = "prom"
            $ show_character("ingrid", "angry", modifier="young")
            ingrid "Ugh, could you {i}please{/i} watch where you're going?"

            $ hide_character()
            "You turn around to see Ingrid and Brent."
            "Brent gives Mona the once-over."

            $ show_character("brent", "angry")
            brent "Do you even go to this school?"

            $ show_character("mona", modifier="young")
            mona "Do I {i}look{/i} like I go to this school?"

            $ hide_character()
            scene crew board with dissolve

        elif ellie_prom == "Logan":
            $ hide_character()
            "You think back to prom night."

            scene prom sepia at center with dissolve
            "Slowly dancing with Logan, you suddenly bump into somebody else on the floor."
            $ young_ingrid_outfit = "prom"
            $ brent_outfit = "prom"
            $ young_logan_outfit = "prom"
            $ show_character("ingrid", "angry", modifier="young")
            ingrid "Ugh, could you {i}please{/i} watch where you're going?"

            $ hide_character()
            "You turn around to see Ingrid and Brent."

            $ show_character("brent", "happy")
            brent "Logan, my main man! Where have you been? It's been way too long."

            $ show_character("logan", "surprised", modifier="young")
            logan "Uh... I've been a little busy."

            $ hide_character()
            scene crew board with dissolve

        $ ingrid_relationship -= 2
        $ show_character("ingrid", "angry")
        ingrid "[Ellie], what the Hell?!"

        $ show_character("ellie", "surprised")
        ellie "I'm sorry I didn't tell you!"

        $ show_character("ingrid", "angry")
        ingrid "Sorry doesn't even begin to cover this!"
        ingrid "You know these people! You can't just--"

    $ hide_character()
    $ center_voice = "MONA"
    center_mona "Are you the only people working on this case?"
    $ center_voice = "TUTORIAL"

    $ change_mona_outfit(2, 1, jacket=True)
    scene safehouse basic at right with dissolve

    $ middle = False
    $ bottom = True
    $ regular = False
    $ timeout_label = None

    $ mona_mood = "neutral"
    show big mona bruised with dissolve

    menu:
        b "We are."

        "Is that your old jacket?":
            hide big mona bruised with dissolve

            $ show_character("mona", "surprised", "bruised")
            mona "I don't know, is it? {i}You{/i} gave me the clothes."

            $ show_character("ingrid")
            ingrid "It is."
            ingrid "It was one of the only things they had from you."

            $ show_character("ellie", "surprised")
            ellie "You checked out her stuff?"

            $ hide_character()
            "She shrugs."

            $ show_character("ingrid")
            ingrid "Figured she'd want them back."

            $ show_character("mona", modifier="bruised")
            mona "... I did. Thank you."

            $ show_character("ingrid")
            ingrid "Whatever."

        "{image=heart_mona} Hi.":
            hide big mona bruised with dissolve

            $ hide_character()
            "She raises an eyebrow at you, amused."

            $ show_character("mona", "happy", "bruised")
            mona "Could have said that before you stuck a needle in me."

            $ show_character("ellie", "happy")
            ellie "You're absolutely right. How about I make it up to you over dinner sometime?"

            $ mona_romance += 1
            $ show_character("mona", "happy", "bruised")
            mona "Let's leave it at {i}hi{/i} for now."

            $ hide_character()
            "You see Ingrid rolling her eyes at the interaction."

            $ ch2_ellie_flirt_with_mona_in_front_of_ingrid = True

            if ingrid_flirt:
                $ ingrid_relationship -= 2

    $ hide_character()
    "Mona switches her attention back to the evidence board."

    scene crew board with dissolve

    $ show_character("mona", "surprised", modifier="bruised")
    mona "That's all you've got?"
    $ show_character("mona", modifier="bruised")
    mona "No wonder you begged me for help."

    $ show_character("ellie")
    ellie "I don't remember begging."

    $ show_character("mona", "happy", "bruised")
    if not ch1_officer_suave_point:
        mona "Ask the COs for the tapes. Maybe that'll jog your memory."

    else:
        mona "Ask the COs for the tapes. I'm sure you have her number."

        if ch1_trail_jones_bartender:
            $ show_character("ingrid", "happy")
            ingrid "She does, she keeps it next to the bartender's."

            $ show_character("mona", "surprised", modifier="bruised")
            mona "The bartender's?"

            $ show_character("ellie", "surprised")
            ellie "I was just being polite!"

            $ show_character("mona", "happy", "bruised")
            mona "You really think anyone's buying that?"

    $ show_character("ingrid")
    ingrid "{i}Ahem{/i}. Can we focus on this?"
    ingrid "What do you know about them?"

    $ show_character("mona", modifier="bruised")
    mona "I know where Logan usually crashes at."
    
    $ show_character("ingrid")
    ingrid "How? You've been in prison."

    $ show_character("mona", "happy", modifier="bruised")
    mona "You'd be surprised."
    $ show_character("mona", modifier="bruised")
    mona "You want the leaders. There's a long chain of command though."
    mona "I'm surprised Logan is even on that list."

    $ show_character("ellie", "surprised")
    ellie "What do you mean?"
    $ show_character("ellie")
    ellie "The information they gave us was that these four were the only members."

    $ show_character("mona", modifier="bruised")
    mona "Well, you've been lied to."
    mona "And those codenames? Torque, Silk, Pixel, Ghost... They're positions on a squad."
    mona "So the question is... Why are you looking for Logan's squad specifically?"

    $ show_character("ingrid")
    ingrid "As if we're going to tell you why we're after your friends."

    $ middle = False
    $ bottom = False
    $ regular = True
    $ timeout_label = None
    $ show_character("ellie")
    menu:
        ellie "Ingrid, Mona..."

        "Doesn't have friends.":
            $ ch2_mona_no_friends = True
            $ show_character("ellie")
            ellie "And the ones she had tried to choke her to death."

            if mona_flirt:
                $ mona_relationship -= 2

            $ show_character("mona", modifier="bruised")
            mona "Ouch."

            $ show_character("ingrid")
            ingrid "All the more reason for us to be careful."

        "Doesn't actually care.":
            $ ch2_mona_doesnt_care = True
            if ch1_ingrid_truth:
                $ show_character("ellie")
                ellie "She was going to help The Brotherhood catch us, remember?"

            $ show_character("ellie")
            ellie "She would sell them to the highest bidder if it benefitted her."

            $ show_character("ingrid")
            ingrid "Doesn't mean we can trust her."

        "Is helping us.":
            $ ch2_mona_is_helping = True
            $ show_character("ingrid")
            ingrid "Or she's playing us."
            ingrid "For all we know she's just fishing for information to warn the others."

    if ch1_mona_trusted:
        $ show_character("ellie")
        ellie "I trust her."
    
    $ show_character("ingrid")
    ingrid "I'm just saying... I'll dig around, see if I can verify her information."

    if ch1_mona_liar:
        $ show_character("ellie")
        ellie "Better safe than sorry."

    $ show_character("mona", modifier="bruised")
    mona "Cool. Are we done?"

    $ hide_character()
    scene safehouse basic at left with dissolve

    $ show_character("ellie")
    ellie "No, actually. I have one more question."
    ellie "Why did you think we wanted to kill you?"

    $ hide_character()
    "She stuffs her hands on the pockets of her jacket and fixes her look on the evidence board."
    "Finally, she shifts uncomfortably in place and looks at you."

    $ show_character("mona", modifier="bruised")
    mona "You're a secret agent. Figure it out yourself."

    $ show_character("ellie")
    menu:
        ellie "..."
        
        "I will.": # +MONA
            $ ch2_mona_i_will = True
            $ hide_character()
            "She doesn't say anything else about it, but you see a hint of a smile on her lips."

            $ mona_relationship += 2
            $ show_character("mona", "neutral", "bruised")
            mona "..."

        "Keep your secrets, then.": # nothing happens
            $ ch2_mona_i_will = False
            $ show_character("ellie")
            ellie "It's not my problem, anyway."

            $ show_character("mona", modifier="bruised")
            mona "That's the spirit."

    $ show_character("mona", modifier="bruised")
    mona "Well, I'm out of here."

    $ show_character("ellie", "angry")
    ellie "What part of \"this isn't freedom\" did you not understand?"

    $ show_character("mona", modifier="bruised")
    mona "Would you relax, Nanny McPhee? I'm not bailing on you."
    mona "It's my first day out of that shithole in ten years. I just want to go out for a bit."

    $ show_character("ellie")
    ellie "You can't just go out. I'm supposed to be watching you."

    $ show_character("mona", "happy", modifier="bruised")
    mona "So? You can tag along."

    if mona_flirt:
        mona "Could be a date."

    $ show_character("ellie")
    ellie "(Hm... I could go and let Mona celebrate her first day out.)"
    ellie "(Or I can lock us in and help Ingrid with research.)"

    $ hide_character()

    $ middle = False
    $ bottom = True
    $ regular = False
    $ timeout_label = None
    
    show big mona bruised at center with dissolve
    menu:
        b "..."

        "Let's go!":
            jump ch2_mona_diamond_scene

        "Not happening.":
            hide big mona bruised with dissolve
            $ middle = False
            $ bottom = False
            $ regular = True
            jump ch2_scene1_research

label ch2_mona_diamond_scene:
    $ ch2_mona_scene = True
    $ mona_mood = "happy"
    show big mona bruised with dissolve
    pause 0.5
    hide big mona bruised with dissolve
    $ middle = False
    $ bottom = False
    $ regular = True

    $ show_character("ellie")
    ellie "But we can't be out for that long, I have work to do."

    $ show_character("mona", modifier="bruised")
    mona "You're the boss. Unfortunately."

    $ show_character("ellie")
    ellie "I can ask Ingrid to replace me."

    $ show_character("mona", "happy", modifier="bruised")
    mona "No takebacks, [Wheeler]. You're stuck with me."

    $ show_character("ellie", "happy")
    ellie "Come on, before I change my mind."

    $ hide_character()
    "You grab the keys and gesture for Mona to follow you to the car."

    scene city day car at mid_left with dissolve

    "She immediately puts her feet up on the dashboard. You glare at her."

    $ show_character("mona", modifier="bruised")
    mona "What?"
    mona "If you don't want me to get comfortable here you should just let me drive."

    $ show_character("ellie")
    ellie "Sorry. Part of the deal to get you out involves not letting you drive."

    $ show_character("mona", "happy", modifier="bruised")
    mona "I feel like you're making stuff up as you go."

    $ show_character("ellie", "happy")
    ellie "Doesn't change the fact that you're not driving."

    play sound "audio/SFX/sfx car startup.mp3"

    $ show_character("ellie")
    ellie "Just tell me where to go."

    $ show_character("mona", modifier="bruised")
    mona "Straight ahead. I'll tell you when to turn."

    $ hide_character()
    "She rolls the window down and sticks out her arm, feeling the wind on her skin."

    if mona_flirt or ellie_prom == "Mona":
        "She clears her throat."

        $ show_character("mona", modifier="bruised")
        mona "Judging by this tragic excuse for a car, am I safe to assume that you didn't meet a beautiful person with a beautiful car? Didn't get hearts in your eyes?"
        
        $ show_character("ellie")
        menu:
            ellie "Well..."

            "There is someone else.":
                $ ch2_mona_diamond_scene_someone_else = True
                if ellie_prom != "Mona":
                    $ show_character("mona", modifier="bruised")
                    mona "You're not still hang up on [ellie_prom], are you? That's the real tragedy."
                
                if ingrid_flirt:
                    $ show_character("mona", modifier="bruised")
                    mona "Your partner definitely wants you too."

                if ellie_prom == "Mona" and not ingrid_flirt:
                    $ show_character("mona", "happy", modifier="bruised")
                    mona "If you're trying to make me jealous it's not working."

            "It's not like I'm looking for anyone.":
                $ ch2_mona_diamond_scene_casual_fun = True
                $ show_character("mona", modifier="bruised")
                mona "Oh, so you just flirt with people for fun?"

                $ show_character("ellie")
                ellie "Ever heard of casual fun?"

                $ show_character("mona", "happy", modifier="bruised")
                mona "Have you? How did you even get a babysitting gig with a lifestyle like that?"

                $ show_character("ellie")
                ellie "Ha ha. Hilarious."

            "{image=heart_mona} Not since you've been gone.":
                $ ch2_mona_diamond_scene_only_one = True
                $ show_character("mona", modifier="bruised")
                mona "I told you to forget about me, when I got arrested."

                $ show_character("ellie")
                ellie "And I said I wouldn't."

                $ mona_romance += 1
                $ show_character("mona", modifier="bruised")
                mona "God, you're stubborn."

    $ show_character("mona", modifier="bruised")
    mona "Turn here."

    $ hide_character()
    scene front car coastal at mid_left with dissolve
    pause 0.5

    $ show_character("ellie", "surprised")
    ellie "The beach? You want to go to the beach?"

    $ show_character("mona", modifier="bruised")
    mona "Well, {i}excuse me{/i} if I haven't been outside for the past decade."

    $ show_character("ellie", "surprised")
    ellie "You don't even have a bathing suit--"

    $ show_character("mona", modifier="bruised")
    mona "Shut up. Stop the car."

    play sound "audio/SFX/sfx car stop squeal.mp3"

    $ hide_character()
    "The car barely stops before Mona pops open the door and jumps out."
    "You cuss under your breath and park the car hastily before running after her."

    scene coastal beach at mid_to_left with dissolve
    pause 0.5

    "You follow her through the sand."

    $ show_character("ellie", "surprised")
    ellie "You can't bolt out like that!"

    $ show_character("mona", modifier="bruised")
    mona "Please. If I wanted to run away you'd never find me again. Keep up."

    $ hide_character()
    "She stops once she makes it to the ocean."

    scene beach ocean front at center with dissolve

    "You watch her close her eyes and take in the salty ocean breeze."
    "Finally, she sits down by the ocean. You move to join her."

    $ show_character("ellie")
    ellie "Thought you'd never see water again?"

    $ show_character("mona", modifier="bruised")
    mona "No. I'm not even that big a fan of the beach."
    mona "Just..."

    $ hide_character()
    "She gestures in front of her like it's obvious."

    $ show_character("mona", modifier="bruised")
    mona "Needed a reminder."

    $ show_character("ellie")
    menu: 
        ellie "A reminder? Of what?"

        "What freedom feels like?":
            $ show_character("mona", modifier="bruised")
            mona "Sure, if I hadn't brought a babysitter with me."

        "How big the world is?": # +MONA
            $ mona_relationship += 2

            $ show_character("mona", "happy", modifier="bruised")
            mona "It's definitely not what it seems through a tiny window with bars."

    $ show_character("mona", modifier="bruised")
    mona "The ocean seems to go on forever, doesn't it?"
    mona "I could just get in and swim away. No one would ever find me again."

    $ show_character("ellie")
    ellie "You better be kidding, otherwise I'll have to cuff you to me."

    $ hide_character()
    "She throws her head back in laughter."

    $ mona_relationship += 2
    $ show_character("mona", "happy", modifier="bruised")
    mona "At least take a girl out to eat first."

    $ show_character("ellie")
    ellie "We can grab something to eat before going back."

    $ hide_character()
    "You sit in comfortable silence for a while."

    scene beach ocean front at center with fade

    $ show_character("mona", modifier="bruised")
    mona "Thank you."
    mona "For not letting me die."

    $ show_character("ellie")
    ellie "What are you running from, Mona?"

    $ show_character("mona", modifier="bruised")
    mona "Doesn't matter."

    $ show_character("ellie")
    ellie "I'll figure you out, one day."

    $ hide_character()
    "She snorts."

    $ show_character("mona", "happy", modifier="bruised")
    mona "I highly doubt it."

    $ show_character("ellie")
    menu:
        ellie "(I should...)"

        "(Show her I mean it.)":
            $ ch2_mona_real_name = True
            $ show_character("ellie")
            ellie "You shouldn't doubt me, {i}[mona_real_name!c]{/i}."

            $ show_character("mona", "surprised", modifier="bruised")
            mona "What did you just say?"

            $ show_character("ellie", "happy")
            ellie "What, you thought I wouldn't come across your actual name?"
            ellie "Give me some more credit here."

            $ show_character("mona", "surprised", modifier="bruised")
            mona "Where did you-- How did you--"

            $ mona_relationship += 2
            $ show_character("mona", modifier="bruised")
            mona "Well played, [Ellie] [Wheeler]."
            mona "Don't go getting any ideas, though. Call me Mona."

            $ show_character("ellie")
            ellie "Understood."

        "(Tell her I mean it.)":
            $ show_character("ellie")
            ellie "I mean it, Mona."

            if ch2_mona_i_will:
                ellie "I said I'd figure it out and I will."

            $ show_character("mona", modifier="bruised")
            mona "Talk is cheap, [Ellie_nickname]."

            if ch2_mona_i_will:
                $ show_character("mona", "happy", "bruised")
                mona "But I believe you. Just this once."

        "(Drop the subject.)":
            $ hide_character()
            "You fix your gaze on the ocean in front of you."

    $ show_character("mona", modifier="bruised")
    mona "How about that food now? I'm starving."

    $ show_character("ellie")
    ellie "Sure. I saw a diner on the way here."

    $ show_character("mona", modifier="bruised")
    mona "Great. I'll drive us."

    $ show_character("ellie")
    ellie "Nice try. Not happening."

    $ show_character("mona", "happy", modifier="bruised")
    mona "Worth a shot."

    $ hide_character()
    "You take one more look at the ocean before standing up to go."
    
    scene coastal beach at left with dissolve
    "Mona lingers by the water for a beat before following you back to the car."

    jump ch2_mona_diamond_scene_diner

label ch2_mona_diamond_scene_diner:

    scene black with fade
    pause 0.5

    scene diner 50s day at left with dissolve

    $ hide_character()
    "A short drive later, you and Mona step into the diner and take a seat at a booth."
    "As per your training, you make sure to sit on the side that allows you to face the door."
    "You expect her to sit in front of you, but she slides in the seat next to yours."

    $ show_character("ellie")
    ellie "You're a little paranoid, aren't you?"

    $ show_character("mona", modifier="bruised")
    mona "Maybe I'm just trying to get closer to you."

    $ hide_character()
    "You notice her eyes flash to the door as someone steps in."

    $ show_character("ellie")
    ellie "Hm hm, definitely."

    $ hide_character()
    "The waiter comes by your booth and you place your orders."

    $ hide_character()
    scene diner 50s day at left with dissolve
    
    "A little while later, you're watching as Mona devours a giant burger like she hasn't eaten in days."

    $ show_character("ellie", "surprised")
    ellie "Slow down! I didn't save you from being strangled for you to choke to death on food!"

    $ hide_character()
    "She raises an eyebrow at you but complies."

    $ show_character("mona", modifier="bruised")
    mona "You and I... We're pretty similar, right?"

    $ show_character("ellie")
    ellie "Are we?"

    $ show_character("mona", modifier="bruised")
    mona "We were both honor roll students. Both got in with the wrong crowd. Both got betrayed by someone we trusted."

    if ellie_prom == "Mona":
        $ show_character("ellie")
        ellie "Does it even count if you did it to save me?"

        $ show_character("mona", modifier="bruised")
        mona "I meant Logan. But good to know you would count that as a betrayal."

    elif ellie_prom == "Logan":
        $ show_character("mona", modifier="bruised")
        mona "Though you still crawled back to Logan after he played you. I would never."

    $ show_character("mona", modifier="bruised")
    mona "And somehow you still turned your life around. You were still [ellie_valedictorian!c]."
    mona "And me? I was sitting in jail."
    mona "That's the difference between us, really. I was already too far gone. You still had a chance."

    $ hide_character()
    "She looks away."
    $ show_character("mona", modifier="bruised")
    mona "You were always good. To the bitter end."

    $ show_character("ellie")
    menu:
        ellie "Maybe..."

        "Is that why you took a bullet for me?":
            $ ch2_mona_diamond_scene_saved_ellie = True
            $ show_character("mona", modifier="bruised")
            mona "No."
            mona "Yes."
            $ show_character("mona", "angry", modifier="bruised")
            mona "I don't know."
            mona "I just didn't want you to end up like me."
            mona "You and your naive, straight up annoying optimism."
            $ show_character("mona", modifier="bruised")
            mona "It was stupid."

            $ show_character("ellie", "surprised")
            ellie "(I think I get it...)"
            ellie "(No one saved her when she needed them to, so she saved me instead.)"

            $ show_character("ellie")
            ellie "Well... Thank you for doing something stupid."

        "But you're wrong. I wasn't good.":
            $ ch2_mona_diamond_scene_not_good = True
            $ show_character("ellie")
            ellie "I liked it, if I'm being honest. Still do."

            $ show_character("mona", modifier="bruised")
            mona "Figures, with the job you have. But you {i}are{/i} good."
            mona "You wouldn't be here with me right now if you weren't."

        "You haven't lost your chance either.":
            $ ch2_mona_diamond_scene_have_a_chance = True
            $ show_character("mona", modifier="bruised")
            mona "Have you met me?"

            $ show_character("ellie")
            ellie "I have. That's how I know you can still turn it around."

            $ show_character("mona", modifier="bruised")
            mona "I'm not good for anything else, [Ellie_nickname]."

            $ show_character("ellie", "happy")
            ellie "I don't know. I think you're pretty good at this informant thing."

            $ show_character("mona", "happy", modifier="bruised")
            mona "Ah, yes. Snitching. My specialty."

            $ show_character("ellie", "happy")
            ellie "Think about it as intelligence gathering. You could be a good spy."

            $ show_character("mona", modifier="bruised")
            mona "Or a double agent."

            $ show_character("ellie")
            ellie "Are you trying to tell me something?"

            $ show_character("mona", "happy", modifier="bruised")
            mona "Just keeping you on your toes."

    $ hide_character()
    "She puts her food down."

    $ show_character("mona", modifier="bruised")
    mona "Well, I'm stuffed."

    $ mona_relationship += 4
    $ my_notify_func("gui/notify.png", "LIFE'S A BEACH", "You celebrated Mona's first day\nout of jail!")
    mona "And... Thank you. For coming with me."

    $ show_character("ellie", "happy")
    menu:
        ellie "Don't mention it."

        "{image=heart_mona} Take me on a real date next time.":
            $ show_character("mona", "happy", modifier="bruised")
            mona "What, a trip to the beach and lunch not doing it for you?"

            $ show_character("ellie", "happy")
            ellie "Not when you're all paranoid and keeping secrets from me."
            
            $ mona_romance += 1
            $ show_character("mona", "happy", modifier="bruised")
            mona "It's part of my charm."

        "Let's go back.":
            pass

    $ hide_character()
    "You make your way out and drive back to the safehouse."
    
    jump ch2_scene1_research

label ch2_scene1_research:
    scene safehouse basic at left with fade
    pause 0.5

    $ hide_character()
    "Ingrid waves you over."

    $ show_character("ingrid")
    ingrid "I think I've got something."
    ingrid "Check out this footage."
    $ hide_character()

    scene safehouse computers at center with dissolve

    "Ingrid taps on the keyboard and a video starts playing."
    "In the video, you watch as Torque - who you now know is Logan - leans against a black 2018 Halo Krude electric car. He gets in the car, {color=[highlight]}adjusting the driver's seat all the way down{/color}."
    
    $ show_character("ingrid")
    ingrid "Now watch this. It's from the same night."
    ingrid "Watch the driver."

    $ hide_character()
    "She presses play on a different video."
    "In this one, the same black 2018 Halo Krude speeds past, drawing attention from nearby security officers."
    "Ingrid freezes the image when the car is almost out of frame, the driver clear in the image. You take note of the way he is gripping the wheel, almost clutching it to his chest."

    $ show_character("ingrid", "surprised")
    ingrid "There! Did you see it?"

    $ maximum_serious_points += 1

    $ show_character("ellie", "surprised")
    menu:
        ellie "Yes! It's the..."
 
        "Seat!": # +SERIOUS
            $ serious_points += 1
            $ show_character("ellie", "surprised")
            ellie "He adjusted the seat but in this video he's too close to the wheel."

            $ show_character("ingrid", "happy")
            ingrid "Exactly."

        "Wheel!":
            pass

        "Driver!":
            pass

    $ show_character("ingrid")
    ingrid "It could mean they're different drivers."
    ingrid "Your {i}friend{/i} could be right about Torque being just a position on a squad."

    $ show_character("ellie")
    menu:
        ellie "..."

        "{image=heart_ingrid} Why did you say friend like that?":
            $ show_character("ellie")
            ellie "You know we haven't seen or spoken to each other in ten years, right?"

            if ch2_ellie_flirt_with_mona_in_front_of_ingrid:
                $ show_character("ingrid")
                ingrid "Well, you sure seemed cozy."

            $ show_character("ellie", "happy")
            ellie "No need to be jealous."

            $ show_character("ingrid", "surprised")
            ingrid "I wasn't! I'm not!"

            if ellie_prom == "Mona":
                $ show_character("ellie", "happy")
                ellie "You telling me we don't have a vibe like Mona said?"
            else:
                $ show_character("ellie", "happy")
                ellie "You know, [ellie_prom!c] asked me if we had a thing when we bumped into each other at prom."

            $ ingrid_romance += 1
            $ show_character("ingrid", "happy")
            ingrid "You'd like that, wouldn't you?"
            ingrid "Get back to work, Casanova."

        "It's a start.":
            $ show_character("ellie")
            ellie "It's not 100\% convincing."

            $ show_character("ingrid")
            ingrid "Agreed. But at least we know there might be two Torques."

        "I knew she was right.":
            $ show_character("ingrid")
            ingrid "And I said there was no harm in verifying."

            $ show_character("ellie")
            ellie "It's verified now."

            $ show_character("ingrid")
            ingrid "It's barely verified."

            $ show_character("ellie", "happy")
            ellie "All I'm hearing is that my instincts were right."

            $ show_character("ingrid", "happy")
            ingrid "I won't feed your ego."

    $ show_character("ingrid")
    ingrid "We'll see if we can dig up more evidence at the New York Auto Show."

    $ show_character("ellie")
    ellie "I'll get everything set."

    jump ch2_scene2

