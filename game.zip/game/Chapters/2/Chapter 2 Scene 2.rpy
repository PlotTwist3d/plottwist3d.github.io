label ch2_scene2:
    scene gaia private jet at left with fade
    show screen location_title("new york text") with dissolve
    show screen settingsUI
    $ renpy.pause(2, hard=True)
    hide screen location_title with dissolve

    # make the cover story for the auto show
    "You glance out the window of GAIA's private jet on your way back to New York."
    "To your left, Ingrid types non-stop on her laptop."

    $ show_character("ellie")
    ellie "What are you doing?"

    $ show_character("ingrid")
    ingrid "Creating our fake identities for the event."

    $ show_character("ellie", "happy")
    ellie "And you weren't going to let me in on the fun?"

    if ch1_ingrid_scene:
        if ellie_codename:
            $ show_character("ingrid", "happy")
            ingrid "I was too nice with your codename. Was hoping to redeem it with your fake name."

        else:
            $ show_character("ingrid", "happy")
            ingrid "And let you pick my alias after you picked my codename? I'm not that much of a masochist."
        
    else:
        $ show_character("ingrid", "happy")
        ingrid "Of course not. I was going to saddle you with a ridiculous name--"

    $ show_character("ellie", "happy")
    ellie "Give me that."

    $ hide_character()
    "You swipe the laptop from her and read out loud."

    $ show_character("ellie")
    ellie "{i}Eliza Lawrence. Reclusive socialite who developed a recent interest in luxury cars.{/i}"
    $ show_character("ellie", "happy")
    ellie "Is this all so you don't have to pretend not to be a spoiled rich brat?"

    $ show_character("ingrid", "happy")
    ingrid "Watch it, [Wheeler]."
    $ show_character("ingrid")
    ingrid "This identity was already on GAIA's database. We don't really have time to make something believable before the show."
    ingrid "I did some research. This show is mainly aimed at the elite, it's our best bet to blend in."
    ingrid "If we're collectors it'll make it easier to ask about the models that are more probable to be targeted."

    $ show_character("mona", modifier="bruised")
    mona "A little flaw with your plan."
    mona "If Logan is there he's going to know [Ellie] isn't rich. Or a collector."

    $ show_character("ingrid")
    ingrid "Then maybe [Ellie] needs to stay behind. Someone needs to babysit you anyway."

    $ show_character("ellie", "surprised")
    menu:
        ellie "But I have to go!"

        "I know how these guys think!":
            $ show_character("ingrid", "surprised")
            ingrid "That's exactly what I'm worried about!"

            $ show_character("ellie")
            ellie "You need me."
            
        "You can't go without backup!":
            $ show_character("ingrid")
            ingrid "... Did you just use protocol against me?"
            $ ingrid_relationship += 1
            ingrid "Unfair, I'm the only one that can do that."

    $ show_character("ellie")
    ellie "I just need a different cover story."
    ellie "What if I'm someone that works for {color=[highlight]}Ms. Lawrence{/color}?"

    $ show_character("ingrid")
    ingrid "I guess you could be my personal {color=[highlight]}driver{/color}? Ms. Lawrence would definitely be the type to be drived around."

    $ show_character("ellie")
    ellie "I like that. And I came with you to the Auto Show because you {color=[highlight]}wanted my expertise{/color} in choosing a new car."

    $ hide_character()
    "Ingrid steals the computer back for a couple of minutes."

    $ show_character("ingrid")
    ingrid "Okay... {color=[highlight]}Irina Levanov{/color}. There isn't much information on her so you should be able to impersonate her. Plus, you two are alike enough."
    ingrid "She used to dominate underground racing circuits. Known for her {color=[highlight]}speed{/color} and pulling off nearly impossible {color=[highlight]}stunts{/color}."

    $ show_character("ellie", "happy")
    ellie "Sounds right up my alley."

    $ show_character("mona", modifier="bruised")
    mona "Again, isn't that just a waste of time?"
    mona "Logan will clock you in two seconds flat."

    $ show_character("ellie")
    ellie "Two seconds, huh?"

    $ show_character("mona", modifier="bruised")
    mona "Fine. One and half, with his pathetic pining over you."

    $ show_character("ingrid")
    ingrid "Yeah, that guy was all over you when we were teens."

    $ show_character("ellie")
    menu:
        ellie "Sounds like..."

        "You're jealous, Mona." (hidden=not mona_flirt):
            $ show_character("mona", modifier="bruised")
            mona "Please."
            mona "If anything, Colt was jealous. I just found it hilarious."

            $ show_character("ellie", "happy")
            ellie "Hm hm, sure."

        "You're jealous, Ingrid." (hidden=not ingrid_flirt):
            $ show_character("ingrid", "surprised")
            ingrid "Seriously? The guy didn't even look at me twice after meeting you."
            $ show_character("ingrid")
            ingrid "Jealous is an understatement."

            $ show_character("ellie")
            ellie "Not what I meant--"

        "An advantage.":
            $ ch2_string_logan_along = True
            ellie "If he still thinks I'm cute, that is."

            $ hide_character()
            "Ingrid snorts and glances your way, seemingly appraising you."

            $ show_character("ingrid", "happy")
            ingrid "I don't know, he might be disappointed."

            $ show_character("ellie", "happy")
            ellie "By you, maybe."

            if ingrid_codename_barfie:
                ellie "{i}Barfie{/i}."
                
            $ hide_character()
            "Ingrid shoves you playfully."
            
            if ingrid_flirt:
                $ show_character("ingrid", "happy")
                ingrid "You're fine, don't worry about it."
            
            $ show_character("ingrid")
            ingrid "You sure know how to use that type of advantage."

            $ show_character("ellie", "happy")
            ellie "We have to use every weapon at our disposal, no?"

            $ ingrid_relationship += 2
            $ show_character("ingrid", "happy")
            ingrid "Good to see you using that brain of yours to strategize for once."

            $ show_character("mona", modifier="bruised")
            mona "So you're just going to lead the guy on until you can throw him in jail?"
            
            $ mona_relationship -= 2
            $ show_character("mona", "angry", "bruised")
            mona "I thought you were above that, with all the shit Logan's put you through."

            if mona_flirt:
                $ hide_character()
                "She levels you with a glare."

        "A nightmare.":
            $ ch2_dont_string_logan_along = True
            $ mona_relationship += 2
            $ show_character("mona", modifier="bruised")
            mona "Amen."

            if ch1_trail_jones_bartender:
                $ show_character("ingrid", "surprised")
                ingrid "You flirted with a male bartender like three days ago!"

            $ show_character("ingrid")
            ingrid "Think about it. You can use this to your advantage."

            $ show_character("ellie")
            ellie "Just because he strung me along doesn't mean I'll do the same."

            $ ingrid_relationship -= 2
            $ show_character("ingrid", "angry")
            ingrid "Do you even want to catch him?"

            $ show_character("ellie", "surprised")
            ellie "What's that supposed to mean?"

            $ show_character("ingrid")
            ingrid "Whatever. We're going off-topic."

    $ show_character("ingrid")
    ingrid "Can we get back on track?"
    ingrid "The fake identity isn't for Logan, it's for everybody else."
    ingrid "No one can know we who we are and why we were there."
    ingrid "Doesn't matter if he recognizes you or not as long as everybody else is none the wiser."

    $ show_character("ellie")
    ellie "Exactly."

    $ show_character("ingrid")
    ingrid "That just leaves us with the problem of what to do with Orange is The New Black over there."

    $ show_character("ellie")
    ellie "Way ahead of you."
    ellie "I called Agent Gray yesterday. You know [grey_pronoun_she]'s a sucker for cars, might be good to have on our ear."
    ellie "Agent [Jones] will keep an eye on Mona while we're there."

    $ show_character("ingrid", "surprised")
    ingrid "How did you even-- Don't they have their own missions to do?"

    $ show_character("ellie", "happy")
    ellie "They can't say no to this face."
    ellie "I'm their favorite mentee."

    $ show_character("ingrid", "happy")
    ingrid "[Jones]'s favorite. I'm pretty sure Gray likes me better. And Vivian. And the director. And our instructors. And--"

    $ show_character("ellie", "happy")
    menu:
        ellie "Oh no, you're getting competitive..."

        "I woke up a beast.":
            $ show_character("ingrid", "happy")
            ingrid "Damn straight."

            $ hide_character()
            "You smile briefly at her before settling in for the rest of the flight."

        "{image=heart_ingrid} It's a good look on you.":
            $ ch2_ellie_flirt_with_ingrid_in_front_of_mona = True
            $ show_character("ingrid", "happy")
            ingrid "Flattery isn't going to help you win them over."

            $ show_character("ellie", "happy")
            ellie "It's not them I'm trying to win over."

            $ ingrid_romance += 1
            $ hide_character()
            "Ingrid rolls her eyes dramatically, but you catch the small smile she tries to hide."

            "Mona gives you an indecipherable look."
            if ch2_mona_scene:
                if not (ch2_mona_diamond_scene_casual_fun or ch2_mona_diamond_scene_someone_else):
                    # told Mona she was the only one -> lie
                    "Something akin to anger flashes in her eyes for the briefest moment before she schools her expression back to a careful neutral mask."

                    $ mona_relationship -= 20 # goes down an entire relationship tier
                    $ ch2_mona_broken_trust = True
                    $ show_character("mona", modifier="bruised")
                    mona "..."
                
                elif ch2_mona_diamond_scene_someone_else:
                    # flirts with Mona but is interested in someone else
                    "Then her lips curve upwards into a mischievous smirk."

                    $ show_character("mona", "happy", modifier="bruised")
                    mona "Don't worry, you already won me over."

                    $ hide_character()
                    "She adds a little playful wink at the end. You notice Ingrid stiffen beside you before she glares at Mona."

                    $ show_character("ellie", "surprised")
                    ellie "(Is Mona trying to make Ingrid jealous or am I imagining things?)"

            else:
                if mona_flirt:
                    "She arches an eyebrow at you, almost daring you to specify {i}who{/i} you are trying to win over."
                
                else:
                    "She glances between you and Ingrid, stopping only when she catches your look."
                    if ellie_prom == "Mona":
                        "She smirks and mouths {i}Vibes{/i}."
                    else:
                        "She winks discreetly at you."

            $ hide_character()
            "You don't have enough time to examine the implications of it as the plane starts descending."
            
    $ hide_character()
    scene safehouse simple at left with fade
    
    "Later, you meet with Agent [Jones] and Agent Gray at the New York safehouse."
    "You leave Mona under Agent [Jones] care and both you and Ingrid duck out to another room to pick your outfits."

    $ change_ingrid_outfit("mission", 1)
    $ show_character("ingrid")
    ingrid "Would you hurry up? We're going to be late."

    $ show_character("ellie", "surprised")
    ellie "How did you pick a dress so fast?"

    $ show_character("ingrid", "happy")
    ingrid "With the help of my impecable taste."

    $ hide_character()
    $ bottom = True
    $ middle = False
    $ regular = False
    $ ingrid_mood = "happy"
    show big ingrid at center with dissolve
    menu:
        b "That outfit..."
        "Definitely screams filthy rich.":
            hide big ingrid with dissolve
            $ show_character("ingrid")
            ingrid "Can't tell if that's a compliment or not."

        "Is beautiful.":
            hide big ingrid with dissolve
            $ show_character("ingrid", "happy")
            ingrid "Naturally."
    
    $ bottom = False
    $ middle = False
    $ regular = True

    $ show_character("ellie")
    ellie "Can you help me pick mine now?"

    $ show_character("ingrid")
    ingrid "Fine."

    $ hide_character()
    "She rumages through the pile of clothes you have at your disposal."

    $ show_character("ingrid")
    ingrid "This one's too blue... That one's too much..."
    $ show_character("ingrid", "happy")
    ingrid "Ah!"
    ingrid "Try this one. Might give you some credibility as Ms. Lawrence's driver."

    $ hide_character()
    "She shoves the clothes in your arms and pushes you into the bathroom."
    "You make quick work of putting them on before stepping out."

    $ hide_character()
    tutorial "SERIOUS points unlock {color=[blue]}outfits{/color} and {color=[blue]}mission{/color} options."

    jump ch2_scene2_outfit_selection

label ch2_scene2_outfit_selection:
    $ hide_character()
    $ change_ellie_outfit("racer", 1)
    $ bottom = True
    $ middle = False
    $ regular = False
    $ ellie_mood = "neutral"
    show big ellie at center with dissolve
    menu:
        b "Let's see..."
        "This is perfect for my cover!" (serious=True, points=1, disabled=(serious_points < 1)):
            $ ellie_mood = "happy"
            show big ellie at center with dissolve
            pause 0.5
            hide big ellie with dissolve
            $ ch2_racer_outfit = True
            
            $ show_character("ingrid", "happy")
            ingrid "Of course it is. When did I ever let you down?"

            $ show_character("ellie", "happy")
            ellie "Never, {i}Ms. Lawrence{/i}. That's why you're the boss and I'm just an underpaid employee."

            $ show_character("ingrid", "happy")
            ingrid "Underpaid? Wow, I should have thrown your CV in the trash."

            $ show_character("ellie", "happy")
            ellie "But then who would drive you around?"

            $ show_character("ingrid", "happy")
            ingrid "Someone less of a complainer, probably."

        "I'll take something else.":
            hide big ellie with dissolve
            $ show_character("ellie")
            $ ch2_racer_outfit = False
            ellie "I just don't think I can pull it off."

            $ hide_character()
            "You change back to your normal clothes."

            $ change_ellie_outfit("casual", ellie_default_outfit)
    
    $ bottom = False
    $ middle = False
    $ regular = True

    $ show_character("ellie")
    ellie "Should I drive us? Make it look real?"

    $ show_character("ingrid", "happy")
    ingrid "I'm not going to complain about being chauffered around."

    $ hide_character()
    "There's a soft knock on the door and [AgentJones] pokes [jones_pronoun_pos_her] head in."

    $ show_character("jones")
    jones "You girls ready?"

    $ show_character("ellie")
    ellie "We are."

    $ show_character("jones")
    jones "Alright. Remember to keep your comms on."
    jones "And don't be a hero, this is just a reconnaissance mission. You're not cleared to use your guns yet."

    $ show_character("ingrid")
    ingrid "We know. Just gather as much information as we can and disappear without a trace."

    $ show_character("jones", "happy")
    jones "You kids grew up so fast."

    $ hide_character()
    "She makes a show of wiping a fake tear. You can practically hear Agent Gray roll [grey_pronoun_pos_her] eyes in the next room."

    $ show_character("jones")
    jones "Good luck. I'll stay on the line as well just in case."
    jones "Go. Get out there."

    $ hide_character()
    "You leave the safehouse with Ingrid."

    jump ch2_scene2_auto_show

label ch2_scene2_auto_show:
    $ hide_character()
    scene auto show lounge at center with fade
    "A short drive later, you and Ingrid walk into the New York Auto Show."

    "You look around the space, surprised at the lack of cars in exposition."

    $ mission_current_value = 0
    $ mission_required_value = 5

    $ show_character("ellie", "surprised")
    ellie "Are we in the right place?"

    $ show_character("ingrid")
    ingrid "This is more like a gala than anything."
    ingrid "There will be some presentations about the new models and a few prototypes around but this is mostly an excuse to rub elbows with rich and powerful people."
    ingrid "There's a collection of very expensive classic cars as well."

    $ show_character("ingrid", "surprised")
    ingrid "Did you not research any of this?"

    $ show_character("ellie", "surprised")
    ellie "I assumed it would be different, is all!"
    $ show_character("ellie")
    ellie "Seems like a waste for them to target this place."

    $ show_character("ingrid")
    ingrid "Not necessarily. Prototypes are rare and expensive, they can get good money for them."

    $ show_character("ellie")
    ellie "Let's keep an eye out for anything out of the ordinary."
    ellie "(And Logan. He's bound to be here somewhere.)"

    $ show_character("ingrid")
    ingrid "Right... But try not to look so out of place."
    $ show_character("ingrid", "happy")
    ingrid "Turn on the charm, [Wheeler]. Gather some intel."

    $ hide_character()
    "You assess your surroundings."
    "There's people around you chatting about cars, drinks in hand. Out of the corner of your eye, you spot a plaque indicating the way to the classic cars expo."
    "Further ahead, you notice a small crowd has gathered around something - or someone - and is cheering loudly. It parts just enough to let you get a glimpse of what seems to be a driving simulator."

    jump ch2_auto_show_choice_loop

label ch2_auto_show_choice_loop:
    if ch2_auto_show_cars and ch2_auto_show_mingle and ch2_auto_show_race:
        jump ch2_scene2_colt_introduction

    else:
        $ show_character("ellie", "happy")
        menu:
            ellie "Let's..."

            "Check out the classic cars." (hidden=ch2_auto_show_cars):
                jump ch2_scene2_auto_show_classic_cars
            
            "Mingle." (hidden=ch2_auto_show_mingle):
                jump ch2_scene2_auto_show_mingle

            "Try the simulator." (hidden=ch2_auto_show_race):
                jump ch2_scene2_auto_show_simulator

label ch2_scene2_auto_show_classic_cars:
    # view classic cars (just activities to do while on auto show)
    $ ch2_auto_show_cars = True
    $ hide_character()
    "You step into a different room."

    scene auto show classic cars at center with fade

    "People line up along the cars, admiring and commenting on the collection behind exhibited."

    $ show_character("greer")
    q "This one's from the 1950s. Not very fast but sturdy as they come."

    $ show_character("omar")
    q "Yes. So sturdy that it kills the driver on impact."

    $ show_character("greer")
    q "But the car remains intact."
    q "People can be replaced. This beast is one of a kind."

    $ show_character("naomi")
    q "I personally prefer speed over flashiness."
    $ show_character("naomi", "happy")
    q "Doesn't matter what a car looks like or how sturdy it is when it's zooming past you at 120 miles per hour."

    $ show_character("omar")
    q "What's the point of having an ugly car? Cars are a symbol of status."

    $ hide_character()
    "They notice you watching them."
    
    if ch2_racer_outfit:
        "They cast an appreciative look over your outfit."
        $ show_point_gained("+COVER")
        $ mission_current_value += 1

        $ show_character("greer", "surprised")
        q "You look familiar."

    else:
        "They cast an unimpressed look over your outfit."
        $ show_character("greer")
        q "If you're looking for the servant's lounge, it's not here."

        $ show_point_gained("-COVER")
        $ show_character("ellie", "angry")
        ellie "I'm exactly where I'm supposed to be."

    $ show_character("ellie")
    ellie "I'm Irina Levanov."

    $ show_character("omar", "surprised")
    q "The driver? Oh, maybe you can settle our argument then."

    $ show_character("omar")
    q "What is more important in a car? Speed, durability, or beauty?"

    $ show_character("ellie")
    menu:
        ellie "Obviously it's..."

        "Speed.":
            $ show_character("omar", "happy")
            q "I should have known. Of course one of the fastest drivers out there would choose speed."
            $ show_point_gained("+COVER")
            $ mission_current_value += 1
            $ show_character("naomi", "happy")
            q "Just means she knows what she's talking about."
            naomi "I'm Naomi. These losers are Omar and Greer."

            $ show_character("greer", "angry")
            greer "Losers?!"

        "Durability.":
            $ show_character("naomi", "surprised")
            q "Really? I thought someone like you would appreciate speed above anything else."
            $ show_point_gained("-COVER")

            $ show_character("ellie", "surprised")
            ellie "Durability is very important! Especially if you like speed!"

            $ show_character("greer", "happy")
            q "Damn right."
            greer "I'm Greer. These non-believers are Naomi and Omar."

        "Aesthetics.":
            $ show_character("naomi", "surprised")
            q "Really? I thought someone like you would appreciate speed above anything else."
            $ show_point_gained("-COVER")

            $ show_character("ellie", "surprised")
            ellie "Speed is great but you gotta look good!"

            $ show_character("omar", "happy")
            q "If you're not going to show off the car then what's the point, really?"
            omar "I'm Omar. These two are Naomi and Greer."

    $ show_character("omar")
    omar "What brings you to the Auto Show? Is there a race going on that we're not aware of?"

    $ show_character("ellie")
    ellie "Nothing like that."
    menu:
        ellie "I'm just here as a consultant for..."

        "Mr. Lawrence.":
            $ ch2_lawrence = False
            $ show_character("omar")
            omar "I don't think I've ever heard of him."
            omar "Is it someone I should know?"
            $ show_point_gained("-COVER")
            $ show_character("ellie", "surprised")
            ellie "I'm sorry did I say Mr? I meant {i}Ms.{/i} Lawrence."
            $ show_character("ellie")
            ellie "Sometimes I forget she's a lady."

            $ hide_character()
            "The trio snickers."

            $ show_character("greer", "happy")
            greer "That bad, huh?"

        "Ms. Lawrence.":
            $ ch2_lawrence = True
            $ show_character("greer", "surprised")
            greer "Impossible! She's too reclusive to have hired you."
            $ show_point_gained("+COVER")

            $ show_character("ellie", "happy")
            ellie "She's a weird one, that's for sure."

            $ mission_current_value += 1

    $ show_character("naomi")
    naomi "I'd be weird too if I had a fortune like hers."

    $ show_character("greer", "happy")
    greer "Maybe you should join the Jackals."

    $ hide_character()
    "The group laughs as if it's an inside joke you're not supposed to understand."

    $ show_character("ellie")
    ellie "The Jackals?"

    $ show_character("omar")
    omar "It's a heist crew. Rumors say they steal prototype cars and sell the technology to the highest bidders."

    $ show_character("naomi", "happy")
    naomi "My dream job: screwing over corporations."

    $ show_character("ellie", "happy")
    ellie "I can get behind that. Think they're taking walk-ins?"

    $ show_character("greer", "happy")
    greer "Doubtful. It's very exclusive."

    $ show_character("ellie")
    ellie "You don't seem too worried that they steal cars."

    $ show_character("omar")
    omar "Sure, it's bad from a moral point of view but come on. Are you going to tell me it isn't thrilling? It's like Fast and Furious."
    
    $ show_character("greer")
    greer "Who cares about thrilling? It's making them famous. That's the real appeal."

    $ show_character("naomi")
    naomi "Please. The {i}money{/i} is the appeal."

    $ hide_character()
    "As the trio begins another heated discussion that you have no interest in, you slide back to where Ingrid is."

    $ show_character("ellie")
    ellie "Is everyone here insane?"

    $ show_character("ingrid")
    ingrid "We prefer the word {i}excentric{/i}."

    $ show_character("ellie", "happy")
    ellie "{i}We{/i}?"

    $ hide_character()
    "She smiles briefly at you before sliding her business face mask back on."

    $ show_character("ingrid")
    ingrid "I think I found something."
    ingrid "I've been paying attention to the security cameras around here."
    ingrid "I've noticed some of them are shutting off for a few seconds before coming back."

    $ show_character("ellie")
    ellie "Pixel?"

    $ show_character("ingrid")
    ingrid "Could be. Could be nothing."

    $ show_character("ellie")
    ellie "We'll keep an eye out."
    ellie "What about Silk? There's people here that idolize the Jackals."

    $ hide_character()
    "You gesture vagely in the direction of the arguing trio."

    if not ch2_lawrence:
        "Greer catches your look and snickers."

        $ show_character("greer", "happy")
        greer "She {i}does{/i} look like a man!"

        $ hide_character()
        "Ingrid looks confused."

    $ show_character("ingrid")
    ingrid "I don't think they would be so open about it if they had anything to hide but we can't rule anything out."
    
    $ hide_character()
    "You and Ingrid circle back to the lounge."

    scene auto show lounge at center with fade

    $ show_character("ingrid")
    ingrid "What should we do now?"

    jump ch2_auto_show_choice_loop

label ch2_scene2_auto_show_mingle:
    # mingle with rich people (just activities to do while on auto show)
    # possibility for +SUAVE
    $ ch2_auto_show_mingle = True

    $ show_character("ingrid", "happy")
    ingrid "My specialty."

    play music "audio/TPA/mischief competition.mp3" fadein 0.5

    $ hide_character()
    "She snags a drink from a passing server and stalks off towards a group of well-dressed guests."

    $ show_character("ingrid", "happy")
    ingrid "Mathilda!"

    $ hide_character()
    "The woman's eyes widen in surprised for a brief second, clearly clueless as to who the hell is this crazy person greeting her, before expertly covering it up with an easy smile. They air kiss."

    $ show_character("silk", "happy")
    mathilda "Dear, so good to see you! I haven't seen you since... huh..."

    $ show_character("ingrid", "happy")
    ingrid "The Grand Prix cerimony in Monaco."

    $ hide_character()
    "A gentleman smiles cordially at her."

    $ show_character("giorgio", "happy")
    q "Ah, another person interested in more than just a pretty chassis!"
    giorgio "I don't believe we've met. I'm Giorgio Ricci."

    $ show_character("ingrid", "happy")
    ingrid "Eliza Lawrence. Delighted to make your acquaintance."

    $ show_character("giorgio", "happy")
    giorgio "I should have guessed! I must say I have been curious to meet you ever since I found out you were looking to hire a driver. I always enjoy a little friendly race among kindred souls."
    giorgio "Are they here today?"

    $ hide_character()
    "His gaze sweeps behind Ingrid eagerly."

    if ch2_racer_outfit:
        "His whole expression brightens when he sees you."

        $ show_character("giorgio", "happy")
        giorgio "That one, certainly?"
        giorgio "It's refreshing to see someone that clearly takes the sport seriously."
        $ show_point_gained("+COVER")
        $ mission_current_value += 1
    
    else:
        "He barely acknowledges your existence."
        $ show_character("ingrid")
        ingrid "I did bring her. But you know how drivers are..."

    $ hide_character()
    "Ingrid waves you over."

    $ show_character("ingrid", "happy")
    ingrid "Mr. Ricci, let me introduce you to my speed demon, Ms. Levanov."

    $ show_character("ellie")
    menu:
        ellie "Please, call me..."

        "Iris.":
            $ show_character("giorgio")
            giorgio "Is that some sort of nickname, Ms Levanov?"
            $ show_point_gained("-COVER")

            $ show_character("ingrid", "angry")
            ingrid "It is, though it's hardly appropriate. Isn't that right, {i}Irina{/i}?"

            $ show_character("ellie")
            ellie "Doesn't matter what's appropriate, as long as everyone else is left in the dust."

            $ show_character("giorgio", "happy")
            giorgio "I couldn't agree more."

        "Irina.":
            $ ch2_irina = True
            ellie "No need for formalities."

            $ show_point_gained("+COVER")
            $ mission_current_value += 1

            $ show_character("giorgio", "happy")
            giorgio "It's a pleasure to make your acquaitance."

        "Ina.":
            $ show_character("giorgio")
            giorgio "Is that some sort of nickname, Ms Levanov?"
            $ show_point_gained("-COVER")

            $ show_character("ingrid")
            ingrid "It is, though it's hardly appropriate. Isn't that right, {i}Irina{/i}?"

            $ show_character("ellie")
            ellie "Doesn't matter what's appropriate, as long as everyone else is left in the dust."

            $ show_character("giorgio", "happy")
            giorgio "I couldn't agree more."

    $ show_character("giorgio")
    giorgio "I saw you race in Cordonia a couple years ago. What made you seek Ms. Lawrence's employment?"

    $ show_character("ingrid", "happy")
    ingrid "Much as it pains me to admit, I sought her, not the other way around."
    ingrid "Difficult to convince her, with all the buzz around that new crew... What was it called...? Some sort of animal... Wolves? Dogs?"

    $ show_character("silk")
    mathilda "Jackals, perhaps?"

    $ show_character("ingrid")
    ingrid "Ah, possibly."

    $ show_character("giorgio")
    giorgio "A bunch of hooligans, if you ask me."
    giorgio "Underground races might not be legal, but neither is stealing and damaging perfectly good cars. The latter being much severe, in my opinion."

    $ show_character("ingrid")
    ingrid "Damaging?"

    $ show_character("giorgio")
    giorgio "Some of the stolen cars have surfaced in underground races. They seem intent on crashing them, those lousy drivers."

    $ show_character("silk")
    mathilda "Ms. Levanov, you certainly have a better understanding than we do."

    $ hide_character()
    "You attempt to relax your expression into one of casual indifference. Mathilda regards you with curiosity."

    $ show_character("silk")
    mathilda "Are they lousy drivers?"

    $ maximum_suave_points += 1

    $ show_character("ellie")
    ellie "Lousy drivers can't pull off the stunts that they do."
    menu:
        ellie "And I should know..."

        "I wrote the rulebook on stunts.":
            $ ch2_stunts = True
            $ show_character("giorgio", "happy")
            giorgio "That you did."
            $ show_point_gained("+COVER")
            $ mission_current_value += 1
            giorgio "I have never witnessed anyone as fearless behind a wheel as you were."

            $ show_character("silk")
            mathilda "Is that so?"
            mathilda "What makes you so brave, Ms. Levanov?"

            $ hide_character()
            "Mathilda sips her drink, her eyes trained on you with an intensity that's hard to miss."

            $ show_character("ellie")
            menu:
                ellie "I can't give away my secrets like this."

                "Over dinner, perhaps?":
                    $ ch2_mathilda_suave_point = True
                    $ hide_character()
                    "Her lips quirk up in a tiny smirk."
                    $ suave_points += 1
                    $ show_character("silk", "happy")
                    mathilda "And bold, in addition to being brave."
                    mathilda "Both qualities I admire in a woman."

                "Only to my employer.":
                    $ show_character("silk", "happy")
                    mathilda "Well, I would be more than happy to employ you."
        
        "I couldn't pull it off.":
            $ show_character("giorgio", "surprised")
            giorgio "Is that so? I thought there was no stunt you couldn't pull off."
            $ show_point_gained("-COVER")
            $ show_character("ellie")
            ellie "That just goes to show how difficult they are."

            $ show_character("silk")
            mathilda "Or perhaps you're losing your touch, Ms. Levanov."

            $ hide_character()
            "She sips her drink, her eyes trained on you with an intensity that's hard to miss."

            $ show_character("ellie")
            menu:
                ellie "Perhaps..."

                "I should use my {i}touch{/i} elsewhere.":
                    $ ch2_mathilda_suave_point = True
                    $ show_character("silk", "happy")
                    mathilda "Is that an invitation, Ms. Levanov?"
                    $ suave_points += 1
                    $ show_character("ellie", "happy")
                    ellie "A suggestion."

                "You should try the stunts yourself.":
                    $ show_character("silk")
                    mathilda "I'd rather watch."
                    mathilda "Would you care to show me?"

                "You're right.":
                    $ show_character("ellie")
                    ellie "Being in the employment of Ms. Lawrence hasn't allowed me for many opportunities to polish my skills."

                    $ show_character("silk")
                    mathilda "Is that so? Well, if you ever consider switching--"

    $ show_character("ingrid")
    ingrid "That's enough of you trying to steal my driver."

    $ show_character("giorgio", "happy")
    giorgio "Now, Ms. Lawrence... Can you blame her? We're all a little jealous of you at the moment."

    $ show_character("ingrid", "happy")
    ingrid "Then we will leave you to wallow in your jealousy."
    ingrid "Irina, come along."

    play music "audio/TPA/default chill.mp3" fadein 0.5

    $ hide_character()
    "You follow her to a more secluded area."

    if ch2_irina and ch2_stunts:
        $ show_character("ingrid")
        ingrid "That went well."

    else:
        if not ch2_irina:
            $ show_character("ingrid", "surprised")
            ingrid "Can't believe you forgot your own name!"

        if not ch2_stunts:
            $ show_character("ingrid", "surprised")
            ingrid "What was that about not pulling off stunts? It's literally what you're know for!"

        $ show_character("ellie", "surprised")
        ellie "I know, I'm sorry!"

        $ show_character("ingrid")
        ingrid "Thankfully it didn't seem to raise any red flags."

    $ show_character("ellie")
    ellie "Why did you ask them about the Jackals?"

    $ hide_character()
    "She shrugs."

    $ show_character("ingrid")
    ingrid "Figured one of them would know something. The venn diagram of people that attend these events and people who have been targeted by the Jackals is basically a circle."

    $ show_character("ellie")
    ellie "Well, now we know where the cars ressurface after being taken."

    $ show_character("ingrid")
    ingrid "Why, though? Why bother stealing these cars if they're just going to wreck them in races?"

    $ show_character("ellie")
    menu:
        ellie "Maybe they..."

        "Are just in it for the thrill.":
            $ ch2_thrill = True
            $ show_character("ingrid")
            ingrid "I agree."
            ingrid "Doesn't make them any less dangerous."

            $ hide_character()
            "You nod in agreement."

        "Are idiots.":
            $ ch2_idiots = True

            $ show_character("ingrid")
            ingrid "They are too put together to be idiots."

            $ show_character("ellie", "happy")
            ellie "I don't know, only an idiot would crash a car."
            ellie "It«s good for us, makes our job easier."
            
            $ hide_character()
            "She shakes her head at you, but you see the tiniest hint of a smile on her lips."

        "Aren't what they seem.":
            $ ch2_what_it_seems = True
            
            $ show_character("ingrid")
            ingrid "How so?"

            $ show_character("ellie")
            ellie "Think about it. Nothing they do seems to make sense."
            ellie "We're missing something."

            $ show_character("ingrid")
            ingrid "We might be..."

    $ show_character("ingrid")
    ingrid "Where to, next?"

    jump ch2_auto_show_choice_loop

label ch2_scene2_auto_show_simulator:
    # racing simulator (just activities to do while on auto show)
    # recruit Fabian for later chapters
    $ maximum_serious_points += 1
    $ ch2_auto_show_race = True
    $ hide_character()
    "You approach the driving simulator."
    "The machine screeches as the man currently controlling a virtual Mitsubishi Lancer Evolution X steps hard on the gas, effortlessly gliding into the finish line."
    "The small crowd gathered around him cheers."

    $ show_character("fabian", "happy")
    q "Pay up, Roger."

    $ hide_character()
    "His opponent grunts in contempt but reaches for his wallet. He pulls you a stack of bills and uncerimoniously throws then at the driver."

    "There's a rustle on your ear, and the comms flip to life."

    $ show_character("mona", "surprised", "bruised holo")
    mona "I know that guy!"
    mona "They call him The European. Kaneko and I watched him race once... He obliterated Salazar."
    
    $ show_character("fabian", "happy")
    european "Anybody else wants to give it a try?"

    $ hide_character()
    "He scans the crowd. His eyes fall on you and he takes a second to take you in."

    if ch2_racer_outfit:
        $ show_character("fabian", "happy")
        european "How about you? You look like you can give me a real challenge."
        $ show_point_gained("+COVER")
        $ mission_current_value += 1

    else:
        $ show_character("fabian")
        european "You look a little out of place. Maybe you'll do a better job than the rest of these snobs."
        $ show_point_gained("-COVER")

    $ show_character("ellie")
    ellie "What's the wager?"

    $ show_character("fabian")
    european "2 grand."

    $ hide_character()
    "Ingrid side-eyes you, managing to keep her practised rich-person composure."
    "You know what the warning in her eyes means, though: don't gamble with GAIA's money."

    $ show_character("ellie")
    ellie "(It's a lot of money...)"
    ellie "(But I'm here as a driver and everyone's staring. I have the skills, I could pull this off.)"
    menu:
        ellie "I will..."

        "Take the bet.":
            # -2000 if loss, +2000 if win
            $ ch2_auto_show_challenge = True
            $ hide_character()
            "The European grins and jumps back into his seat."

            $ show_character("fabian", "happy")
            european "Go on, don't be shy."
            if not ch2_racer_outfit:
                european "I'll go easier on you."

                $ show_character("ellie", "angry")
                ellie "I can handle myself just fine."

            $ hide_character()
            "You hop into your seat and check the controls."
            play music "audio/TPA/exciting.mp3" fadein 0.5
            scene auto show simulator at center with fade
            "You look at the screen and see the countdown."
            "5... 4... 3... 2... 1... Go!"
            "The simulated cars roars as you take off."

            $ loop_counter = 0
            $ loop_points = 0

            jump ch2_scene2_auto_show_simulator_minigame

        "Decline the challenge.":
            # skip minigame
            $ my_notify_func("gui/notify.png", "CHICKENED OUT", f"You didn't participate in the\nsimulated race!")
            $ ch2_auto_show_challenge = False
            jump ch2_scene2_colt_introduction

label ch2_scene2_auto_show_simulator_minigame:
    hide timer_clock
    $ timer_clock = 7
    $ timeout_label = "ch2_auto_show_sim_minigame_failure"

    $ option = renpy.random.choice(["SWERVE", "DRIFT", "SPEED UP", "SLOW DOWN"])

    $ show_point_gained(option)

    $ regular = False
    $ middle = True
    $ bottom = False
    $ timer_clock = 7
    menu:
        "I have to..."

        "Swerve!":
            if option == "SWERVE":
                $ loop_points += 1
        
        "Drift!":
            if option == "DRIFT":
                $ loop_points += 1
        
        "Speed Up!":
            if option == "SPEED UP":
                $ loop_points += 1

        "Slow Down!":
            if option == "SLOW DOWN":
                $ loop_points += 1

    $ loop_counter += 1

    if loop_counter < 5:
        jump ch2_scene2_auto_show_simulator_minigame
    else:
        jump ch2_scene2_auto_show_simulator_end

label ch2_auto_show_sim_minigame_failure:
    $ loop_counter += 1

    if loop_counter < 5:
        jump ch2_scene2_auto_show_simulator_minigame
    else:
        jump ch2_scene2_auto_show_simulator_end

label ch2_scene2_auto_show_simulator_end:
    $ regular = True
    $ middle = False
    $ bottom = False
    $ timeout_label = None

    play music "audio/TPA/default chill.mp3" fadein 0.5
    if loop_points >= 3:
        $ ch2_simulator_win = True
        $ hide_character()
        "You step on the gas, eyeing the finish line... And cross it just before your opponent!"
        $ serious_points += 1
        $ my_notify_func("gui/notify.png", "HOT WHEELS", f"You won the simulated race!")
        
        scene auto show lounge at center with fade

        $ show_character("fabian", "surprised")
        fabian "Impossible!"

        $ show_character("ellie", "happy")
        ellie "What can I say? I never lose."

        $ show_character("fabian")
        fabian "I suppose you want your prize?"

        $ show_character("ellie")
        menu:
            ellie "I want..."

            "My money.":
                $ show_character("fabian", "happy")
                fabian "Fair is fair."

                $ hide_character()
                "He hands you a stack of cash."

                $ show_character("fabian")
                fabian "It was a fun race. Feeling up for a rematch?"

                $ show_character("ellie")
                ellie "Some other time. I have places to be."

                $ hide_character()
                "He gives you an understanding nod before turning back to the crowd, looking for the next challenger."

            "A favor." (suave=True, points=2, disabled=(suave_points< 2)):
                $ ch2_recruited_fabian = True
                # Fabian owes you a favor
                $ show_character("fabian", "surprised")
                fabian "You mean the 2 grand, right?"

                $ show_character("ellie")
                ellie "No. You can keep the money, but you owe me."

                $ show_character("fabian")
                fabian "And what exactly do I owe you?"

                $ show_character("ellie")
                ellie "You're a great driver. If I need your services in the future I'll let you know."

                $ hide_character()
                "He ponders for a minute, silently staring at you as if he could read your true intentions."

                $ show_character("fabian")
                fabian "... I can do that."

                $ my_notify_func("gui/notify.png", "CAVALRY", "You have recruited Fabian!")

                $ show_character("ellie", "happy")
                ellie "A pleasure doing business with you."

                $ hide_character()
                "He gives you one last wary look before turning back to the crowd, looking for his next challenger."

    else:
        $ ch2_simulator_win = False
        $ hide_character()
        "You step on the gas just as The European crosses the finish line in front of you!"
        $ my_notify_func("gui/notify.png", "COLD WHEELS", f"You lost the simulated race!")
        $ show_point_gained("-COVER")

        $ show_character("fabian", "happy")
        fabian "Still undefeated."

        $ show_character("ellie")
        menu:
            ellie "You're a great driver..."

            "Congratulations on the win.":
                $ hide_character()
                "You hand him the money you owe him."

                $ show_character("fabian", "happy")
                fabian "A much more gracious loser than the last dude."

                $ show_character("ellie", "happy")
                ellie "Some of us have manners."

                $ hide_character()
                "He gives you a respectful nod before turning back to the crowd, looking for his next challenger."

            "Any chance you take odd jobs?" (suave=True, points=2, disabled=(suave_points< 2)):
                # Fabian will come to your aid
                $ ch2_recruited_fabian = True
                $ show_character("ellie")
                ellie "You're a great driver. Maybe I can hire you in the future?"

                $ hide_character()
                "He ponders for a minute, silently staring at you as if he could read your true intentions."

                $ show_character("fabian")
                fabian "... You could do that."

                $ my_notify_func("gui/notify.png", "CAVALRY", "You have recruited Fabian!")

                $ show_character("ellie", "happy")
                ellie "A pleasure doing business with you."

                $ hide_character()
                "He gives you one last wary look before turning back to the crowd, looking for his next challenger."

    $ hide_character()
    "You return to where Ingrid is."

    if ch2_simulator_win:
        $ show_character("ingrid")
        ingrid "Good job. If anyone had any doubts you knew how to drive like a professional they're definitely convinced now."
        
        $ mission_current_value += 1
        $ show_point_gained("+COVER")

    else:
        $ show_character("ingrid", "angry")
        ingrid "Are you actively trying to sabotage this mission?"

        $ show_character("ellie")
        ellie "It was just a race, relax. Besides, the guy is a pro. He's beaten everyone anyway."

        $ hide_character()
        "She breathes out in exhasperation."

        $ show_character("ingrid")
        ingrid "Fine."

    $ show_character("ingrid")
    ingrid "Where are we going next?"

    jump ch2_auto_show_choice_loop

label ch2_scene2_colt_introduction:
    $ hide_character()
    play sound "audio/SFX/sfx motorcycle.mp3"
    play music "audio/TPA/chase.mp3"
    "You open your mouth to answer but a loud noise overtakes all other sound in the lounge."
    "You turn sharply towards the double doors as a motorcycle burst through."
    $ change_colt_outfit("formal", 1, jacket=False)

    $ timeout_label = None
    show screen item("colt new bike", "Is that a motorcycle?")
    $ regular = False
    $ bottom = True
    menu:
        with dis
        "What the hell?!":
            $ bottom = False
            $ regular = True

    hide screen item with dis

    "The driver takes the bike for a lap around the room before coming to a sharp stop at the center of the lounge."

    $ show_character("giorgio", "surprised")
    giorgio "Is that...?"

    $ show_character("naomi", "happy")
    naomi "I didn't think they made these anymore."

    $ show_character("colt", modifier="helmet")
    q "They don't."
    q "This is a limited edition Halo Crossroads. Design from the past, tech from the future."

    $ hide_character()
    "He removes the helmet."

    #TODO Colt character customization

    $ hide_character()
    "Your eyes widen in surprise before you manage to school your features back to casual indifference."

    play music "audio/TPA/default chill.mp3"

    $ show_character("ellie", "surprised")
    ellie "(Oh my God... That's {color=[highlight]}Colt{/color}!)"

    $ hide_character()
    "Your mind flashes back to memories of you and Colt."

    scene car sideshow sepia at left with fade
    $ show_character("colt", modifier="young")
    colt "Looks like you're in the wrong place, sweetheart."
    colt "A girl like you could get herself in trouble at a place like this."
    $ hide_character()

    scene auto shop billards sepia at right with fade
    $ show_character("colt", "happy", "young")
    colt "Nice to see someone else around here with brains."
    $ hide_character()
    
    scene auto shop inside sepia at left with fade
    $ show_character("toby", "surprised")
    toby "What's your favorite new model of the year?"

    $ show_character("colt", "happy", "young")
    colt "Yeah, you know {i}all{/i} about that, don't you, [Ellie]?"

    $ hide_character()

    scene auto show lounge at center with fade

    if ellie_young_first_kiss == "Colt":
        $ show_character("ellie")
        ellie "(Colt was my first kiss...)"

        $ young_colt_outfit = "undies"
        $ show_character("colt", "sad", "young")
        colt "You're with Logan. I shouldn't do this to the crew."
        $ young_colt_outfit = "casual"

    if ellie_prom == "Colt":
        $ show_character("ellie")
        ellie "(He was my date to prom...)"
        $ hide_character()

        scene hotel suite sepia at left with fade
        $ young_colt_outfit = "prom"
        $ show_character("colt", modifier="young")
        colt "Every plan I make, I want you there with me."
        colt "A regular path, a regular life? [Ellie_nickname] you're too good for that..."
        $ show_character("colt", "happy", "young")
        colt "You're too bad for it too."

        scene black with fade
        $ show_character("ellie")
        menu:
            ellie "(He loved me and I...)"

            "{image=heart_colt} Loved him back.":
                $ ellie_prom_love = True
                $ show_character("colt", "happy", "young")
                colt "Would have been pretty embarrassing if you didn't say it back."

            "Didn't feel the same.":
                $ ellie_prom_love = False

        $ hide_character()

        scene auto show lounge at center with fade
        "Your focus is pulled back to the present."

    jump ch2_scene3
