
transform inleft():
    offscreenleft
    zoom 0.4
    alpha 0.6
    anchor (1.0, 0.5)
    pos (0.0, 0.5)
    ease 0.3 zoom 1.0 align (0.0, 1.0) alpha 1.0

transform shakeleft():
    zoom 1.0
    alpha 1.0
    anchor (1.0, 0.5)
    align (0.0, 1.0)
    pos (0.0, 1.0)
    linear 0.1 yoffset -10 
    linear 0.1 yoffset +10

transform flipleft():
    offscreenleft
    xzoom -1.0
    zoom 0.4
    alpha 0.6
    anchor (1.0, 0.5)
    pos (0.0, 0.5)
    ease 0.3 zoom 1.0 align (0.0, 1.0) alpha 1.0

transform flip():
    xzoom -1.0
    anchor (0.0, 0.5)
    align (0.0, 1.0)

transform inright():
    offscreenright
    zoom 0.4
    alpha 0.6
    anchor (0.0, 0.5)
    pos (1.0, 0.5)
    ease 0.3 zoom 1.0 align (0.6, 1.0) alpha 1.0

transform shakeright():
    zoom 1.0
    alpha 1.0
    anchor (0.0, 0.5)
    align (0.6, 1.0)
    pos (0.6, 0.98)
    linear 0.05 yoffset -10 
    linear 0.05 yoffset +10

transform flipright():
    offscreenright
    xzoom -1.0
    alpha .4
    zoom 0.4
    anchor (0.0, 0.5)
    pos (1.0, 0.5)
    ease 0.3 zoom 1.0 align (0.6, 1.0) alpha 1.0

transform outleft():
    zoom 1.0
    alpha 1.0
    ease 0.25 zoom 0.6 align (-0.5, 0.6) alpha 0.6
    offscreenleft

transform outright():
    zoom 1.0
    alpha 1.0
    ease 0.25 zoom 0.6 align (1.5, 0.6) alpha 0.6
    offscreenright

transform fulldissolve():
    alpha 0.2
    zoom 1.0
    anchor (1.0, 1.0)
    pos (768, 1360)
    ease .4 alpha 1.0

transform nerve_dissolve():
    alpha 0
    zoom 1.4
    xalign 0.5
    yalign 0.5
    linear 0.4 zoom 1.0 alpha 0.7
    linear 0.2 alpha 0.85
    linear 0.4 zoom 1.3 alpha 0.7
    linear 0.2 alpha 0

transform alpha_button:
    alpha 0.6

define dis = Dissolve(0.2)
define longdissolve = Dissolve(1.2)
define move = MoveTransition(1.0)
define wipedown = CropMove(0.5, mode="custom", startcrop=(0.25, 0.0, 0.5, 1.0), endcrop=(0.0, 0.0, 1.0, 1.0), topnew=False)
image title_cutscene = Transform(Movie(play="images/Video/Title-animation.ogv"), size=(772, 1353))
image noahmc_cg = Movie(play="images/Video/noahmc.ogv")
image abel_cg = Movie(play="images/Video/abel_cg.ogv")
image matthias_cg = Movie(play="images/Video/matthias_cg.ogv")

init python:
    class StarField(object):

        def __init__(self):

            self.sm = SpriteManager(update=self.update)

            # A list of (sprite, starting-x, speed).
            self.stars = [ ]

            # Note: We store the displayable in a variable here.
            # That's important - it means that all of the stars at
            # a given speed have the same displayable. We render that
            # displayable once, and cache the result.

            d = Transform(ColorBlend2("images/particle.png", "#FFF000", 0.75), zoom=10, alpha=0.25)
            for i in range(0, 10):
                self.add(d, 80)

            d = Transform(ColorBlend2("images/particle.png", "#00FF00", 0.75), zoom=7, alpha=0.25)
            for i in range(0, 5):
                self.add(d, 80)

            d = Transform(ColorBlend2("images/particle.png", "#FF0000", 0.75), zoom=7, alpha=0.25)
            for i in range(0, 5):
                self.add(d, 80)

        def add(self, d, speed):
            s = self.sm.create(d)

            start = renpy.random.randint(0, 840)
            s.x = renpy.random.randint(0, 600)

            self.stars.append((s, start, speed))

        def update(self, st):
            for s, start, speed in self.stars:
                s.y = (start + speed * st) % 840 - 20

            return 0

transform my_tr(t=0):
    xpos 1.2 xanchor 0.0
    t*0.5
    linear 1.0 xalign 0.5

transform fromRight:
    subpixel True
    alpha 0.0 xalign 1.0 xanchor 0.0
    parallel:
        easein 1.0 alpha 1.0
    parallel:
        easein 1.0 xalign 0.5
    on hide:
        alpha 1 zoom 1 xanchor 0.5 yanchor 0.5
        block:
            linear 0.1 zoom 1.1
            linear 0.5 zoom 0

transform toOffscreenLeft():
    subpixel True
    truecenter
    ease 0.5 offscreenleft

transform toOffscreenRight():
    subpixel True
    truecenter
    ease 0.5 offscreenright

transform fromOffscreenLeft():
    subpixel True
    offscreenleft
    ease 0.5 truecenter

transform fromOffscreenRight():
    subpixel True
    offscreenright
    ease 0.5 truecenter

transform move_left(fn=None, fn2=None):
    toOffscreenLeft
    function renpy.partial(tfn, callback=fn)
    fromOffscreenRight
    function renpy.partial(tfn, callback=fn2)

transform move_right(fn=None, fn2=None):
    toOffscreenRight
    function renpy.partial(tfn, callback=fn)
    fromOffscreenLeft
    function renpy.partial(tfn, callback=fn2)

transform cave_rumbling:
    subpixel True
    center
    choice:
        linear 0.2 xoffset 5
        linear 0.2 xoffset -5
    repeat

init -2:
    style nvl_dialogue:
        line_spacing 7
    style say_dialogue:
        line_spacing 7

define flash = Fade(0.2, 0.1, 0.2, color='#fff')

init:
    image rain light:
        "images/rain/rain1.png"
        0.2
        "images/rain/rain3.png"
        0.2
        repeat

    image rain:
        "images/rain/rain1.png"
        0.2
        "images/rain/rain3.png"
        0.2
        "images/rain/rain2.png"
        0.2
        repeat

    image matt_cg_shadow:
        "images/cgs/matt cg shadow/matt_cg_1.png"
        .5
        "images/cgs/matt cg shadow/matt_cg_2.png" with longdissolve
        1.2
        "images/cgs/matt cg shadow/matt_cg_3.png" with longdissolve
        1

    image the_end:
        "images/ending cards/The End/the-end-2.png"
        .02
        "images/ending cards/The End/the-end-3.png"
        .02
        "images/ending cards/The End/the-end-4.png"
        .02
        "images/ending cards/The End/the-end-5.png"
        .02
        "images/ending cards/The End/the-end-6.png"
        .02
        "images/ending cards/The End/the-end-7.png"
        .02
        "images/ending cards/The End/the-end-8.png"
        .02
        "images/ending cards/The End/the-end-9.png"
        .02
        "images/ending cards/The End/the-end-10.png"
        .02
        "images/ending cards/The End/the-end-11.png"
        .02
        "images/ending cards/The End/the-end-12.png"
        .02
        "images/ending cards/The End/the-end-13.png"
        .02
        "images/ending cards/The End/the-end-14.png"
        .02
        "images/ending cards/The End/the-end-15.png"
        .02
        "images/ending cards/The End/the-end-16.png"
        .02
        "images/ending cards/The End/the-end-17.png"
        .02
        "images/ending cards/The End/the-end-18.png"
        .02
        "images/ending cards/The End/the-end-19.png"
        .02
        "images/ending cards/The End/the-end-20.png"
        .02
        "images/ending cards/The End/the-end-21.png"
        .02
        "images/ending cards/The End/the-end-22.png"
        .02
        "images/ending cards/The End/the-end-23.png"
        .02
        "images/ending cards/The End/the-end-24.png"
        .02
        "images/ending cards/The End/the-end-25.png"
        .02
        "images/ending cards/The End/the-end-26.png"
        .02
        "images/ending cards/The End/the-end-27.png"
        .02
        "images/ending cards/The End/the-end-28.png"
        .02
        "images/ending cards/The End/the-end-29.png"
        .02
        "images/ending cards/The End/the-end-30.png"
        .02
        "images/ending cards/The End/the-end-31.png"
        .02
        "images/ending cards/The End/the-end-32.png"
        .02
        "images/ending cards/The End/the-end-33.png"
        .02
        "images/ending cards/The End/the-end-34.png"
        .02
        "images/ending cards/The End/the-end-35.png"
        .02
        "images/ending cards/The End/the-end-36.png"
        .02
        "images/ending cards/The End/the-end-37.png"
        .02
        "images/ending cards/The End/the-end-38.png"
        .02
        "images/ending cards/The End/the-end-39.png"
        .02
        "images/ending cards/The End/the-end-40.png"
        .02
        "images/ending cards/The End/the-end-41.png"
        .02
        "images/ending cards/The End/the-end-42.png"
        .02
        "images/ending cards/The End/the-end-43.png"
        .02
        "images/ending cards/The End/the-end-44.png"
        .02
        "images/ending cards/The End/the-end-45.png"
        .02
        "images/ending cards/The End/the-end-46.png"
        .02
        "images/ending cards/The End/the-end-47.png"
        .02
        "images/ending cards/The End/the-end-48.png"
        .02
        "images/ending cards/The End/the-end-49.png"
        .02
        "images/ending cards/The End/the-end-50.png"
        .02
        "images/ending cards/The End/the-end-51.png"
        .02
        "images/ending cards/The End/the-end-52.png"
        .02
        "images/ending cards/The End/the-end-53.png"
        .02
        "images/ending cards/The End/the-end-54.png"
        .02
        "images/ending cards/The End/the-end-55.png"
        .02
        "images/ending cards/The End/the-end-56.png"
        .02
        "images/ending cards/The End/the-end-57.png"
        .02
        "images/ending cards/The End/the-end-58.png"
        .02
        "images/ending cards/The End/the-end-59.png"
        .02
        "images/ending cards/The End/the-end-60.png"
        .02
        "images/ending cards/The End/the-end-61.png"
        .02
        "images/ending cards/The End/the-end-62.png"
        .02
        "images/ending cards/The End/the-end-63.png"
        .02
        "images/ending cards/The End/the-end-64.png"
        .02
        "images/ending cards/The End/the-end-65.png"
        .02
        "images/ending cards/The End/the-end-66.png"
        .02
        "images/ending cards/The End/the-end-67.png"
        .02
        "images/ending cards/The End/the-end-68.png"
        .02
        "images/ending cards/The End/the-end-69.png"
        .02
        "images/ending cards/The End/the-end-70.png"
        .02
        "images/ending cards/The End/the-end-71.png"
        .02
        "images/ending cards/The End/the-end-72.png"
        .02
        "images/ending cards/The End/the-end-73.png"
        .02
        "images/ending cards/The End/the-end-74.png"
        .02
        "images/ending cards/The End/the-end-75.png"
        .02
        "images/ending cards/The End/the-end-76.png"
        .02
        "images/ending cards/The End/the-end-77.png"
        .02
        "images/ending cards/The End/the-end-78.png"
        .02
        "images/ending cards/The End/the-end-79.png"
        .02
        "images/ending cards/The End/the-end-80.png"
        .02
        "images/ending cards/The End/the-end-81.png"
        .02
        "images/ending cards/The End/the-end-82.png"
        .02
        "images/ending cards/The End/the-end-83.png"
        .02
        "images/ending cards/The End/the-end-84.png"
        .02
        "images/ending cards/The End/the-end-85.png"
        .02
        "images/ending cards/The End/the-end-86.png"
        .02
        "images/ending cards/The End/the-end-87.png"
        .02
        "images/ending cards/The End/the-end-88.png"
        .02
        "images/ending cards/The End/the-end-89.png"
        .02
        "images/ending cards/The End/the-end-90.png"
        .02
        "images/ending cards/The End/the-end-91.png"
        .02
        "images/ending cards/The End/the-end-92.png"
        .02
        "images/ending cards/The End/the-end-93.png"
        .02
        "images/ending cards/The End/the-end-94.png"
        .02
        "images/ending cards/The End/the-end-95.png"
        .02
        "images/ending cards/The End/the-end-96.png"
        .02
        "images/ending cards/The End/the-end-97.png"
        .02
        "images/ending cards/The End/the-end-98.png"
        .02
        "images/ending cards/The End/the-end-99.png"
        .02
        "images/ending cards/The End/the-end-100.png"
        .02
        "images/ending cards/The End/the-end-101.png"
        .02
        "images/ending cards/The End/the-end-102.png"
        .02
        "images/ending cards/The End/the-end-103.png"
        .02
        "images/ending cards/The End/the-end-104.png"
        .02
        "images/ending cards/The End/the-end-105.png"
        .02
        "images/ending cards/The End/the-end-106.png"
        .02
        "images/ending cards/The End/the-end-107.png"
        .02
        "images/ending cards/The End/the-end-108.png"
        .02
        "images/ending cards/The End/the-end-109.png"
        .02
        "images/ending cards/The End/the-end-110.png"
        .02
        "images/ending cards/The End/the-end-111.png"
        .02
        "images/ending cards/The End/the-end-112.png"
        .02
        "images/ending cards/The End/the-end-113.png"
        .02
        "images/ending cards/The End/the-end-114.png"
        .02
        "images/ending cards/The End/the-end-115.png"
        .02
        "images/ending cards/The End/the-end-116.png"
        .02
        "images/ending cards/The End/the-end-117.png"
        .02
        "images/ending cards/The End/the-end-118.png"
        .02
        "images/ending cards/The End/the-end-119.png"
        .02
        "images/ending cards/The End/the-end-120.png"
        .02
        "images/ending cards/The End/the-end-121.png"
        .02
        "images/ending cards/The End/the-end-122.png"
        .02
        "images/ending cards/The End/the-end-123.png"
        .02
        "images/ending cards/The End/the-end-124.png"
        .02
        "images/ending cards/The End/the-end-125.png"
        .02
        "images/ending cards/The End/the-end-126.png"
        .02
        "images/ending cards/The End/the-end-127.png"
        .02
        "images/ending cards/The End/the-end-128.png"
        .02
        "images/ending cards/The End/the-end-129.png"
        .02
        "images/ending cards/The End/the-end-130.png"
        .02
        "images/ending cards/The End/the-end-131.png"
        .02
        "images/ending cards/The End/the-end-132.png"
        .02
        "images/ending cards/The End/the-end-133.png"
        .02
        "images/ending cards/The End/the-end-134.png"
        .02
        "images/ending cards/The End/the-end-135.png"
        .02
        "images/ending cards/The End/the-end-136.png"
        .02
        "images/ending cards/The End/the-end-137.png"
        .02
        "images/ending cards/The End/the-end-138.png"
        .02
        "images/ending cards/The End/the-end-139.png"
        .02
        "images/ending cards/The End/the-end-140.png"
        .02
        "images/ending cards/The End/the-end-141.png"
        .02
        "images/ending cards/The End/the-end-142.png"
        .02
        "images/ending cards/The End/the-end-143.png"
        .02
        "images/ending cards/The End/the-end-144.png"
        .02
        "images/ending cards/The End/the-end-145.png"
        .02
        "images/ending cards/The End/the-end-146.png"
        .02
        "images/ending cards/The End/the-end-147.png"
        .02
        "images/ending cards/The End/the-end-148.png"
        .02
        "images/ending cards/The End/the-end-149.png"
        .02
        "images/ending cards/The End/the-end-150.png"
        .02
        "images/ending cards/The End/the-end-151.png"
        .02
        "images/ending cards/The End/the-end-152.png"
        .02
        "images/ending cards/The End/the-end-153.png"
        .02
        "images/ending cards/The End/the-end-154.png"
        .02
        "images/ending cards/The End/the-end-155.png"
        .02
        "images/ending cards/The End/the-end-156.png"
        .02
        "images/ending cards/The End/the-end-157.png"
        .02
        "images/ending cards/The End/the-end-158.png"
        .02
        "images/ending cards/The End/the-end-159.png"
        .02
        "images/ending cards/The End/the-end-160.png"
        .02
        "images/ending cards/The End/the-end-161.png"
        .02
        "images/ending cards/The End/the-end-162.png"
        .02
init python:
    def tfn(tr, st, at, callback=None):
        fn = callback

        if callable(fn):
            fn()
            renpy.restart_interaction()

    def ColorBlend(d, color="#00FFFF"):
        return Transform(d, matrixcolor=BrightnessMatrix(0.25)*TintMatrix(color))

    def ColorBlend2(d, color="#FFF", alpha=.25):
        return AlphaBlend(Transform(d, alpha = alpha), d, Solid(color, xysize=(config.screen_width, config.screen_height)), alpha=True)

    def Desaturate(d):
        return Transform(d, matrixcolor=SaturationMatrix(0.0))

default driving_bg = "driving freeway day bg"

image driving bg animation:
    driving_bg with PushMove(0.5, "pushleft")
    pause 0.5
    repeat

default car_overlay = "fancy car overlay"

image car driving animation:
    car_overlay
    pause 1.5
    linear 0.2 yoffset -10 
    linear 0.2 yoffset +10
    pause 1.5
    repeat

image new york view rail empty = Transform(Composite(
                    (769, 1650),
                        (-500, -300), "images/backgrounds_TPA/new york view empty.png",
                ), zoom=0.7)

image new york view rail mona = Transform(Composite(
                    (769, 1650),
                        (-500, -300), "images/backgrounds_TPA/new york view empty.png",
                        (-500, -300), "images/Mona/new york view.png"
                ), zoom=0.7)

image new york view rail mona ellie = Transform(Composite(
                    (769, 1650),
                        (-500, -300), "images/backgrounds_TPA/new york view empty.png",
                        (-500, -300), "images/Mona/new york view.png",
                        (-500, -300), "Create_Character/Ellie/ellie_new_york_view_[ellie_race].png"
                ), zoom=0.7)

image new york view rail ingrid = Transform(Composite(
                    (769, 1650),
                        (-500, -300), "images/backgrounds_TPA/new york view empty.png",
                        (-500, -300), "images/Ingrid/new york view.png"
                ), zoom=0.7)

image new york view rail ingrid ellie = Transform(Composite(
                    (769, 1650),
                        (-500, -300), "images/backgrounds_TPA/new york view empty.png",
                        (-500, -300), "images/Ingrid/new york view.png",
                        (-500, -300), "Create_Character/Ellie/ellie_new_york_view_[ellie_race].png"
                ), zoom=0.7)

image ellie hand = Transform(Composite(
                    (769, 1650),
                        (-500, -150), "Create_Character/Ellie/ellie_new_york_view_[ellie_race].png",
                ), zoom=0.7)

image new_york_view_ellie_animation:
    "ellie hand"
    anchor (0.5, 0.5)
    pos (1.0, 0.3)
    linear 0.25 pos (0.5, 0.5)