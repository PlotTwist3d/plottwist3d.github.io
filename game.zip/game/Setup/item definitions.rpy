screen item(name, title=""):
    add "gui/overlay/confirm.png" at item_dissolve
    add "images/Bubbles/Reaction Bubble Neutral MC.png" at item_dissolve:
        xpos 150
        ypos -100
    add "images/items/[name].png" at item_dissolve:
        zoom 1
        xpos 150
        ypos 350

    text "[title]":
        style "item_text"
        xalign 0.5
        ypos 900

screen item_choice(choice_text, confirm_selection=False):

    # item: name, bubble, button_text, jump_label
    zorder 10000001
    add "gui/overlay/confirm.png" at item_dissolve

    imagebutton:
        idle Transform(Composite(
                    (400, 400),
                        (0,0), "images/Bubbles/item bubble [item1_bubble].png",
                        (0,0), "images/items/[item1].png"
                ), zoom=0.75, alpha=0.75)
        hover Transform(Composite(
                    (400, 400),
                        (0,0), "images/Bubbles/item bubble [item1_bubble].png",
                        (0,0), "images/items/[item1].png"
                ), zoom=0.75, alpha=1.0)
        selected (selected_item=="choice1")
        selected_idle Transform(Composite(
                        (400, 400),
                            (0,0), "images/Bubbles/item bubble [item1_bubble].png",
                            (0,0), "images/items/[item1].png"
                    ), zoom=0.78)
        selected_hover Transform(Composite(
                        (400, 400),
                            (0,0), "images/Bubbles/item bubble [item1_bubble].png",
                            (0,0), "images/items/[item1].png"
                    ), zoom=0.78)
        xpos 50
        ypos 200
        if confirm_selection:
            action [SetVariable("selected_item", "choice1"), Show("confirm_item_selection")]
        else:
            action [SetVariable("selected_item", "choice1"), Hide("item_choice"), Show("show_selected_item")]

    imagebutton:
        idle Transform(Composite(
                    (400, 400),
                        (0,0), "images/Bubbles/item bubble [item2_bubble].png",
                        (0,0), "images/items/[item2].png"
                ), zoom=0.75, alpha=0.75)
        hover Transform(Composite(
                    (400, 400),
                        (0,0), "images/Bubbles/item bubble [item2_bubble].png",
                        (0,0), "images/items/[item2].png"
                ), zoom=0.75, alpha=1.0)
        selected (selected_item=="choice2")
        selected_idle Transform(Composite(
                        (400, 400),
                            (0,0), "images/Bubbles/item bubble [item2_bubble].png",
                            (0,0), "images/items/[item2].png"
                    ), zoom=0.78)
        selected_hover Transform(Composite(
                        (400, 400),
                            (0,0), "images/Bubbles/item bubble [item2_bubble].png",
                            (0,0), "images/items/[item2].png"
                    ), zoom=0.78)
        xpos 400
        ypos 400
        if confirm_selection:
            action [SetVariable("selected_item", "choice2"), Show("confirm_item_selection")]
        else:
            action [SetVariable("selected_item", "choice2"), Hide("item_choice"), Show("show_selected_item")]

    imagebutton:
        idle Transform(Composite(
                    (400, 400),
                        (0,0), "images/Bubbles/item bubble [item3_bubble].png",
                        (0,0), "images/items/[item3].png"
                ), zoom=0.75, alpha=0.75)
        hover Transform(Composite(
                    (400, 400),
                        (0,0), "images/Bubbles/item bubble [item3_bubble].png",
                        (0,0), "images/items/[item3].png"
                ), zoom=0.75, alpha=1.0)
        selected (selected_item=="choice3")
        selected_idle Transform(Composite(
                        (400, 400),
                            (0,0), "images/Bubbles/item bubble [item3_bubble].png",
                            (0,0), "images/items/[item3].png"
                    ), zoom=0.78)
        selected_hover Transform(Composite(
                        (400, 400),
                            (0,0), "images/Bubbles/item bubble [item3_bubble].png",
                            (0,0), "images/items/[item3].png"
                    ), zoom=0.78)
        xpos 50
        ypos 600
        if confirm_selection:
            action [SetVariable("selected_item", "choice3"), Show("confirm_item_selection")]
        else:
            action [SetVariable("selected_item", "choice3"), Hide("item_choice"), Show("show_selected_item")]

    text "[choice_text]":
        style "item_text"
        xalign 0.5
        ypos 1050

    if timeout_label:
        use timer_clock

default item1 = "steering straight"
default item2 = "pedal gas"
default item3 = "pedal break"

default item1_bubble = "neutral"
default item2_bubble = "neutral"
default item3_bubble = "neutral"

default item1_text = "The first one!"
default item2_text = "The second one!"
default item3_text = "The last one!"

default item1_jump = "customization_end"
default item2_jump = "customization_end"
default item3_jump = "customization_end"

screen confirm_item_selection():
    zorder 10000002
    #style_prefix "choice"

    imagebutton:
        idle "gui/choice_idle_background.png"
        hover "gui/choice_hover_background.png"

        xpos 40
        ypos 1100

        action [Hide("confirm_item_selection"), Hide("item_choice"), Show("show_selected_item")]

    if selected_item == "choice1":
        text "[item1_text]":
            xalign 0.5
            ypos 1140
    elif selected_item == "choice2":
        text "[item2_text]":
            xalign 0.5
            ypos 1140
    else:
        text "[item3_text]":
            xalign 0.5
            ypos 1140

screen show_selected_item():
    if selected_item == "choice1":
        add Transform(Composite(
                    (400, 400),
                        (0,0), "images/Bubbles/item bubble [item1_bubble].png",
                        (0,0), "images/items/[item1].png"
        ), zoom=0.78, xpos=50, ypos=200) at animate_choice_item1

        timer 2.0 action [Hide("show_selected_item"), Jump(item1_jump)]

        text "[item1_text]":
            style "item_text"
            xalign 0.5
            ypos 1050

    elif selected_item == "choice2":
        add Transform(Composite(
                    (400, 400),
                        (0,0), "images/Bubbles/item bubble [item2_bubble].png",
                        (0,0), "images/items/[item2].png"
        ), zoom=0.78, xpos=400, ypos=400) at animate_choice_item1, animate_choice_item2

        timer 2.0 action [Hide("show_selected_item"), Jump(item2_jump)]

        text "[item2_text]":
            style "item_text"
            xalign 0.5
            ypos 1050

    else:
        add Transform(Composite(
                    (400, 400),
                        (0,0), "images/Bubbles/item bubble [item3_bubble].png",
                        (0,0), "images/items/[item3].png"
        ), zoom=0.78, xpos=400, ypos=400) at animate_choice_item1, animate_choice_item3

        timer 2.5 action [Hide("show_selected_item"), Jump(item3_jump)]

        text "[item3_text]":
            style "item_text"
            xalign 0.5
            ypos 1050

default selected_item = None

transform animate_choice_item1:
    ease 2.0 zoom 1.5

transform animate_choice_item2:
    pos (400, 400)
    ease 2.0 align (0.4, 0.4)

transform animate_choice_item3:
    pos (50, 600)
    ease 2.0 align (0.4, 0.4)

style item_text:
    font "Fonts/TTSupermolotNeue-ExtraBold.ttf"
    color "#000000"
    outlines [ (4, "#ffff", absolute(0), absolute(0)) ]
    size 40

transform item_dissolve():
    alpha 0
    ease .3 alpha 1.0
