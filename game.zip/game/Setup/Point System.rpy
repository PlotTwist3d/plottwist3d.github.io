transform point_text_transform():
    xalign 0.5
    yalign 0.5
    zoom 0.1
    ease 0.3 zoom 1.2
    ease 0.1 zoom 1.0
    linear 1.25 yalign 0.3

screen point_gained(my_txt):
    text my_txt size 35 color "#E5DBD9" outlines [ (absolute(1), "#292928", absolute(0), absolute(0)) ] font "Fonts/Sofia Pro Semi Bold Az.otf" at point_text_transform
    timer 0.9 action Hide("point_gained", dissolve)
    zorder 10000000000000000

transform center_image:
    align (0.5, 0.5)
    
init python:
    def show_point_gained(txt):
        renpy.show_screen("point_gained", my_txt=txt)

    def check_points():
        global suave_points, suave_points_old, serious_points, serious_points_old
        if suave_points > suave_points_old:
            show_point_gained("+{image=suave_point_image}")
            suave_points_old = suave_points
        if serious_points > serious_points_old:
            show_point_gained("+{image=serious_point_image}")
            serious_points_old = serious_points

    config.python_callbacks.append(check_points)

    def completed_mission(required_value, current_value, 
                            achievement_success_title=None, achievement_success_text=None,
                            achievement_failure_title=None, achievement_failure_text=None):
        if current_value >= required_value:
            if achievement_success_title is not None:
                my_notify_func("gui/notify.png", achievement_success_title, achievement_success_text)
            return True
            
        else:
            if achievement_failure_title is not None:
                my_notify_func("gui/notify.png", achievement_failure_title, achievement_failure_text)
            return False
            
