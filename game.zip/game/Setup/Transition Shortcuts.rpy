### Transition shortcuts
init python:

    def ssl(name, flip_left=False, shake=False):
        """
        FOR PC
        shows new emotion
        """
        renpy.hide(name)
        if flip_left:
            renpy.show(name, at_list=[flip])
        else:
            renpy.show(name)
        renpy.with_statement(Dissolve(0.2))

    def slr(name1, name2, shake=False):
        """
        FOR NPC
        shows new emotion
        """
        renpy.hide(name1)
        sr(name2, shake=False)
        renpy.with_statement(Dissolve(0.2))

    def srl(name1, name2, shake=False):
        """
        FOR NPC-PC after ssr
        shows new emotion
        """
        renpy.hide(name1)
        sl(name2, shake=False)
        renpy.with_statement(Dissolve(0.2))

    def ssr(name, flip_right=False, shake=False):
        """
        FOR NPC
        shows new emotion
        """
        renpy.show(name)
        if flip_right:
            renpy.show(name, at_list=[flipright])
        else:
            renpy.show(name)
        renpy.with_statement(Dissolve(0.2))
        if shake:
            renpy.show(name, at_list=[shakeright])

    def sl(name, shake=False):
        """
        FOR PC
        shows name inleft
        """
        renpy.show(name, at_list=[inleft])
        renpy.with_statement(Dissolve(0.2))
        if shake:
            renpy.show(name, at_list=[shakeleft])

    def sr(name, shake=False):
        """
        FOR NPC
        shows name inright
        """
        renpy.show(name, at_list=[inright])
        renpy.with_statement(Dissolve(0.2))
        if shake:
            renpy.show(name, at_list=[shakeright])

    def hl(name):
        """
        FOR PC
        hides name outleft
        and adds 0.3s pause
        """
        renpy.show(name, at_list = [outleft])
        renpy.pause(0.15)

    def hr(name):
        """
        FOR NPC
        hides name outright
        and adds 0.3s pause
        """
        renpy.show(name, at_list = [outright])
        renpy.pause(0.15)

    def lr(name1, name2, shake=False):
        """
        FOR PC-NPC
        hides name1 outleft and
        shows name2 inright
        """

        hl(name1)
        renpy.pause(0.15)
        sr(name2, shake)

    def rl(name1, name2, shake=False):
        """
        FOR NPC-PC
        hides name1 outright and
        shows name2 inleft
        """
        hr(name1)
        renpy.pause(0.15)
        sl(name2, shake)

    def rr(name1, name2, shake=False):
        """
        FOR NPC-NPC
        hides name1 outright and
        shows name2 inright
        """
        renpy.show(name1, zorder=0)
        renpy.show(name2, at_list = [inright], zorder=1)
        renpy.with_statement(Dissolve(0.2))
        hr(name1)
        if shake:
            renpy.show(name2, at_list=[shakeright])

    def fr(name):
        """
        FOR RIGHT-SIDE MC
        flips character to the right side
        and shows it inright
        """
        renpy.show(name, at_list = [flipright])
        renpy.with_statement(Dissolve(0.2))

    def fl(name):
        """
        FOR LEFT-SIDE NON-MC PC
        flips character to the left side
        and shows it inleft
        """
        renpy.show(name, at_list = [flipleft])
        renpy.with_statement(Dissolve(0.2))

    def rfl(name1, name2):
        """
        FOR NPC and NON-MC PC
        hides name1 outright and
        shows name2 flipleft
        """
        hr(name1)
        fl(name2)

    def rfr(name1, name2):
        """
        FOR NON-MC PC and NON-PC MC
        hides name1 outright and
        shows name2 flipright
        """
        renpy.show(name1, zorder=0)
        renpy.show(name2, at_list = [flipright], zorder=1)
        renpy.with_statement(Dissolve(0.2))
        hr(name1)

    def lfr(name1, name2):
        """
        FOR NON-MC PC and NON-PC MC
        hides name1 outright and
        shows name2 flipright
        """
        hl(name1)
        sr(name2)

    def sf(name):
        renpy.show(name, at_list = [fulldissolve])
        renpy.with_statement(Dissolve(0.5))

    def show_character(name, with_mood="neutral", modifier=None, shake=False):
        """
        Example that displays ingrid holo with mood sad
        [required] name: ingrid
        modifier: holo
        with_mood: "sad"
        """
        
        global current_speaker, current_mood, playable_character

        next_speaker = name

        if modifier is not None:
            next_speaker += " " + modifier

        if playable_character == name.upper(): # show on the right
            if current_speaker == next_speaker: # same character
                current_mood = with_mood
                flip = False
                if playable_character != "ELLIE": # not usually MC
                    flip = True
                ssl(next_speaker, flip, shake)

            elif current_speaker == None: # no character
                current_mood = with_mood
                if playable_character != "ELLIE":
                    fl(next_speaker)
                elif playable_character != "ELLIE" and "ellie" in next_speaker:
                    fr(next_speaker)
                else:
                    sl(next_speaker, shake)

            else:
                # hide right and show MC left
                hr(current_speaker)
                
                current_mood = with_mood
                if playable_character != "ELLIE":
                    fl(next_speaker)
                else:
                    sl(next_speaker, shake)
        
        else:
            # show NPC
            if current_speaker == next_speaker: # same character
                current_mood = with_mood
                ssr(next_speaker, False, shake)

            elif current_speaker == None: # no character
                current_mood = with_mood
                sr(next_speaker, shake)
            
            else: # different character
                name_without_modifier = current_speaker.split(" ")[0]

                if playable_character == name_without_modifier.upper(): # last shown was PC
                    hl(current_speaker)

                    current_mood = with_mood
                    sr(next_speaker, shake)
                
                else: # last shown was NPC
                    hr(current_speaker)

                    current_mood = with_mood
                    sr(next_speaker, shake)

        current_speaker = next_speaker

    def hide_character():
        global current_speaker, playable_character

        if current_speaker == None:
            return

        name_without_modifier = current_speaker.split(" ")[0]

        if playable_character == name_without_modifier.upper():
            hl(current_speaker)
        else:
            hr(current_speaker)

        current_speaker = None
