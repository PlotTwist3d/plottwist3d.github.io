init python:
    #Devon

    def NextGreyModel():
        global grey_race

        if grey_race < 3:
            grey_race += 1
        else:
            grey_race = 1

    def PrevGreyModel():
        global grey_race

        if grey_race > 1:
            grey_race -= 1
        else:
            grey_race = 3

    def NextLoganModel():
        global logan_race

        if logan_race < 4:
            logan_race += 1
        else:
            logan_race = 1

    def PrevLoganModel():
        global logan_race

        if logan_race > 1:
            logan_race -= 1
        else:
            logan_race = 4

    def NextJonesBody():
        global jones_body

        if jones_body < 2:
            jones_body += 1
        else:
            jones_body = 1

    def PrevJonesBody():
        global jones_body

        if jones_body > 1:
            jones_body -= 1
        else:
            jones_body = 2

    def NextJonesModel():
        global jones_race

        if jones_race < 4:
            jones_race += 1
        else:
            jones_race = 1

    def PrevJonesModel():
        global jones_female, jones_race

        if jones_race > 1:
            jones_race -= 1
        else:
            jones_race = 4

    def NextJonesHair():
        global jones_female, jones_hair

        if jones_hair < 6:
            jones_hair += 1
        else:
            jones_hair = 1

    def PrevJonesHair():
        global jones_female, jones_hair

        if jones_hair > 1:
            jones_hair -= 1
        else:
            jones_hair = 6

    def NextEllieModel():
        global ellie_race

        if ellie_race < 4:
            ellie_race += 1
        else:
            ellie_race = 1

    def PrevEllieModel():
        global ellie_race

        
        if ellie_race > 1:
            ellie_race -= 1
        else:
            ellie_race = 4

    def NextEllieHair():
        global ellie_hair

        if ellie_hair < 10:
            ellie_hair += 1
        else:
            ellie_hair = 1

    def PrevEllieHair():
        global ellie_hair

        if ellie_hair > 1:
            ellie_hair -= 1
        else:
            ellie_hair = 10

    def NextEllieTattoo():
        global ellie_tattoo

        if ellie_tattoo < 7:
            ellie_tattoo += 1
        else:
            ellie_tattoo = 0

    def PrevEllieTattoo():
        global ellie_tattoo

        if ellie_tattoo > 0:
            ellie_tattoo -= 1
        else:
            ellie_tattoo = 7
    
    def NextEllieOutfit():
        global ellie_outfit

        if ellie_outfit < 2:
            ellie_outfit += 1
        else:
            ellie_outfit = 1

    def PrevEllieOutfit():
        global ellie_outfit

        if ellie_outfit > 1:
            ellie_outfit -= 1
        else:
            ellie_outfit = 2