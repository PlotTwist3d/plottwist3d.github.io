screen timer_clock:
    zorder 10001

    $ clock_time = clock_time
    
    #timer clock_time repeat True action If(clock_time > 0, true=SetVariable("clock_time", clock_time - 0.1), false=[Hide("timer_clock"), Jump(timeout_label)])
    timer clock_time repeat False action [Hide("timer_clock"), Jump(timeout_label)]

    add "gui/timer_empty.png":
        zoom 0.5
        if regular:
            xpos 550
            ypos 750
        elif middle:
            xpos 650
            ypos 450
        else:
            xalign 0.45
            yalign 0.45

    add "clockanimation":
        zoom 0.5
        if regular:
            xpos 550
            ypos 750
        elif middle:
            xpos 650
            ypos 450
        else:
            xalign 0.45
            yalign 0.45

default clock_time = 7

image clockanimation:
    "gui/timer_full.png"
    pause 0.5
    "gui/timer_empty.png" with ImageDissolve("gui/timer_dissolve.png", time=clock_time - 0.5)
   

screen settingsUI:
    zorder 10000
    imagebutton:
        xalign 1.0
        yalign 0.0
        xoffset -10
        yoffset 55
        idle "gui/menu_idle.png"
        hover "gui/menu_hover.png"
        action ShowMenu("preferences")

    imagebutton:
        xalign 1.0
        yalign 0.0
        xoffset -10
        yoffset 145
        idle "gui/ff_idle.png"
        hover "gui/ff_hover.png"
        action Skip() alternate Skip(fast=True, confirm=True)

screen suave_and_serious_points():
    zorder 10000
        #### point counter for suave
    add "gui/overlay/red_point_counter.png":
        pos (50, 0)
    add "images/suave.png":
        pos (67, 35)

    text str(suave_points) pos (170, 40)

    #### point counter for serious
    add "gui/overlay/blue_point_counter.png":
        pos (400, 0)
    add "images/serious.png":
        pos (417, 20)

    text str(serious_points) pos (520, 40)

screen location_title(location):
    zorder 10000
    #### point counter for suave
    add "images/overlays/[location].png":
        pos (200, 500)
        zoom 0.6

screen gameUI:
    zorder 1000000000000000000
    imagebutton:
        xalign 1.0
        yalign 0.0
        xoffset -30
        yoffset 30
        idle "gui/stats_idle.png"
        hover "gui/stats_hover.png"
        action ShowMenu("settingsUI")

screen home_menu:
    add "images/backgrounds/smoky background.jpg"
    add "gui/overlay/confirm.png"
    zorder 100000000
    imagebutton:
        xalign 1.0
        yalign 0.0
        xoffset -30
        yoffset 30
        idle "gui/return_idle.png"
        hover "gui/return_hover.png"
        action Return()
        alternate Return()
    imagebutton:
        xalign 1.0
        yalign 0.0
        xoffset -30
        yoffset 120
        idle "gui/settings_idle.png"
        hover "gui/settings_hover.png"
        action ShowMenu("save")

    #if setup_complete and (not flashback and rowan_outfit != "Fight" and rowan_outfit != "robe" and rowan_outfit != "Matthias" and rowan_outfit != "Lincoln" and playing_as == capsRowan):
    #    imagebutton:
    #        xalign 1.0
    #        yalign 0.0
    #        xoffset -32
    #        yoffset 210
    #        idle "gui/closet_button_idle.png"
    #        hover "gui/closet_button_hover.png"
    #        action ShowMenu("closet")
    #        alternate ShowMenu("closet")
    #        keysym "c"
    #        alternate_keysym "c"

screen StatsUI:
    zorder 10000000000000
    use game_menu(_("{color=#888888}{font=fonts/TTSupermolotNeue-ExtraBold.ttf}{size=45}STATS"), scroll=("vpgrid" if gui.history_height else "viewport"), yinitial=1.0):
        imagebutton:
            xalign 1.0
            yalign 0.0
            xoffset -30
            yoffset 30
            auto "gui/return_%s.png"
            action Return()

        hbox:
            vbox:
                spacing 10
                text "{color=#ffff}Suave Points{/color}" size 35
                text "{color=#ffff}Serious Points{/color}" size 35
                text "" size 1
                text "{color=#ffff}Ingrid Relationship{/color} [ingrid_relationship]" size 35
                text "" size 1
                text "{color=#ffff}Mona Relationship{/color} [mona_relationship]" size 35
                text "" size 1
                text "{color=#ffff}Colt Relationship{/color} [colt_relationship]" size 35
                text "" size 1
                text "{color=#ffff}Logan Relationship{/color} [logan_relationship]" size 35
                text "" size 1
                text "{color=#ffff}Ingrid Romance{/color}" size 35
                text "{color=#ffff}Mona Romance{/color}" size 35
                text "{color=#ffff}Colt Romance{/color}" size 35
                text "{color=#ffff}Logan Romance{/color}" size 35

            vbox:
                spacing 10
                text "{color=#ffff}[suave_points] out of [maximum_suave_points]{/color}" size 35
                text "{color=#ffff}[serious_points] out of [maximum_serious_points]{/color}" size 35

                text "{image=images/icons/[ingrid_relationship_icon].png}"
                text "{image=images/icons/[mona_relationship_icon].png}"
                text "{image=images/icons/[colt_relationship_icon].png}"
                text "{image=images/icons/[logan_relationship_icon].png}"

                if current_li == "Ingrid":
                    text "{color=#ffff}[ingrid_romance] (LI){/color}"
                else:
                    text "{color=#ffff}[ingrid_romance]{/color}"

                if current_li == "Mona":
                    text "{color=#ffff}[mona_romance] (LI){/color}"
                else:
                    text "{color=#ffff}[mona_romance]{/color}"

                if current_li == "Colt":
                    text "{color=#ffff}[colt_romance] (LI){/color}"
                else:
                    text "{color=#ffff}[colt_romance]{/color}"

                if current_li == "Logan":
                    text "{color=#ffff}[logan_romance] (LI){/color}"
                else:
                    text "{color=#ffff}[logan_romance]{/color}"

#click to continue
screen ctc:
    zorder 100
    add "gui/ctc.png" at ctc_appear
    text _("{i}TAP TO CONTINUE{/i}") at ctc_text:
        size 30 font "Fonts/TTSupermolotNeue-ExtraBold.ttf" color "#ffffff"
screen ctc_text:
    zorder 100
    text _("{i}TAP TO CONTINUE{/i}") at ctc_text:
        size 30 font "Fonts/TTSupermolotNeue-ExtraBold.ttf" color "#ffffff"

transform ctc_text:
    alpha 0.0
    xalign .5
    yalign .98
    pause 5.0
    ease 0.35 alpha 0.5

transform ctc_appear:
    alpha 0.0
    xalign .5
    yalign .93
    zoom .45
    pause 5.0
    block:
        ease 0.35 alpha 1.0 zoom .65
        ease 0.35 zoom .45
        ease 0.25 zoom .58
        ease 0.25 zoom .45
        pause 1.5
        repeat
    repeat
