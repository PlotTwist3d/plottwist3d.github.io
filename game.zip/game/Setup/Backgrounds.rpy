transform left_to_right:
    xalign 0.0
    yalign 1.0
    ease 1.0 xalign 1.0

transform mid_right:
    xalign 0.75
    yalign 1.0

transform mid_right_to_left:
    xalign 0.75
    yalign 1.0
    ease 2.0 xalign 0.0

transform mid_right_to_right:
    xalign 0.75
    yalign 1.0
    ease 2.0 xalign 1.0

transform mid_left:
    xalign 0.25
    yalign 1.0

transform mid_left_to_right:
    xalign 0.25
    yalign 1.0
    ease 2.0 xalign 1.0

transform mid_left_to_mid_right:
    xalign 0.25
    yalign 1.0
    ease 2.0 xalign 0.75

transform mid_left_to_left:
    xalign 0.25
    yalign 1.0
    ease 2.0 xalign 0.0

transform right_to_mid_right:
    xalign 1.0
    yalign 1.0
    ease 2.0 xalign 0.75

transform right_to_mid:
    xalign 1.0
    yalign 1.0
    ease 2.0 xalign 0.5

transform right_to_mid_left:
    xalign 1.0
    yalign 1.0
    ease 2.0 xalign 0.25

transform mid_left_to_left:
    xalign 0.25
    yalign 1.0
    ease 2.0 xalign 0.0

transform left_to_mid_right:
    xalign 0.0
    yalign 1.0
    ease 2.0 xalign 0.75

transform lg_left_to_right:
    xalign 0.0
    yalign 1.0
    ease 2.0 xalign 1.0

transform left_to_mid:
    xalign 0.0
    yalign 1.0
    ease 1.0 xalign 0.5

transform right_to_left:
    xalign 1.0
    yalign 1.0
    ease 1.0 xalign 0.0

transform lg_right_to_left:
    xalign 1.0
    yalign 1.0
    ease 2.0 xalign 0.0

transform right_to_mid:
    xalign 1.0
    yalign 1.0
    ease 1.0 xalign 0.5

transform mid_to_left:
    xalign 0.5
    yalign 1.0
    ease 1.0 xalign 0.0

transform mid_to_right:
    xalign 0.5
    yalign 1.0
    ease 1.0 xalign 1.0


#heart
image heart = "images/heart.png"
image heartbreak = "images/heartbreak.png"
#ok emoji
image okhand = "images/ok hand.png"

default left_image = None
default right_image = None

image split_screen = Transform(Composite(
                    (1688, 2048),
                        (0, 420), AlphaMask("[right_image]", "images/overlays/split screen alpha mask.png", invert=True),
                        (0, 420), "images/overlays/screen separator.png"
                ), zoom=1)

#### PTA
image closet = Transform("images/backgrounds_TPA/closet.jpg", zoom=1)
image blur summer background = Transform("images/backgrounds_TPA/blur summer background.jpg", zoom=1)
image new york street day = Transform("images/backgrounds_TPA/new york street day.jpg", zoom=0.75)
image new york street night = Transform("images/backgrounds_TPA/new york street night.jpg", zoom=0.75)
image nightclub vip = Transform("images/backgrounds_TPA/nightclub vip.jpg", zoom=0.75)
image hallway apartment = Transform("images/backgrounds_TPA/hallway apartment.jpg", zoom=0.8)
image apartment night = Transform("images/backgrounds_TPA/apartment night.jpg", zoom=0.75)
image gaia plane = Transform("images/backgrounds_TPA/gaia private jet.jpg", zoom=0.8)
image junk = Transform("images/backgrounds_TPA/junk.jpg", zoom=0.8)
image gaia prison = Transform("images/backgrounds_TPA/gaia prison.jpg", zoom=0.8)

#### ROD
image underground rave = Transform("images/backgrounds_ROD/underground rave.jpg", zoom=0.75)
image underground rave sepia = Transform(Transform("images/backgrounds_ROD/underground rave.jpg", zoom=0.75), matrixcolor=SepiaMatrix())
image hallway fancy = Transform("images/backgrounds_ROD/hallway fancy.jpg", zoom=0.8)
image hallway fancy sepia = Transform(Transform("images/backgrounds_ROD/hallway fancy.jpg", zoom=0.8), matrixcolor=SepiaMatrix())
image hotel suite = Transform("images/backgrounds_ROD/hotel suite.jpg", zoom=0.8)
image hotel suite sepia = Transform(Transform("images/backgrounds_ROD/hotel suite.jpg", zoom=0.8), matrixcolor=SepiaMatrix())
image parking school day = Transform("images/backgrounds_ROD/parking school day.jpg", zoom=0.75)
image parking school day sepia = Transform(Transform("images/backgrounds_ROD/parking school day.jpg", zoom=0.75), matrixcolor=SepiaMatrix())
image prom = Transform("images/backgrounds_ROD/prom.jpg", zoom=0.75)
image prom sepia = Transform(Transform("images/backgrounds_ROD/prom.jpg", zoom=0.75), matrixcolor=SepiaMatrix())
image driving freeway day bg = Transform("images/backgrounds_ROD/driving freeway day.jpg", zoom=0.8)
image car sideshow = Transform("images/backgrounds_ROD/car sideshow.jpg", zoom=0.75)
image car sideshow sepia = Transform(Transform("images/backgrounds_ROD/car sideshow.jpg", zoom=0.75), matrixcolor=SepiaMatrix())

#### PRISON
image prison security office = Transform("images/backgrounds/prison/prison security office.jpg", zoom=0.8)
image prison interrogation room = Transform("images/backgrounds/prison/interrogation room.jpg", zoom=0.8)
image prison cell dirty = Transform("images/backgrounds/prison/prison cell dirty.jpg", zoom=0.8)
image prison cell clean = Transform("images/backgrounds/prison/prison cell clean.jpg", zoom=0.75)
image prison isolation hallway = Transform("images/backgrounds/prison/prison isolation hallway.jpg", zoom=0.8)
image prison patio = Transform("images/backgrounds/prison/prison patio.jpg", zoom=0.8)
image prison cafeteria = Transform("images/backgrounds/prison/prison cafeteria.jpg", zoom=0.8)

#### BARS AND RESTAURANTS
image interior bar artedeco = Transform("images/backgrounds_TPA/interior bar artedeco.jpg", zoom=0.8)
image bar desert road = Transform("images/backgrounds/bar/bar desert road.jpg", zoom=0.8)
image bar alley = Transform("images/backgrounds/bar/bar alley.jpg", zoom=0.8)
image bar pool table = Transform("images/backgrounds/bar/bar pool table.jpg", zoom=0.8)
image diner 50s day = Transform("images/backgrounds/cafe/diner 50s day.jpg", zoom=0.7)
image diner 50s night = Transform("images/backgrounds/cafe/diner 50s night.jpg", zoom=0.7)
image coffee shop day = Transform("images/backgrounds/cafe/coffee shop day.jpg", zoom=0.8)
image restaurant rustic neutral = Transform("images/backgrounds/cafe/restaurant rustic neutral.jpg", zoom=0.8)

#### SAFEHOUSE
image safehouse basic = Transform("images/backgrounds/safehouse/safehouse basic.jpg", zoom=0.8)
image safehouse fancy day = Transform("images/backgrounds/safehouse/safehouse fancy day.jpg", zoom=0.8)
image safehouse fancy night = Transform("images/backgrounds/safehouse/safehouse fancy night.jpg", zoom=0.8)
image safehouse computers = Transform("images/backgrounds/safehouse/safehouse computers.jpg", zoom=0.7)
image safehouse simple = Transform("images/backgrounds/safehouse/safehouse simple.jpg", zoom=0.7)
image safehouse illegal = Transform("images/backgrounds/safehouse/safehouse illegal.jpg", zoom=0.7)

#### DRIVING
image city day car = Transform("images/backgrounds/driving/city day car.jpg", zoom=0.7)
image front car coastal = Transform("images/backgrounds/driving/front car coastal.jpg", zoom=0.7)
image highway day car = Transform("images/backgrounds/driving/highway day car.jpg", zoom=0.7)
image fancy car overlay = Transform("images/backgrounds/driving/fancy car overlay.png", zoom=0.75, ypos=1500)

#### BEACH
image coastal beach = Transform("images/backgrounds/beach/coastal beach.jpg", zoom=0.8)
image beach ocean front = Transform("images/backgrounds/beach/beach ocean front.jpg", zoom=0.8)

#### AUTO SHOP
image auto shop inside = Transform("images/backgrounds/auto shop/auto shop inside.jpg", zoom=0.8)
image auto shop inside sepia = Transform(Transform("images/backgrounds/auto shop/auto shop inside.jpg", zoom=0.8), matrixcolor=SepiaMatrix())
image auto shop billards = Transform("images/backgrounds/auto shop/billards.jpg", zoom=0.8)
image auto shop billards sepia = Transform(Transform("images/backgrounds/auto shop/billards.jpg", zoom=0.8), matrixcolor=SepiaMatrix())

### AUTO SHOW
image auto show lounge = Transform("images/backgrounds/auto show/auto show lounge.jpg", zoom=0.8)
image auto show classic cars = Transform("images/backgrounds/auto show/auto show classic cars.jpg", zoom=0.8)
image auto show simulator = Transform("images/backgrounds/driving/road night car.jpg", zoom=0.8)
image auto show prototype = Transform("images/backgrounds/auto show/auto show prototype.jpg", zoom=0.8)
image auto show no prototype = Transform("images/backgrounds/auto show/auto show no prototype.jpg", zoom=0.8)
image auto show inside prototype = Composite(
    (769, 1350),
        (-100,-100), Transform("images/backgrounds/auto show/auto show no prototype.jpg", zoom=0.8),
        (-300,-100), "fancy car overlay"
                )
image auto show security = Transform("images/backgrounds/auto show/auto show security.jpg", zoom=0.8)

image auto show ballroom expo = Composite(
    (769, 1350),
        (-1500,-10), Transform("images/backgrounds/auto show/auto show ballroom.jpg", zoom=0.8),
        (0, 350), Transform("images/overlays/car kaneko.png", zoom=1.2)
)

image main menu = Transform("gui/main_menu.png", zoom=1.0)