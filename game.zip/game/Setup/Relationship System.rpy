transform relationship_gain():
    alpha 0.0
    pause 0.3
    xalign 0.5
    yalign 0.5
    zoom 0.1
    alpha 1.0
    ease 0.3 zoom 1.2
    ease 0.1 zoom 1.0
    linear 1.25 yalign 0.25

screen relationship_change(my_txt):
    zorder 10000000
    text my_txt size 35 color "#E5DBD9" outlines [ (absolute(1), "#292928", absolute(0), absolute(0)) ] font "Fonts/Sofia Pro Semi Bold Az.otf" at relationship_gain
    timer 0.9 action Hide("relationship_change", dissolve)


#### RELATIONSHIP 
default distrust = 20
default dislike = 40
default neutral = 60
default liked = 80
default respected = 100
default trusted = 120
default ride_or_die = 140

default status_untrusted = "DISTRUST"
default status_status_disliked = "DISLIKE"
default status_status_neutral = "NEUTRAL"
default status_status_liked = "LIKED"
default status_status_respected = "RESPECTED"
default status_status_trusted = "TRUSTED"
default status_status_ride_or_die = "RIDE_OR_DIE"

init python:
    def my_notify_func(txt, txt1, txt2):
        renpy.show_screen("achievement", my_txt=txt, my_txt1=txt1, my_txt2=txt2)

    def notify_relationship_point(txt):
        renpy.show_screen("relationship_change", my_txt=txt)
        renpy.pause(0.2)

    def relationship_check(current_rel_value, minimum_relationship):
        global distrust, dislike, neutral, liked, respected, trusted, ride_or_die
        global status_untrusted, status_disliked, status_neutral, status_liked, status_respected, status_trusted, status_ride_or_die

        if minimum_relationship == status_untrusted:
            return True
        elif minimum_relationship == status_disliked:
            return current_rel_value > distrust
        elif minimum_relationship == status_neutral:
            return current_rel_value > dislike
        elif minimum_relationship == status_liked:
            return current_rel_value > neutral
        elif minimum_relationship == status_respected:
            return current_rel_value > liked
        elif minimum_relationship == status_trusted:
            return current_rel_value > respected
        else:
            return current_rel_value > trusted

    def check_relationship_maxmin():
        global colt_relationship, colt_relationship_old, ingrid_relationship, ingrid_relationship_old, logan_relationship, logan_relationship_old, mona_relationship, mona_relationship_old

        if colt_relationship >= 140 and colt_relationship != colt_relationship_old:
            notify_relationship_point("Colt MAX")
        if colt_relationship <= 0 and colt_relationship != colt_relationship_old:
            notify_relationship_point("Colt MIN")

        if logan_relationship >= 140 and logan_relationship != logan_relationship_old:
            notify_relationship_point("Logan MAX")
        if logan_relationship <= 0 and logan_relationship != logan_relationship_old:
            notify_relationship_point("Logan MIN")

        if mona_relationship >= 140 and mona_relationship != mona_relationship_old:
            notify_relationship_point("Mona MAX")
        if mona_relationship <= 0 and mona_relationship != mona_relationship_old:
            notify_relationship_point("Mona MIN")

        if ingrid_relationship >= 140 and ingrid_relationship != ingrid_relationship_old:
            notify_relationship_point("Ingrid MAX")
        if ingrid_relationship <= 0 and ingrid_relationship != ingrid_relationship_old:
            notify_relationship_point("Ingrid MIN")

    config.python_callbacks.append(check_relationship_maxmin)

    def check_notify_relationship_change():
        global colt_relationship, colt_relationship_old, ingrid_relationship, ingrid_relationship_old, logan_relationship, logan_relationship_old, mona_relationship, mona_relationship_old
        global distrust, dislike, neutral, liked, respected, trusted, ride_or_die
        names = ["Colt", "Ingrid", "Logan", "Mona"]
        relationships = [colt_relationship, ingrid_relationship, logan_relationship, mona_relationship]
        relationships_old = [colt_relationship_old, ingrid_relationship_old, logan_relationship_old, mona_relationship_old]

        for i in range(len(names)):

            name = names[i]
            relationship = relationships[i]
            relationship_old = relationships_old[i]

            if relationship <= distrust and relationship_old > distrust:
                my_notify_func("gui/notify.png", "RELATIONSHIP LOST!", f"{name} doesn't trust you!")
            if relationship > distrust and relationship <= dislike and relationship_old <= distrust:
                my_notify_func("gui/notify.png", "RELATIONSHIP GAINED!", f"{name} now only dislikes you!")
            if relationship > distrust and relationship <= dislike and relationship_old > dislike:
                my_notify_func("gui/notify.png", "RELATIONSHIP LOST!", f"{name} dislikes you!")
            if relationship > dislike and relationship <= neutral and relationship_old <= dislike:
                my_notify_func("gui/notify.png", "RELATIONSHIP GAINED!", f"{name} is neutral about you!")
            if relationship > dislike and relationship <= neutral and relationship_old > neutral:
                my_notify_func("gui/notify.png", "RELATIONSHIP LOST!", f"{name} is neutral about you!")
            if relationship > neutral and relationship <= liked and relationship_old <= neutral:
                my_notify_func("gui/notify.png", "RELATIONSHIP GAINED!", f"{name} now likes you!")
            if relationship > neutral and relationship <= liked and relationship_old > liked:
                my_notify_func("gui/notify.png", "RELATIONSHIP LOST!", f"{name} only likes you now!")
            if relationship > liked and relationship <= respected and relationship_old <= liked:
                my_notify_func("gui/notify.png", "RELATIONSHIP GAINED!", f"{name} now respects you!")
            if relationship > liked and relationship <= respected and relationship_old > respected:
                my_notify_func("gui/notify.png", "RELATIONSHIP LOST!", f"You've lost {name}'s trust!")
            if relationship > respected and relationship <= trusted and relationship_old <= respected:
                my_notify_func("gui/notify.png", "RELATIONSHIP GAINED!", f"You've gained {name}'s trust!")
            if relationship > respected and relationship <= trusted and relationship_old > trusted:
                my_notify_func("gui/notify.png", "RELATIONSHIP LOST!", f"{name} is no longer your ride or die!")
            if relationship > trusted and relationship <= ride_or_die and relationship_old <= trusted:
                my_notify_func("gui/notify.png", "RELATIONSHIP GAINED!", f"{name} is now your ride or die!")

            if relationship > relationship_old:
                notify_relationship_point(f"+{name.upper()}")
            elif relationship < relationship_old:
                notify_relationship_point(f"-{name.upper()}")

        colt_relationship_old = colt_relationship
        logan_relationship_old = logan_relationship
        mona_relationship_old = mona_relationship
        ingrid_relationship_old = ingrid_relationship

    config.python_callbacks.append(check_notify_relationship_change)

    def check_li_status():
        global colt_romance, colt_flirt, ingrid_romance, ingrid_flirt, logan_romance, logan_flirt, mona_romance, mona_flirt, current_li
        global colt_romance_old, ingrid_romance_old, logan_romance_old, mona_romance_old
        global colt_relationship, colt_relationship_old, ingrid_relationship, ingrid_relationship_old, mona_relationship, mona_relationship_old, logan_relationship, logan_relationship_old

        if colt_romance > 0 and not colt_flirt:
            colt_flirt = True

        if logan_romance > 0 and not logan_flirt:
            logan_flirt = True

        if mona_romance > 0 and not mona_flirt:
            mona_flirt = True 

        if ingrid_romance > 0 and not ingrid_flirt:
            ingrid_flirt = True

        if colt_romance > colt_romance_old:
            #colt_relationship_old += 2
            colt_relationship += 2
            colt_romance_old = colt_romance
            notify_relationship_point("+{image=heart_colt}")

        if ingrid_romance > ingrid_romance_old:
            #ingrid_relationship_old += 2
            ingrid_relationship += 2
            ingrid_romance_old = ingrid_romance
            notify_relationship_point("+{image=heart_ingrid}")

        if mona_romance > mona_romance_old:
            #mona_relationship_old += 2
            mona_relationship += 2
            mona_romance_old = mona_romance
            notify_relationship_point("+{image=heart_mona}")

        if logan_romance > logan_romance_old:
            #logan_relationship_old += 2
            logan_relationship += 2
            logan_romance_old = logan_romance
            notify_relationship_point("+{image=heart_logan}")

        if colt_romance < colt_romance_old:
            #colt_relationship_old += 2
            colt_relationship -= 2
            colt_romance_old = colt_romance
            notify_relationship_point("-{image=heart_colt}")

        if ingrid_romance < ingrid_romance_old:
            #ingrid_relationship_old += 2
            ingrid_relationship -= 2
            ingrid_romance_old = ingrid_romance
            notify_relationship_point("-{image=heart_ingrid}")

        if mona_romance < mona_romance_old:
            #mona_relationship_old += 2
            mona_relationship -= 2
            mona_romance_old = mona_romance
            notify_relationship_point("-{image=heart_mona}")

        if logan_romance < logan_romance_old:
            #logan_relationship_old += 2
            logan_relationship -= 2
            logan_romance_old = logan_romance
            notify_relationship_point("-{image=heart_logan}")

        lis = ["Ingrid", "Mona", "Colt", "Logan"]
        points = [ingrid_romance, mona_romance, colt_romance, logan_romance]

        if max(points) > 0:
            for i in range(len(points)):
                if points[i] == max(points):
                    current_li = lis[i]
                    return

    config.python_callbacks.append(check_li_status)

init -10:
    ###relationship
    default mona_relationship = 50
    default mona_relationship_old = 50
    default logan_relationship = 50
    default logan_relationship_old = 50
    default ingrid_relationship = 62
    default ingrid_relationship_old = 62
    default colt_relationship = 50
    default colt_relationship_old = 50
    default colt_relationship_icon = "neutral"
    default ingrid_relationship_icon = "neutral"
    default logan_relationship_icon = "neutral"
    default mona_relationship_icon = "neutral"

    default mona_romance_old = 0
    default logan_romance_old = 0
    default ingrid_romance_old = 0
    default colt_romance_old = 0

    default ingrid_relationship_end_of_chapter = 62
    default mona_relationship_end_of_chapter = 50
    default logan_relationship_end_of_chapter = 50
    default colt_relationship_end_of_chapter = 50

    default mona_romance_end_of_chapter = 0
    default ingrid_romance_end_of_chapter = 0
    default logan_romance_end_of_chapter = 0
    default colt_romance_end_of_chapter = 0

init python:
    def limit_relationship():

        global ingrid_relationship, ingrid_relationship_old, colt_relationship, colt_relationship_old, ingrid_relationship, ingrid_relationship_old, logan_relationship, logan_relationship_old, mona_relationship, mona_relationship_old

        try:
            if colt_relationship < 0:
                colt_relationship = 0
            elif colt_relationship > 140:
                colt_relationship = 140

            if colt_relationship_old < 0:
                colt_relationship_old = 0
            elif colt_relationship_old > 140:
                colt_relationship_old = 140

            if ingrid_relationship < 0:
                ingrid_relationship = 0
            elif ingrid_relationship > 140:
                ingrid_relationship = 140

            if ingrid_relationship_old < 0:
                ingrid_relationship_old = 0
            elif ingrid_relationship_old > 140:
                ingrid_relationship_old = 140

            if logan_relationship < 0:
                logan_relationship = 0
            elif logan_relationship > 140:
                logan_relationship = 140

            if logan_relationship_old < 0:
                logan_relationship_old = 0
            elif logan_relationship_old > 140:
                logan_relationship_old = 140

            if mona_relationship < 0:
                mona_relationship = 0
            elif mona_relationship > 140:
                mona_relationship = 140

            if mona_relationship_old < 0:
                mona_relationship_old = 0
            elif mona_relationship_old > 140:
                mona_relationship_old = 140

            if connor_relationship < 0:
                connor_relationship = 0
            elif connor_relationship > 140:
                connor_relationship = 140

        except:
            pass

    config.python_callbacks.append(limit_relationship)

    def relationship_icon():
        global colt_relationship, colt_relationship_icon, ingrid_relationship, ingrid_relationship_icon, logan_relationship, logan_relationship_icon, mona_relationship, mona_relationship_icon
        try:
            if colt_relationship <= 20:
                colt_relationship_icon = "hate"
            elif colt_relationship > 20 and colt_relationship <= 40:
                colt_relationship_icon = "dislike"
            elif colt_relationship > 40 and colt_relationship <= 60:
                colt_relationship_icon = "neutral"
            elif colt_relationship > 60 and colt_relationship <= 80:
                colt_relationship_icon = "like"
            elif colt_relationship > 80 and colt_relationship <= 100:
                colt_relationship_icon = "friend"
            elif colt_relationship > 100 and colt_relationship <= 120:
                colt_relationship_icon = "close"
            elif colt_relationship > 120 and colt_relationship <= 140:
                colt_relationship_icon = "best_friends"

            if ingrid_relationship <= 20:
                ingrid_relationship_icon = "hate"
            elif ingrid_relationship > 20 and ingrid_relationship <= 40:
                ingrid_relationship_icon = "dislike"
            elif ingrid_relationship > 40 and ingrid_relationship <= 60:
                ingrid_relationship_icon = "neutral"
            elif ingrid_relationship > 60 and ingrid_relationship <= 80:
                ingrid_relationship_icon = "like"
            elif ingrid_relationship > 80 and ingrid_relationship <= 100:
                ingrid_relationship_icon = "friend"
            elif ingrid_relationship > 100 and ingrid_relationship <= 120:
                ingrid_relationship_icon = "close"
            elif ingrid_relationship > 120 and ingrid_relationship <= 140:
                ingrid_relationship_icon = "best_friends"

            if logan_relationship <= 20:
                logan_relationship_icon = "hate"
            elif logan_relationship > 20 and logan_relationship <= 40:
                logan_relationship_icon = "dislike"
            elif logan_relationship > 40 and logan_relationship <= 60:
                logan_relationship_icon = "neutral"
            elif logan_relationship > 60 and logan_relationship <= 80:
                logan_relationship_icon = "like"
            elif logan_relationship > 80 and logan_relationship <= 100:
                logan_relationship_icon = "friend"
            elif logan_relationship > 100 and logan_relationship <= 120:
                logan_relationship_icon = "close"
            elif logan_relationship > 120 and logan_relationship <= 140:
                logan_relationship_icon = "best_friends"

            if mona_relationship <= 20:
                mona_relationship_icon = "hate"
            elif mona_relationship > 20 and mona_relationship <= 40:
                mona_relationship_icon = "dislike"
            elif mona_relationship > 40 and mona_relationship <= 60:
                mona_relationship_icon = "neutral"
            elif mona_relationship > 60 and mona_relationship <= 80:
                mona_relationship_icon = "like"
            elif mona_relationship > 80 and mona_relationship <= 100:
                mona_relationship_icon = "friend"
            elif mona_relationship > 100 and mona_relationship <= 120:
                mona_relationship_icon = "close"
            elif mona_relationship > 120 and mona_relationship <= 140:
                mona_relationship_icon = "best_friends"

        except:
            pass

    def restore_relationship_scores():
        global ingrid_relationship, ingrid_relationship_old, ingrid_relationship_end_of_chapter
        global mona_relationship, mona_relationship_old, mona_relationship_end_of_chapter
        global logan_relationship, logan_relationship_old, logan_relationship_end_of_chapter
        global colt_relationship, colt_relationship_old, colt_relationship_end_of_chapter

        ingrid_relationship = ingrid_relationship_end_of_chapter
        ingrid_relationship_old = ingrid_relationship_end_of_chapter

        mona_relationship = mona_relationship_end_of_chapter
        mona_relationship_old = mona_relationship_end_of_chapter

        logan_relationship = logan_relationship_end_of_chapter
        logan_relationship_old = logan_relationship_end_of_chapter

        colt_relationship = colt_relationship_end_of_chapter
        colt_relationship_old = colt_relationship_end_of_chapter

    def restore_romance_scores():
        global ingrid_romance, ingrid_romance_old, ingrid_romance_end_of_chapter
        global mona_romance, mona_romance_old, mona_romance_end_of_chapter
        global logan_romance, logan_romance_old, logan_romance_end_of_chapter
        global colt_romance, colt_romance_old, colt_romance_end_of_chapter

        ingrid_romance = ingrid_romance_end_of_chapter
        ingrid_romance_old = ingrid_romance_end_of_chapter

        mona_romance = mona_romance_end_of_chapter
        mona_romance_old = mona_romance_end_of_chapter

        logan_romance = logan_romance_end_of_chapter
        logan_romance_old = logan_romance_end_of_chapter

        colt_romance = colt_romance_end_of_chapter
        colt_romance_old = colt_romance_end_of_chapter

    def restore_relationship_defaults(chapter=1):
        restore_relationship_scores()
        restore_romance_scores()

    def save_relationship_system_scores():
        global ingrid_romance, ingrid_romance_end_of_chapter, ingrid_relationship, ingrid_relationship_end_of_chapter
        global mona_romance, mona_romance_end_of_chapter, mona_relationship, mona_relationship_end_of_chapter
        global colt_romance, colt_romance_end_of_chapter, colt_relationship, colt_relationship_end_of_chapter
        global logan_romance, logan_romance_end_of_chapter, logan_relationship, logan_relationship_end_of_chapter

        ingrid_relationship_end_of_chapter = ingrid_relationship
        ingrid_romance_end_of_chapter = ingrid_romance

        mona_relationship_end_of_chapter = mona_relationship
        mona_romance_end_of_chapter = mona_romance
        
        colt_relationship_end_of_chapter = colt_relationship
        colt_romance_end_of_chapter = colt_romance

        logan_relationship_end_of_chapter = logan_relationship
        logan_romance_end_of_chapter = logan_romance

    config.python_callbacks.append(relationship_icon)
