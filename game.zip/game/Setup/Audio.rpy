init:
    $ renpy.music.register_channel("music", mixer="sfx", loop=True)

    $ renpy.music.register_channel("sound", mixer="sfx", loop=False)
