
# general
default maximum_suave_points = 0
default maximum_serious_points = 0
default maximum_serious_points_end_of_chapter = 0
default maximum_suave_points_end_of_chapter = 0
default suave_points = 0
default serious_points_old = 0
default serious_points = 0
default suave_points_old = 0
default suave_points_end_of_chapter = 0
default serious_points_end_of_chapter = 0
default current_li = None
default spoilers = False
default persistent.spoilers = False
default is_dating = False
default time = 7

default mission_required_value = 0
default mission_current_value = 0
default current_mission_complete = False
default achievement_success_title = None
default achievement_success_text = None
default achievement_failure_title = None
default achievement_failure_text = None
default current_mood = "neutral"
default current_speaker = None
default loop_counter = 0
default loop_points = 0

default loop_question_option1 = False
default loop_question_option2 = False
default loop_question_option3 = False

define highlight = "#23a997"
define red = "#aa0d0dff"
define blue = "#0553e4ff"

# closet controls
default closet_choice_expanded = True
default setup_complete = True
default playing_from_beginning = False
default mission_outfit_style = "casual"
default suave_points_outfit = "1"
default serious_points_outfit = "2"

#other defaults
default playing_as = "ELLIE"
default playable_character = "ELLIE"
default center_voice = "TUTORIAL"
default who = None
default who_old = None
default current_chapter = 1
default maximum_chapters = 3
default jones_grey_dating = False
default jones_viv_dating = False

###Agent Grey Pronouns
default AgentGrey = "Samara"
default capsAgentGrey = "SAMARA"
default Grey = "Gray"
default capsGrey = "GRAY"
default grey_pronoun_she = "she"
default grey_pronoun_her = "her"
default grey_pronoun_pos_her = "her"
default grey_pronoun_pos_hers = "hers"
default grey_herself = "herself"
default grey_partner = "girlfriend"
default grey_daughter = "daughter"
default grey_beautiful = "beautiful"
default grey_darling = "darling"

###Agent Jones Pronouns
default AgentJones = "Elliot"
default capsAgentJones = "ELLIOT"
default Jones = "Jones"
default capsJones = "JONES"
default jones_pronoun_she = "she"
default jones_pronoun_her = "her"
default jones_pronoun_pos_her = "her"
default jones_pronoun_pos_hers = "hers"
default jones_herself = "herself"
default jones_partner = "girlfriend"
default jones_daughter = "daughter"
default jones_beautiful = "beautiful"
default jones_darling = "sweetheart"
default jones_ellie_fav_child = False

###Ellie Wheeler Pronouns
default Ellie = "Eleanor"
default capsEllie = "Eleanor"
default Ellie_nickname = "Ellie"
default Wheeler = "Wheeler"
default capsWheeler = "WHEELER"
default ellie_pronoun_she = "she"
default ellie_pronoun_her = "her"
default ellie_pronoun_pos_her = "her"
default ellie_pronoun_pos_hers = "hers"
default ellie_herself = "herself"
default ellie_partner = "girlfriend"
default ellie_daughter = "daughter"
default ellie_beautiful = "beautiful"
default ellie_young_tattoo = False
default ellie_no_tattoo = True
default ellie_tattoo_flowers = False
default ellie_tattoo_visible = False
default ellie_valedictorian = False
default ellie_ingrid_friends_hs = False
default ellie_codename = None
default ellie_young_first_kiss = None
default ellie_prom = None
default ellie_prom_love = False

# INGRID
default ingrid_flirt = False
default ingrid_romance = 0
default ingrid_romance_max = 0
default ingrid_barbie_puke = False
default ingrid_codename_barfie = False
default ingrid_codename = None

# LOGAN
default logan_flirt = False
default logan_romance = 0
default logan_romance_max = 0
default logan_young_forgiven = False

# MONA
default mona_flirt = False
default mona_romance = 0
default mona_romance_max = 0
default mona_tracker = False
default mona_rejected = False
default mona_real_name = "Layla"

# COLT
default colt_flirt = False
default colt_romance = 0
default colt_romance_max = 0