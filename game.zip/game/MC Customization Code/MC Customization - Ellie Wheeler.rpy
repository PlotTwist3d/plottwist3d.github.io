default ellie_race = 1
default ellie_race_max = 3
default ellie_outfit = 1
default ellie_outfit_undies = 1
default ellie_outfit_max = 9
default ellie_hair = 1
default ellie_hair_max = 10
default ellie_female = True
default ellie_undies = 1
default ellie_undies_max = 2
default ellie_pjs = 1
default ellie_pjs_max = 2
default ellie_heist = 1
default ellie_nipples = ellie_undies
default ellie_towel = 1
default ellie_mood = "neutral"
default ellie_tattoo = 0
default ellie_outfit_style = "casual"
default ellie_default_outfit = 1
default ellie_gunshot = False

default young_ellie_hairstyle = 1

init python:

    def change_ellie_outfit(outfit, index, gunshot=False):
        global ellie_outfit, ellie_outfit_style, ellie_gunshot

        ellie_outfit_style = outfit
        ellie_outfit = index
        ellie_gunshot = gunshot

#####################################renpy langauge version:

###Full Sized
image big ellie = Composite(
    (769, 1350),
        (100, 200), Transform("Create_Character/Ellie/Hair/ellie_[ellie_hair]_back.png", zoom=0.75),
        (100, 200), Transform("Create_Character/Ellie/Mood/ellie_[ellie_race]_body.png", zoom=0.75),
        (100, 200), Transform("Create_Character/Ellie/Tattoos/ellie_tattoo_[ellie_tattoo].png", zoom=0.75),
        (100, 200), Transform("Create_Character/Ellie/Mood/ellie_[ellie_race]_[ellie_mood].png", zoom=0.75),
        (100, 200), Transform("Create_character/Ellie/Outfits/ellie_outfit_[ellie_outfit_style][ellie_outfit].png", zoom=0.75),
        (100, 200), Transform("Create_character/Ellie/Hair/ellie_[ellie_hair]_front.png", zoom=0.75)
)

image big ellie undies = Composite(
    (769, 1350),
        (100, 200), Transform("Create_Character/Ellie/Hair/ellie_[ellie_hair]_back.png", zoom=0.75),
        (100, 200), Transform("Create_Character/Ellie/Mood/ellie_[ellie_race]_body.png", zoom=0.75),
        (100, 200), Transform("Create_Character/Ellie/Tattoos/ellie_tattoo_[ellie_tattoo].png", zoom=0.75),
        (100, 200), Transform("Create_Character/Ellie/Mood/ellie_[ellie_race]_[ellie_mood].png", zoom=0.75),
        (100, 200), Transform("Create_character/Ellie/Outfits/ellie_outfit_undies[ellie_outfit].png", zoom=0.75),
        (100, 200), Transform("Create_character/Ellie/Hair/ellie_[ellie_hair]_front.png", zoom=0.75)
)

image setup ellie = Composite(
    (769, 1350),
        (100, 200), Transform("Create_Character/Ellie/Hair/ellie_[ellie_hair]_back.png", zoom=0.75),
        (100, 200), Transform("Create_Character/Ellie/Mood/ellie_[ellie_race]_body.png", zoom=0.75),
        (100, 200), Transform("Create_Character/Ellie/Tattoos/ellie_tattoo_[ellie_tattoo].png", zoom=0.75),
        (100, 200), Transform("Create_Character/Ellie/Mood/ellie_[ellie_race]_[ellie_mood].png", zoom=0.75),
        (100, 200), Transform("Create_character/Ellie/Outfits/ellie_outfit_casual[ellie_outfit].png", zoom=0.75),
        (100, 200), Transform("Create_character/Ellie/Hair/ellie_[ellie_hair]_front.png", zoom=0.75)
)

image ellie = Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble [current_mood] MC.png",
        (0, 0), AlphaMask(Transform(Composite(
                    (769, 1350),
                        (40, 400), Transform("Create_Character/Ellie/Hair/ellie_[ellie_hair]_back.png", zoom=0.75),
                        (40, 400), Transform("Create_Character/Ellie/Mood/ellie_[ellie_race]_body.png", zoom=0.75),
                        (40, 400), Transform("Create_Character/Ellie/Tattoos/ellie_tattoo_[ellie_tattoo].png", zoom=0.75),
                        (40, 400), Transform("Create_Character/Ellie/Mood/ellie_[ellie_race]_[current_mood].png", zoom=0.75),
                        (40, 400), Transform("Create_character/Ellie/Outfits/ellie_outfit_[ellie_outfit_style][ellie_outfit].png", zoom=0.75),
                        (40, 400), ConditionSwitch(
                            "ellie_gunshot", Transform("Create_character/Ellie/ellie_gunshot.png", zoom=0.75),
                            True, "images/Colt/Mood/nothing.png"
                        ),
                        (40, 400), Transform("Create_character/Ellie/Hair/ellie_[ellie_hair]_front.png", zoom=0.75)
                ), zoom=0.75), "images/Bubbles/alpha_mask.png"),
)

image ellie NPC = Transform(Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble [current_mood] MC.png",
        (0, 0), AlphaMask(Transform(Composite(
                    (769, 1350),
                        (40, 400), Transform("Create_Character/Ellie/Hair/ellie_[ellie_hair]_back.png", zoom=0.75),
                        (40, 400), Transform("Create_Character/Ellie/Mood/ellie_[ellie_race]_body.png", zoom=0.75),
                        (40, 400), Transform("Create_Character/Ellie/Tattoos/ellie_tattoo_[ellie_tattoo].png", zoom=0.75),
                        (40, 400), Transform("Create_Character/Ellie/Mood/ellie_[ellie_race]_[current_mood].png", zoom=0.75),
                        (40, 400), Transform("Create_character/Ellie/Outfits/ellie_outfit_[ellie_outfit_style][ellie_outfit].png", zoom=0.75),
                        (40, 400), ConditionSwitch(
                            "ellie_gunshot", Transform("Create_character/Ellie/ellie_gunshot.png", zoom=0.75),
                            True, "images/Colt/Mood/nothing.png"
                        ),
                        (40, 400), Transform("Create_character/Ellie/Hair/ellie_[ellie_hair]_front.png", zoom=0.75)
                ), zoom=0.75), "images/Bubbles/alpha_mask.png"),
), xzoom=-1)

#####################################python version:
screen race_ellie():
    default move = truecenter

    zorder 100000000000000
    modal True

    #add "images/backgrounds_TPA/closet.jpg"
    add "big ellie undies" at move

    if closet_choice_expanded:
        imagemap:
            idle "Dressup_Screen/idle no arrows.png"
            hover "Dressup_Screen/selected no arrows.png"
            selected_idle "Dressup_Screen/selected no arrows.png"
            selected_hover "Dressup_Screen/selected no arrows.png"

            ##Continue##
            hotspot (60,900,647,286) action Return() keysym "K_RETURN"

        imagebutton:
            xalign 0.865
            yalign 0.72
            idle "Dressup_Screen/arrow down.png"
            action (SetVariable("closet_choice_expanded", False))

        imagebutton:
            xoffset 20
            xalign 0.0
            yalign 0.5
            idle "Dressup_Screen/arrow left.png"
            action SetScreenVariable("move", move_right(PrevEllieModel, SetScreenVariable("move", truecenter)))
            keysym "K_LEFT"

        imagebutton:
            xoffset -20
            xalign 1.0
            yalign 0.5
            idle "Dressup_Screen/arrow right.png"
            action SetScreenVariable("move", move_left(NextEllieModel, SetScreenVariable("move", truecenter)))
            keysym "K_RIGHT"

    else:
        imagebutton:
            xalign 0.865
            yalign 0.98
            idle "Dressup_Screen/arrow up.png"
            action (SetVariable("closet_choice_expanded", True))

screen tattoo_ellie():
    default move = truecenter

    zorder 100000000000000
    modal True

    #add "images/backgrounds_TPA/closet.jpg"
    add "big ellie undies" at move

    if closet_choice_expanded:
        imagemap:
            idle "Dressup_Screen/idle no arrows.png"
            hover "Dressup_Screen/selected no arrows.png"
            selected_idle "Dressup_Screen/selected no arrows.png"
            selected_hover "Dressup_Screen/selected no arrows.png"

            ##Continue##
            hotspot (60,900,647,286) action Return() keysym "K_RETURN"

        imagebutton:
            xalign 0.865
            yalign 0.72
            idle "Dressup_Screen/arrow down.png"
            action (SetVariable("closet_choice_expanded", False))

        imagebutton:
            xoffset 20
            xalign 0.0
            yalign 0.5
            idle "Dressup_Screen/arrow left.png"
            action SetScreenVariable("move", move_right(PrevEllieTattoo, SetScreenVariable("move", truecenter)))
            keysym "K_LEFT"

        imagebutton:
            xoffset -20
            xalign 1.0
            yalign 0.5
            idle "Dressup_Screen/arrow right.png"
            action SetScreenVariable("move", move_left(NextEllieTattoo, SetScreenVariable("move", truecenter)))
            keysym "K_RIGHT"

    else:
        imagebutton:
            xalign 0.865
            yalign 0.98
            idle "Dressup_Screen/arrow up.png"
            action (SetVariable("closet_choice_expanded", True))

screen hair_ellie():
    default move = truecenter

    zorder 100000000000000
    modal True

    #add "images/backgrounds_TPA/closet.jpg"
    add "big ellie undies" at move

    if closet_choice_expanded:
        imagemap:
            idle "Dressup_Screen/idle no arrows.png"
            hover "Dressup_Screen/selected no arrows.png"
            selected_idle "Dressup_Screen/selected no arrows.png"
            selected_hover "Dressup_Screen/selected no arrows.png"

            ##Continue##
            hotspot (60,900,647,286) action Return() keysym "K_RETURN"

        imagebutton:
            xalign 0.865
            yalign 0.72
            idle "Dressup_Screen/arrow down.png"
            action (SetVariable("closet_choice_expanded", False))

        imagebutton:
            xoffset 20
            xalign 0.0
            yalign 0.5
            idle "Dressup_Screen/arrow left.png"
            action SetScreenVariable("move", move_right(PrevEllieHair, SetScreenVariable("move", truecenter)))
            keysym "K_LEFT"

        imagebutton:
            xoffset -20
            xalign 1.0
            yalign 0.5
            idle "Dressup_Screen/arrow right.png"
            action SetScreenVariable("move", move_left(NextEllieHair, SetScreenVariable("move", truecenter)))
            keysym "K_RIGHT"

    else:
        imagebutton:
            xalign 0.865
            yalign 0.98
            idle "Dressup_Screen/arrow up.png"
            action (SetVariable("closet_choice_expanded", True))

screen outfit_ellie():
    default move = truecenter

    zorder 100000000000000
    modal True

    #add "images/backgrounds_TPA/closet.jpg"
    add "setup ellie" at move

    if closet_choice_expanded:
        imagemap:
            idle "Dressup_Screen/idle no arrows.png"
            hover "Dressup_Screen/selected no arrows.png"
            selected_idle "Dressup_Screen/selected no arrows.png"
            selected_hover "Dressup_Screen/selected no arrows.png"

            ##Continue##
            hotspot (60,900,647,286) action Return() keysym "K_RETURN"

        imagebutton:
            xalign 0.865
            yalign 0.72
            idle "Dressup_Screen/arrow down.png"
            action (SetVariable("closet_choice_expanded", False))

        imagebutton:
            xoffset 20
            xalign 0.0
            yalign 0.5
            idle "Dressup_Screen/arrow left.png"
            action SetScreenVariable("move", move_right(PrevEllieOutfit, SetScreenVariable("move", truecenter)))
            keysym "K_LEFT"

        imagebutton:
            xoffset -20
            xalign 1.0
            yalign 0.5
            idle "Dressup_Screen/arrow right.png"
            action SetScreenVariable("move", move_left(NextEllieOutfit, SetScreenVariable("move", truecenter)))
            keysym "K_RIGHT"

    else:
        imagebutton:
            xalign 0.865
            yalign 0.98
            idle "Dressup_Screen/arrow up.png"
            action (SetVariable("closet_choice_expanded", True))

