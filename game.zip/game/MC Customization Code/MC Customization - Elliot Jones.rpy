default jones_race = 1
default jones_race_max = 3
default jones_outfit = 1
default jones_outfit_max = 9
default jones_hair = 1
default jones_hair_max = 10
default jones_female = True
default jones_undies = 1
default jones_undies_max = 2
default jones_body = 1
default jones_body_max = 2
default jones_heist = 1
default jones_nipples = jones_undies
default jones_towel = 1
default jones_mood = "neutral"
default jones_outfit_style = "casual"

init:
    $ jones_holo = Character("[capsAgentJones]", color="#292928", what_color="#23a997", who_outlines=[ (1, "#E5DBD9") ], what_xpos=175, what_ypos=-20, who_xpos=285, who_ypos=805)
    $ jones_holo_text = Character('[capsAgentJones]', kind=nvl, color="#E5DBD9", what_color="#23a997", who_size=28, what_size=33, bottom_padding=5, what_xpos=45, who_xpos=45)
    $ left_jones_holo = Character("[capsAgentJones]", color="#292928", who_outlines=[ (1, "#E5DBD9") ], window_top_padding=831, what_xpos=100, what_ypos=-20, who_xpos=310, who_ypos=805)

init python:

    def change_jones_outfit(outfit, index):
        global jones_outfit, jones_outfit_style

        jones_outfit_style = outfit
        jones_outfit = index
#####################################renpy langauge version:

###Full Sized
image big jones = Composite(
    (769, 1350),
        (0, 0), ConditionSwitch(
            "jones_body == 1", Composite(
                                (769, 1350),
                                    (100, 200), Transform("Create_Character/Jones/Hair/jones_[jones_body]_[jones_hair]_back.png", zoom=0.75),
                                    (100, 200), Transform("Create_Character/Jones/Mood/jones_[jones_body]_[jones_race]_body.png", zoom=0.75),
                                    (100, 200), Transform("Create_Character/Jones/Mood/jones_[jones_body]_[jones_race]_[jones_mood].png", zoom=0.75),
                                    (100, 200), Transform("Create_character/Jones/Outfits/jones_[jones_body]_[jones_outfit_style][jones_outfit].png", zoom=0.75),
                                    (100, 200), Transform("Create_character/Jones/Hair/jones_[jones_body]_[jones_hair].png", zoom=0.75)
                            ),
            "True", Composite(
                                (769, 1350),
                                    (50, 200), Transform("Create_Character/Jones/Hair/jones_[jones_body]_[jones_hair]_back.png", zoom=0.75),
                                    (50, 200), Transform("Create_Character/Jones/Mood/jones_[jones_body]_[jones_race]_body.png", zoom=0.75),
                                    (50, 200), Transform("Create_Character/Jones/Mood/jones_[jones_body]_[jones_race]_[jones_mood].png", zoom=0.75),
                                    (50, 200), Transform("Create_character/Jones/Outfits/jones_[jones_body]_[jones_outfit_style][jones_outfit].png", zoom=0.75),
                                    (50, 200), Transform("Create_character/Jones/Hair/jones_[jones_body]_[jones_hair].png", zoom=0.75)
                            ),
        ),
)

###Resized
image jones = Transform(Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble [current_mood] MC.png",
        (0, 0), AlphaMask(ConditionSwitch(
            "jones_female", Transform(Composite(
                                (769, 1350),
                                    (60, 420), Transform("Create_Character/Jones/Hair/jones_[jones_body]_[jones_hair]_back.png", zoom=0.75),
                                    (60, 420), Transform("Create_Character/Jones/Mood/jones_[jones_body]_[jones_race]_body.png", zoom=0.75),
                                    (60, 420), Transform("Create_Character/Jones/Mood/jones_[jones_body]_[jones_race]_[current_mood].png", zoom=0.75),
                                    (60, 420), Transform("Create_character/Jones/Outfits/jones_[jones_body]_[jones_outfit_style][jones_outfit].png", zoom=0.75),
                                    (60, 420), Transform("Create_character/Jones/Hair/jones_[jones_body]_[jones_hair].png", zoom=0.75)
                            ), zoom=0.75),
            "True", Transform(Composite(
                                (769, 1350),
                                    (-40, 420), Transform("Create_Character/Jones/Hair/jones_[jones_body]_[jones_hair]_back.png", zoom=0.75),
                                    (-40, 420), Transform("Create_Character/Jones/Mood/jones_[jones_body]_[jones_race]_body.png", zoom=0.75),
                                    (-40, 420), Transform("Create_Character/Jones/Mood/jones_[jones_body]_[jones_race]_[current_mood].png", zoom=0.75),
                                    (-40, 420), Transform("Create_character/Jones/Outfits/jones_[jones_body]_[jones_outfit_style][jones_outfit].png", zoom=0.75),
                                    (-40, 420), Transform("Create_character/Jones/Hair/jones_[jones_body]_[jones_hair].png", zoom=0.75)
                            ), zoom=0.75),
        ), "images/Bubbles/alpha_mask.png"),
), xzoom=-1)

image jones holo = Transform(Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble [current_mood] MC.png",
        (0, 0), AlphaMask(holo(ConditionSwitch(
            "jones_female", Transform(Composite(
                                (769, 1350),
                                    (60, 420), Transform("Create_Character/Jones/Hair/jones_[jones_body]_[jones_hair]_back.png", zoom=0.75),
                                    (60, 420), Transform("Create_Character/Jones/Mood/jones_[jones_body]_[jones_race]_body.png", zoom=0.75),
                                    (60, 420), Transform("Create_Character/Jones/Mood/jones_[jones_body]_[jones_race]_[current_mood].png", zoom=0.75),
                                    (60, 420), Transform("Create_character/Jones/Outfits/jones_[jones_body]_[jones_outfit_style][jones_outfit].png", zoom=0.75),
                                    (60, 420), Transform("Create_character/Jones/Hair/jones_[jones_body]_[jones_hair].png", zoom=0.75)
                            ), zoom=0.75),
            "True", Transform(Composite(
                                (769, 1350),
                                    (-40, 420), Transform("Create_Character/Jones/Hair/jones_[jones_body]_[jones_hair]_back.png", zoom=0.75),
                                    (-40, 420), Transform("Create_Character/Jones/Mood/jones_[jones_body]_[jones_race]_body.png", zoom=0.75),
                                    (-40, 420), Transform("Create_Character/Jones/Mood/jones_[jones_body]_[jones_race]_[current_mood].png", zoom=0.75),
                                    (-40, 420), Transform("Create_character/Jones/Outfits/jones_[jones_body]_[jones_outfit_style][jones_outfit].png", zoom=0.75),
                                    (-40, 420), Transform("Create_character/Jones/Hair/jones_[jones_body]_[jones_hair].png", zoom=0.75)
                            ), zoom=0.75),
        )), "images/Bubbles/alpha_mask.png"),
), xzoom=-1)

#####################################python version:
screen body_jones():
    default move = truecenter

    zorder 100000000000000
    modal True

    #add "images/backgrounds_TPA/blur summer background.jpg"
    add "big jones" at move

    if closet_choice_expanded:
        imagemap:
            idle "Dressup_Screen/idle no arrows.png"
            hover "Dressup_Screen/selected no arrows.png"
            selected_idle "Dressup_Screen/selected no arrows.png"
            selected_hover "Dressup_Screen/selected no arrows.png"

            ##Continue##
            hotspot (60,900,647,286) action Return() keysym "K_RETURN"

        imagebutton:
            xalign 0.865
            yalign 0.72
            idle "Dressup_Screen/arrow down.png"
            action (SetVariable("closet_choice_expanded", False))

        imagebutton:
            xoffset 20
            xalign 0.0
            yalign 0.5
            idle "Dressup_Screen/arrow left.png"
            action SetScreenVariable("move", move_right(PrevJonesBody, SetScreenVariable("move", truecenter)))
            keysym "K_LEFT"

        imagebutton:
            xoffset -20
            xalign 1.0
            yalign 0.5
            idle "Dressup_Screen/arrow right.png"
            action SetScreenVariable("move", move_left(NextJonesBody, SetScreenVariable("move", truecenter)))
            keysym "K_RIGHT"

    else:
        imagebutton:
            xalign 0.865
            yalign 0.98
            idle "Dressup_Screen/arrow up.png"
            action (SetVariable("closet_choice_expanded", True))

screen race_jones():
    default move = truecenter

    zorder 100000000000000
    modal True

    #add "images/backgrounds_TPA/blur summer background.jpg"
    add "big jones" at move

    if closet_choice_expanded:
        imagemap:
            idle "Dressup_Screen/idle no arrows.png"
            hover "Dressup_Screen/selected no arrows.png"
            selected_idle "Dressup_Screen/selected no arrows.png"
            selected_hover "Dressup_Screen/selected no arrows.png"

            ##Continue##
            hotspot (60,900,647,286) action Return() keysym "K_RETURN"

        imagebutton:
            xalign 0.865
            yalign 0.72
            idle "Dressup_Screen/arrow down.png"
            action (SetVariable("closet_choice_expanded", False))

        imagebutton:
            xoffset 20
            xalign 0.0
            yalign 0.5
            idle "Dressup_Screen/arrow left.png"
            action SetScreenVariable("move", move_right(PrevJonesModel, SetScreenVariable("move", truecenter)))
            keysym "K_LEFT"

        imagebutton:
            xoffset -20
            xalign 1.0
            yalign 0.5
            idle "Dressup_Screen/arrow right.png"
            action SetScreenVariable("move", move_left(NextJonesModel, SetScreenVariable("move", truecenter)))
            keysym "K_RIGHT"

    else:
        imagebutton:
            xalign 0.865
            yalign 0.98
            idle "Dressup_Screen/arrow up.png"
            action (SetVariable("closet_choice_expanded", True))

screen hair_jones():
    default move = truecenter

    zorder 100000000000000
    modal True

    #add "images/backgrounds_TPA/blur summer background.jpg"
    add "big jones" at move

    if closet_choice_expanded:
        imagemap:
            idle "Dressup_Screen/idle no arrows.png"
            hover "Dressup_Screen/selected no arrows.png"
            selected_idle "Dressup_Screen/selected no arrows.png"
            selected_hover "Dressup_Screen/selected no arrows.png"

            ##Continue##
            hotspot (60,900,647,286) action Return() keysym "K_RETURN"

        imagebutton:
            xalign 0.865
            yalign 0.72
            idle "Dressup_Screen/arrow down.png"
            action (SetVariable("closet_choice_expanded", False))

        imagebutton:
            xoffset 20
            xalign 0.0
            yalign 0.5
            idle "Dressup_Screen/arrow left.png"
            action SetScreenVariable("move", move_right(PrevJonesHair, SetScreenVariable("move", truecenter)))
            keysym "K_LEFT"

        imagebutton:
            xoffset -20
            xalign 1.0
            yalign 0.5
            idle "Dressup_Screen/arrow right.png"
            action SetScreenVariable("move", move_left(NextJonesHair, SetScreenVariable("move", truecenter)))
            keysym "K_RIGHT"

    else:
        imagebutton:
            xalign 0.865
            yalign 0.98
            idle "Dressup_Screen/arrow up.png"
            action (SetVariable("closet_choice_expanded", True))