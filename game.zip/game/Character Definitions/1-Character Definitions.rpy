init:
## Bottom boxes
    $ b = Character("b", what_color="#E5DBD9", what_xalign=0.5, what_text_align=0.5, what_ypos=940)
    $ b3 = Character("b3", what_color="#E5DBD9", what_xalign=0.5, what_text_align=0.5, what_ypos=940)

## texts
    $ logan_text = Character('Logan', kind=nvl, color="#E5DBD9", what_color="#E5DBD9", who_size=28, what_size=33, what_xpos=45, who_xpos=45)
    $ grey_text = Character('[AgentGrey]', kind=nvl, color="#E5DBD9", what_color="#E5DBD9", who_size=28, what_size=33, what_xpos=45, who_xpos=45)

##center voices
    $ qc = Character("???", color="#292928", who_outlines=[ (1, "#E5DBD9") ], who_xpos=290, who_ypos=460)
    $ dad = Character("DAD", color="#292928", who_outlines=[ (1, "#E5DBD9") ], what_color="#111E6C", who_xpos=320, who_ypos=460)
    $ tutorial = Character("TUTORIAL", color="#292928", what_color="#23a997", who_outlines=[ (1, "#E5DBD9") ], window_bottom_padding=35, who_xpos=290, who_ypos=460)
    $ halo_ai = Character("HALO AI", color="#292928", what_color="#0b35c0", who_outlines=[ (1, "#E5DBD9") ], who_xpos=300, who_ypos=460)
    $ halo_ai_red = Character("HALO AI", color="#292928", what_color="#aa0d0dff", who_outlines=[ (1, "#E5DBD9") ], who_xpos=300, who_ypos=460)
    $ v = Character("TUTORIAL", color="#292928", what_color="#23a997", who_outlines=[ (1, "#E5DBD9") ], who_xpos=300, who_ypos=460)
    $ end_stats = Character("CHAPTER STATS", color="#292928", who_outlines=[ (1, "#E5DBD9") ], window_bottom_padding=35, who_xpos=290, who_ypos=460)

    $ center_logan = Character("LOGAN", color="#292928", who_outlines=[ (1, "#E5DBD9") ], who_xpos=290, who_ypos=460)
    $ center_grey = Character("[AgentGrey!u]", color="#292928", who_outlines=[ (1, "#E5DBD9") ], who_xpos=290, who_ypos=460)
    $ center_ingrid = Character("INGRID", color="#292928", who_outlines=[ (1, "#E5DBD9") ], who_xpos=290, who_ypos=460)
    $ center_mona = Character("MONA", color="#292928", who_outlines=[ (1, "#E5DBD9") ], who_xpos=290, who_ypos=460)
    $ center_colt = Character("LOGAN", color="#292928", who_outlines=[ (1, "#E5DBD9") ], what_color="#111E6C", who_xpos=290, who_ypos=460)
   
    $ q = Character("???", color="#292928", who_outlines=[ (1, "#E5DBD9") ], what_xpos=175, what_ypos=-20, who_xpos=320, who_ypos=805)

###Menus
    $ bottom = False
    $ middle = False
    $ regular = False

#MC names
    $ jones = Character("[capsAgentJones]", color="#292928", who_outlines=[ (1, "#E5DBD9") ], what_xpos=175, what_ypos=-20, who_xpos=285, who_ypos=805)
    $ left_jones = Character("[capsAgentJones]", color="#292928", who_outlines=[ (1, "#E5DBD9") ], window_top_padding=831, what_xpos=100, what_ypos=-20, who_xpos=310, who_ypos=805)
    $ center_jones = Character("[capsAgentJones]", color="#292928", who_outlines=[ (1, "#E5DBD9") ], what_color="#111E6C", who_xpos=290, who_ypos=460)
    $ jones_text = Character('[capsAgentJones]', kind=nvl, color="#E5DBD9", what_color="#E5DBD9", who_size=28, what_size=33, what_xpos=45)
    $ right_jones_text = Character("[capsAgentJones]", kind=nvl, color="#E5DBD9", what_color="#E5DBD9", who_xalign=.5, who_xpos=250, what_xpos=200, who_size=28, what_size=33)
    
    $ ellie = Character("[capsEllie]", color="#292928", who_outlines=[ (1, "#E5DBD9") ], window_top_padding=831, what_xpos=100, what_ypos=-20, who_xpos=310, who_ypos=805)
    $ right_ellie = Character("[capsEllie]", color="#292928", who_outlines=[ (1, "#E5DBD9") ], what_xpos=175, what_ypos=-20, who_xpos=285, who_ypos=805)
    $ ellie_text = Character("[Ellie]", kind=nvl, color="#E5DBD9", what_color="#E5DBD9", who_xalign=.5, who_xpos=250, what_xpos=200, who_size=28, what_size=33)
    $ center_ellie = Character("[capsEllie]", color="#292928", who_outlines=[ (1, "#E5DBD9") ], what_color="#111E6C", who_xpos=290, who_ypos=460)
    
    $ left_mona = Character("MONA", color="#292928", who_outlines=[ (1, "#E5DBD9") ], window_top_padding=831, what_xpos=100, what_ypos=-20, who_xpos=310, who_ypos=805)

##nvl
    $ lore = Character(kind=nvl, what_color="#000000", what_size=33, what_xpos=50, what_ypos=30, what_xsize=650)

#### holo
