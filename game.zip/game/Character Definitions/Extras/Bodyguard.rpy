###Annie Textbox
init:
    $ bodyguard = Character("BOUNCER", color="#292928", who_outlines=[ (1, "#E5DBD9") ], what_xpos=175, what_ypos=-20, who_xpos=285, who_ypos=805)

###Annie
image f bodyguard = Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble Neutral right.png",
        (0, 0), "images/Extras/Bodyguard F/Body.png",
        (0, 0), "images/Extras/Bodyguard F/Neutral.png",
        (0, 0), "images/Extras/Bodyguard F/Hair.png",
)

image f bodyguard mad = Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble Angry right.png",
        (0, 0), "images/Extras/Bodyguard F/Body.png",
        (0, 0), "images/Extras/Bodyguard F/Angry.png",
        (0, 0), "images/Extras/Bodyguard F/Hair.png",
)
image f bodyguard hap = Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble Happy right.png",
        (0, 0), "images/Extras/Bodyguard F/Body.png",
        (0, 0), "images/Extras/Bodyguard F/Happy.png",
        (0, 0), "images/Extras/Bodyguard F/Hair.png",
)
image f bodyguard sur = Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble Surprised right.png",
        (0, 0), "images/Extras/Bodyguard F/Body.png",
        (0, 0), "images/Extras/Bodyguard F/Surprised.png",
        (0, 0), "images/Extras/Bodyguard F/Hair.png",
)
image f bodyguard sad = Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble Sad right.png",
        (0, 0), "images/Extras/Bodyguard F/Body.png",
        (0, 0), "images/Extras/Bodyguard F/Sad.png",
        (0, 0), "images/Extras/Bodyguard F/Hair.png",
)

image m bodyguard = Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble Neutral right.png",
        (0, 0), "images/Extras/Bodyguard M/Body.png",
        (0, 0), "images/Extras/Bodyguard M/Neutral.png",
        (0, 0), "images/Extras/Bodyguard M/Hair.png",
)

image m bodyguard mad = Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble Angry right.png",
        (0, 0), "images/Extras/Bodyguard M/Body.png",
        (0, 0), "images/Extras/Bodyguard M/Angry.png",
        (0, 0), "images/Extras/Bodyguard M/Hair.png",
)
image m bodyguard hap = Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble Happy right.png",
        (0, 0), "images/Extras/Bodyguard M/Body.png",
        (0, 0), "images/Extras/Bodyguard M/Happy.png",
        (0, 0), "images/Extras/Bodyguard M/Hair.png",
)
image m bodyguard sur = Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble Surprised right.png",
        (0, 0), "images/Extras/Bodyguard M/Body.png",
        (0, 0), "images/Extras/Bodyguard M/Surprised.png",
        (0, 0), "images/Extras/Bodyguard M/Hair.png",
)
image m bodyguard sad = Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble Sad right.png",
        (0, 0), "images/Extras/Bodyguard M/Body.png",
        (0, 0), "images/Extras/Bodyguard M/Sad.png",
        (0, 0), "images/Extras/Bodyguard M/Hair.png",
)
