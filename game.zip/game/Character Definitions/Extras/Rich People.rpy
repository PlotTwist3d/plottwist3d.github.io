init:
    $ giorgio = Character("GIORGIO", color="#292928", who_outlines=[ (1, "#E5DBD9") ], what_xpos=175, what_ypos=-20, who_xpos=285, who_ypos=805)
    $ lucy = Character("LUCY", color="#292928", who_outlines=[ (1, "#E5DBD9") ], what_xpos=175, what_ypos=-20, who_xpos=285, who_ypos=805)
    $ greer = Character("GREER", color="#292928", who_outlines=[ (1, "#E5DBD9") ], what_xpos=175, what_ypos=-20, who_xpos=285, who_ypos=805)
    $ omar = Character("OMAR", color="#292928", who_outlines=[ (1, "#E5DBD9") ], what_xpos=175, what_ypos=-20, who_xpos=285, who_ypos=805)
    $ fabian = Character("FABIEN", color="#292928", who_outlines=[ (1, "#E5DBD9") ], what_xpos=175, what_ypos=-20, who_xpos=285, who_ypos=805)
    $ naomi = Character("NAOMI", color="#292928", who_outlines=[ (1, "#E5DBD9") ], what_xpos=175, what_ypos=-20, who_xpos=285, who_ypos=805)
    $ european = Character("THE EUROPEAN", color="#292928", who_outlines=[ (1, "#E5DBD9") ], what_xpos=175, what_ypos=-20, who_xpos=265, who_ypos=805)

image fabian = Transform(Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble [current_mood] MC.png",
        (0, 0), AlphaMask(Transform(Composite(
                    (769, 1350),
                        (40, 450), Transform("images/Extras/Fabian/fabien01-[current_mood].png", xzoom=-1)
                ), zoom=0.80), "images/Bubbles/alpha_mask.png"),
), xzoom=-1)

image giorgio = Transform(Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble [current_mood] MC.png",
        (0, 0), AlphaMask(Transform(Composite(
                    (769, 1350),
                        (20, 500), Transform("images/Extras/Rich People/Giorgio/giorgio [current_mood].png", xzoom=-1, zoom=1.1)
                ), zoom=0.75), "images/Bubbles/alpha_mask.png"),
), xzoom=-1)

image lucy = Composite(
    (769, 1350),
        (0, 0), Transform("images/Bubbles/Reaction Bubble [current_mood] MC.png", xzoom=-1),
        (0, 0), "images/Extras/Rich People/Lucy/Body.png",
        (0, 0), "images/Extras/Rich People/Lucy/[current_mood!c].png",
        (0, 0), "images/Extras/Rich People/Lucy/Hair.png",
)

image greer = Composite(
    (769, 1350),
        (0, 0), Transform("images/Bubbles/Reaction Bubble [current_mood] MC.png", xzoom=-1),
        (0, 0), "images/Extras/Rich People/Greer/Body.png",
        (0, 0), "images/Extras/Rich People/Greer/[current_mood!c].png",
        (0, 0), "images/Extras/Rich People/Greer/Hair.png",
)

image naomi = Composite(
    (769, 1350),
        (0, 0), Transform("images/Bubbles/Reaction Bubble [current_mood] MC.png", xzoom=-1),
        (0, 0), "images/Extras/Rich People/Naomi/Neutral.png",
        (0, 0), "images/Extras/Rich People/Naomi/[current_mood!c].png",
)

image omar = Transform(Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble neutral MC.png",
        (0, 0), AlphaMask(Transform(Composite(
                    (769, 1350),
                        (20, 500), Transform("images/Extras/Rich People/Omar/omar neutral.png", xzoom=-1, zoom=1.1)
                ), zoom=0.75), "images/Bubbles/alpha_mask.png"),
), xzoom=-1)