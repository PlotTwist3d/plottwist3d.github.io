init:
    $ waiter = Character("WAITER", color="#292928", who_outlines=[ (1, "#E5DBD9") ], what_xpos=175, what_ypos=-20, who_xpos=285, who_ypos=805)

image waiter = Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble Neutral right.png",
        (0, 0), "images/Extras/Waiter/Body.png",
        (0, 0), "images/Extras/Waiter/Neutral.png",
        (0, 0), "images/Extras/Waiter/Hair.png",
)

image waiter mad = Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble Angry right.png",
        (0, 0), "images/Extras/Waiter/Body.png",
        (0, 0), "images/Extras/Waiter/Angry.png",
        (0, 0), "images/Extras/Waiter/Hair.png",
)
image waiter hap = Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble Happy right.png",
        (0, 0), "images/Extras/Waiter/Body.png",
        (0, 0), "images/Extras/Waiter/Happy.png",
        (0, 0), "images/Extras/Waiter/Hair.png",
)
image waiter sur = Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble Surprised right.png",
        (0, 0), "images/Extras/Waiter/Body.png",
        (0, 0), "images/Extras/Waiter/Surprised.png",
        (0, 0), "images/Extras/Waiter/Hair.png",
)
image waiter sad = Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble Sad right.png",
        (0, 0), "images/Extras/Waiter/Body.png",
        (0, 0), "images/Extras/Waiter/Sad.png",
        (0, 0), "images/Extras/Waiter/Hair.png",
)
