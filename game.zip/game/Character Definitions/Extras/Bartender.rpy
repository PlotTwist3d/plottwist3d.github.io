init:
    $ bartender = Character("BARTENDER", color="#292928", who_outlines=[ (1, "#E5DBD9") ], what_xpos=175, what_ypos=-20, who_xpos=285, who_ypos=805)

image bartender = Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble Neutral right.png",
        (0, 0), "images/Extras/Bartender/Body.png",
        (0, 0), "images/Extras/Bartender/Neutral.png",
        (0, 0), "images/Extras/Bartender/Hair.png",
)

image bartender mad = Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble Angry right.png",
        (0, 0), "images/Extras/Bartender/Body.png",
        (0, 0), "images/Extras/Bartender/Angry.png",
        (0, 0), "images/Extras/Bartender/Hair.png",
)
image bartender hap = Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble Happy right.png",
        (0, 0), "images/Extras/Bartender/Body.png",
        (0, 0), "images/Extras/Bartender/Happy.png",
        (0, 0), "images/Extras/Bartender/Hair.png",
)
image bartender sur = Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble Surprised right.png",
        (0, 0), "images/Extras/Bartender/Body.png",
        (0, 0), "images/Extras/Bartender/Surprised.png",
        (0, 0), "images/Extras/Bartender/Hair.png",
)
image bartender sad = Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble Sad right.png",
        (0, 0), "images/Extras/Bartender/Body.png",
        (0, 0), "images/Extras/Bartender/Sad.png",
        (0, 0), "images/Extras/Bartender/Hair.png",
)
