###Annie Textbox
init:
    $ nurse = Character("NURSE", color="#292928", who_outlines=[ (1, "#E5DBD9") ], what_xpos=175, what_ypos=-20, who_xpos=285, who_ypos=805)
    $ hannah = Character("HANNAH", color="#292928", who_outlines=[ (1, "#E5DBD9") ], what_xpos=175, what_ypos=-20, who_xpos=285, who_ypos=805)

###Annie
image nurse = Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble Neutral right.png",
        (0, 0), "images/Extras/Nurse/Body.png",
        (0, 0), "images/Extras/Nurse/Neutral.png",
        (0, 0), "images/Extras/Nurse/Hair.png",
)

image nurse mad = Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble Angry right.png",
        (0, 0), "images/Extras/Nurse/Body.png",
        (0, 0), "images/Extras/Nurse/Angry.png",
        (0, 0), "images/Extras/Nurse/Hair.png",
)
image nurse hap = Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble Happy right.png",
        (0, 0), "images/Extras/Nurse/Body.png",
        (0, 0), "images/Extras/Nurse/Happy.png",
        (0, 0), "images/Extras/Nurse/Hair.png",
)
image nurse sur = Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble Surprised right.png",
        (0, 0), "images/Extras/Nurse/Body.png",
        (0, 0), "images/Extras/Nurse/Surprised.png",
        (0, 0), "images/Extras/Nurse/Hair.png",
)
image nurse sad = Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble Sad right.png",
        (0, 0), "images/Extras/Nurse/Body.png",
        (0, 0), "images/Extras/Nurse/Sad.png",
        (0, 0), "images/Extras/Nurse/Hair.png",
)
