init:
    $ chief = Character("PRISON GUARD", color="#292928", who_outlines=[ (1, "#E5DBD9") ], what_xpos=175, what_ypos=-20, who_xpos=215, who_ypos=805, who_size=30)
    $ officer = Character("OFFICER", color="#292928", who_outlines=[ (1, "#E5DBD9") ], what_xpos=175, what_ypos=-20, who_xpos=285, who_ypos=805)

image officer = Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble [current_mood!c] right.png",
        (0, 0), "images/Extras/Officer/Body.png",
        (0, 0), "images/Extras/Officer/[current_mood!c].png",
        (0, 0), "images/Extras/Officer/Hair.png",
)

image officer holo = Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble [current_mood!c] right.png",
        (0, 0), holo(Composite(
            (769, 1350),
                (0, 0), "images/Extras/Officer/Body.png",
                (0, 0), "images/Extras/Officer/[current_mood!c].png",
                (0, 0), "images/Extras/Officer/Hair.png",))
)

image chief = Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble [current_mood!c] right.png",
        (0, 0), "images/Extras/Chief/Body.png",
        (0, 0), "images/Extras/Chief/[current_mood!c].png",
        (0, 0), "images/Extras/Chief/Hair.png",
)

image chief holo = holo(Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble [current_mood!c] right.png",
        (0, 0), "images/Extras/Chief/Body.png",
        (0, 0), "images/Extras/Chief/[current_mood!c].png",
        (0, 0), "images/Extras/Chief/Hair.png",
))