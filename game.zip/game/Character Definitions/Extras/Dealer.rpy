init:
    $ dealer = Character("DEALER", color="#292928", who_outlines=[ (1, "#E5DBD9") ], what_xpos=175, what_ypos=-20, who_xpos=285, who_ypos=805)
    $ neighbor = Character("NEIGHBOR", color="#292928", who_outlines=[ (1, "#E5DBD9") ], what_xpos=175, what_ypos=-20, who_xpos=285, who_ypos=805)

    $ this_bitch = Character("THIS BITCH", color="#292928", who_outlines=[ (1, "#E5DBD9") ], what_xpos=175, what_ypos=-20, who_xpos=285, who_ypos=805)
    $ ugh = Character("UGH", color="#292928", who_outlines=[ (1, "#E5DBD9") ], what_xpos=175, what_ypos=-20, who_xpos=285, who_ypos=805)
    $ jacqueline = Character("JACQUELINE", color="#292928", who_outlines=[ (1, "#E5DBD9") ], what_xpos=175, what_ypos=-20, who_xpos=285, who_ypos=805) 

image jacqueline = Transform(Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble [current_mood] MC.png",
        (0, 0), AlphaMask(Transform(Composite(
                    (769, 1350),
                        (20, 400), Transform("images/Extras/Dealer/prison_bully_[current_mood].png", zoom=1)
                ), zoom=0.75), "images/Bubbles/alpha_mask.png"),
    ), xzoom=-1)


image dealer = Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble Neutral right.png",
        (0, 0), "images/Extras/Dealer/Body.png",
        (0, 0), "images/Extras/Dealer/Neutral.png",
        (0, 0), "images/Extras/Dealer/Hair.png",
)

image dealer mad = Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble Angry right.png",
        (0, 0), "images/Extras/Dealer/Body.png",
        (0, 0), "images/Extras/Dealer/Angry.png",
        (0, 0), "images/Extras/Dealer/Hair.png",
)
image dealer hap = Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble Happy right.png",
        (0, 0), "images/Extras/Dealer/Body.png",
        (0, 0), "images/Extras/Dealer/Happy.png",
        (0, 0), "images/Extras/Dealer/Hair.png",
)
image dealer sur = Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble Surprised right.png",
        (0, 0), "images/Extras/Dealer/Body.png",
        (0, 0), "images/Extras/Dealer/Surprised.png",
        (0, 0), "images/Extras/Dealer/Hair.png",
)
image dealer sad = Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble Sad right.png",
        (0, 0), "images/Extras/Dealer/Body.png",
        (0, 0), "images/Extras/Dealer/Sad.png",
        (0, 0), "images/Extras/Dealer/Hair.png",
)
