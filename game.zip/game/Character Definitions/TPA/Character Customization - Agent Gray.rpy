###Gray Textbox
init:
    $ grey = Character("[capsAgentGrey]", color="#292928", who_outlines=[ (1, "#E5DBD9") ], what_xpos=175, what_ypos=-20, who_xpos=285, who_ypos=805)
    $ grey_text = Character('[AgentGrey]', kind=nvl, color="#E5DBD9", what_color="#E5DBD9", who_size=28, what_size=33, bottom_padding=5, what_xpos=45, who_xpos=45)
    $ left_grey = Character("[capsAgentGrey]", color="#292928", who_outlines=[ (1, "#E5DBD9") ], window_top_padding=831, what_xpos=100, what_ypos=-20, who_xpos=310, who_ypos=805)

    $ grey_holo = Character("[capsAgentGrey]", color="#292928", what_color="#23a997", who_outlines=[ (1, "#23a997") ], what_xpos=175, what_ypos=-20, who_xpos=285, who_ypos=805)
    $ grey_holo_text = Character('[AgentGrey]', kind=nvl, color="#E5DBD9", what_color="#23a997", who_size=28, what_size=33, bottom_padding=5, what_xpos=45, who_xpos=45)
    $ left_grey_holo = Character("[capsAgentGrey]", color="#292928", who_outlines=[ (1, "#23a997") ], window_top_padding=831, what_xpos=100, what_ypos=-20, who_xpos=310, who_ypos=805)

default grey_race = 1
default grey_race_max = 3
default grey_outfit = 1
default grey_outfit_max = 9
default grey_hair = 1
default grey_hair_max = 10
default grey_female = True
default grey_undies = 1
default grey_undies_max = 2
default grey_pjs = 1
default grey_pjs_max = 2
default grey_heist = 1
default grey_nipples = grey_undies
default grey_towel = 1
default grey_mood = "neutral"
default grey_outfit_style = "casual"

init python:

    def change_grey_outfit(outfit, index):
        global grey_outfit, grey_outfit_style

        grey_outfit_style = outfit
        grey_outfit = index

#####################################renpy langauge version:

###Full Sized
image big grey = Transform(Composite(
    (769, 1350),
        (0, 0), ConditionSwitch(
            "grey_female", Composite(
                (769, 1350),
                    (120, 180), Transform("Create_Character/Grey/Hair/grey_[grey_pjs]_[grey_race]_back.png", zoom=0.75),
                    (120, 180), Transform("Create_Character/Grey/Mood/grey_[grey_pjs]_[grey_race]_body.png", zoom=0.75),
                    (120, 180), Transform("Create_Character/Grey/Mood/grey_[grey_pjs]_[grey_race]_[grey_mood].png", zoom=0.75),
                    (120, 180), Transform("Create_character/Grey/Outfits/grey_[grey_pjs]_[grey_outfit_style][grey_outfit].png", zoom=0.75),
                    (120, 180), Transform("Create_character/Grey/Hair/grey_[grey_pjs]_[grey_race].png", zoom=0.75)
                ),
            "True", Composite(
                (769, 1350),
                    (100, 180), Transform("Create_Character/Grey/Mood/grey_[grey_pjs]_[grey_race]_body.png", zoom=0.75),
                    (100, 180), Transform("Create_Character/Grey/Mood/grey_[grey_pjs]_[grey_race]_[grey_mood].png", zoom=0.75),
                    (100, 180), Transform("Create_character/Grey/Outfits/grey_[grey_pjs]_[grey_outfit_style][grey_outfit].png", zoom=0.75),
                    (100, 180), Transform("Create_character/Grey/Hair/grey_[grey_pjs]_[grey_race].png", zoom=0.75)
                )
            )
), xzoom=-1)

###Resized
image grey = Transform(Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble [current_mood] MC.png",
        (0, 0), AlphaMask(ConditionSwitch(

            "grey_female", Transform(Composite(
                                (769, 1350),
                                    (100, 440), Transform("Create_Character/Grey/Hair/grey_[grey_pjs]_[grey_race]_back.png", zoom=0.75),
                                    (100, 440), Transform("Create_Character/Grey/Mood/grey_[grey_pjs]_[grey_race]_body.png", zoom=0.75),
                                    (100, 440), Transform("Create_Character/Grey/Mood/grey_[grey_pjs]_[grey_race]_[current_mood].png", zoom=0.75),
                                    (100, 440), Transform("Create_character/Grey/Outfits/grey_[grey_pjs]_[grey_outfit_style][grey_outfit].png", zoom=0.75),
                                    (100, 440), Transform("Create_character/Grey/Hair/grey_[grey_pjs]_[grey_race].png", zoom=0.75)
                            ), zoom=0.75),
            "True", Transform(Composite(
                                (769, 1350),
                                    (30, 440), Transform("Create_Character/Grey/Mood/grey_[grey_pjs]_[grey_race]_body.png", zoom=0.75),
                                    (30, 440), Transform("Create_Character/Grey/Mood/grey_[grey_pjs]_[grey_race]_[current_mood].png", zoom=0.75),
                                    (30, 440), Transform("Create_character/Grey/Outfits/grey_[grey_pjs]_[grey_outfit_style][grey_outfit].png", zoom=0.75),
                                    (30, 440), Transform("Create_character/Grey/Hair/grey_[grey_pjs]_[grey_race].png", zoom=0.75)
                                ), zoom=0.75)
        ), mask="images/Bubbles/alpha_mask.png"),
), xzoom=-1)

image grey holo = Transform(Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble [current_mood] MC.png",
        (0, 0), AlphaMask(holo(ConditionSwitch(

            "grey_female", Transform(Composite(
                                (769, 1350),
                                    (100, 440), Transform("Create_Character/Grey/Hair/grey_[grey_pjs]_[grey_race]_back.png", zoom=0.75),
                                    (100, 440), Transform("Create_Character/Grey/Mood/grey_[grey_pjs]_[grey_race]_body.png", zoom=0.75),
                                    (100, 440), Transform("Create_Character/Grey/Mood/grey_[grey_pjs]_[grey_race]_[current_mood].png", zoom=0.75),
                                    (100, 440), Transform("Create_character/Grey/Outfits/grey_[grey_pjs]_[grey_outfit_style][grey_outfit].png", zoom=0.75),
                                    (100, 440), Transform("Create_character/Grey/Hair/grey_[grey_pjs]_[grey_race].png", zoom=0.75)
                            ), zoom=0.75),
            "True", Transform(Composite(
                                (769, 1350),
                                    (30, 440), Transform("Create_Character/Grey/Mood/grey_[grey_pjs]_[grey_race]_body.png", zoom=0.75),
                                    (30, 440), Transform("Create_Character/Grey/Mood/grey_[grey_pjs]_[grey_race]_[current_mood].png", zoom=0.75),
                                    (30, 440), Transform("Create_character/Grey/Outfits/grey_[grey_pjs]_[grey_outfit_style][grey_outfit].png", zoom=0.75),
                                    (30, 440), Transform("Create_character/Grey/Hair/grey_[grey_pjs]_[grey_race].png", zoom=0.75)
                                ), zoom=0.75)
        )), mask="images/Bubbles/alpha_mask.png"),
), xzoom=-1)


#####################################python version:
screen race_grey():
    default move = truecenter

    zorder 100000000000000
    modal True

    #add "blur summer background"
    add "big grey" at move

    if closet_choice_expanded:
        imagemap:
            idle "Dressup_Screen/idle no arrows.png"
            hover "Dressup_Screen/selected no arrows.png"
            selected_idle "Dressup_Screen/selected no arrows.png"
            selected_hover "Dressup_Screen/selected no arrows.png"

            ##Continue##
            hotspot (60,900,647,286) action Return() keysym "K_RETURN"

        imagebutton:
            xalign 0.865
            yalign 0.72
            idle "Dressup_Screen/arrow down.png"
            action (SetVariable("closet_choice_expanded", False))

        imagebutton:
            xoffset 20
            xalign 0.0
            yalign 0.5
            idle "Dressup_Screen/arrow left.png"
            action SetScreenVariable("move", move_right(PrevGreyModel, SetScreenVariable("move", truecenter)))
            keysym "K_LEFT"

        imagebutton:
            xoffset -20
            xalign 1.0
            yalign 0.5
            idle "Dressup_Screen/arrow right.png"
            action SetScreenVariable("move", move_left(NextGreyModel, SetScreenVariable("move", truecenter)))
            keysym "K_RIGHT"

    else:
        imagebutton:
            xalign 0.865
            yalign 0.98
            idle "Dressup_Screen/arrow up.png"
            action (SetVariable("closet_choice_expanded", True))