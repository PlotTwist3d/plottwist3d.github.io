init:
    $ vivian = Character("VIVIAN", color="#292928", who_outlines=[ (1, "#E5DBD9") ], what_xpos=175, what_ypos=-20, who_xpos=285, who_ypos=805)
    $ vivian_holo = Character("VIVIAN", color="#292928", what_color="#23a997", who_outlines=[ (1, "#E5DBD9") ], what_xpos=175, what_ypos=-20, who_xpos=285, who_ypos=805)

image vivian = Transform(Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble [current_mood] MC.png",
        (0, 0), AlphaMask(Transform(Composite(
                    (769, 1350),
                        (0, 450), Transform("images/Extras/Vivian/Vivian [current_mood!c].png", xzoom=-1)
                ), zoom=0.80), "images/Bubbles/alpha_mask.png"),
), xzoom=-1)

image vivian holo = Transform(Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble [current_mood] MC.png",
        (0, 0), AlphaMask(holo(Transform(Composite(
                    (769, 1350),
                        (0, 450), Transform("images/Extras/Vivian/Vivian [current_mood!c].png", xzoom=-1)
                ), zoom=0.80)), "images/Bubbles/alpha_mask.png"),
), xzoom=-1)