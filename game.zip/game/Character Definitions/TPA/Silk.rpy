init:
    $ mathilda = Character("MATHILDA", color="#292928", who_outlines=[ (1, "#E5DBD9") ], what_xpos=175, what_ypos=-20, who_xpos=285, who_ypos=805)
    $ silk = Character("SILK", color="#292928", who_outlines=[ (1, "#E5DBD9") ], what_xpos=175, what_ypos=-20, who_xpos=285, who_ypos=805)

image silk = Transform(Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble [current_mood] MC.png",
        (0, 0), AlphaMask(Transform(Composite(
                    (769, 1350),
                        (0, 450), Transform("images/Extras/Silk/Sister_Outgoing_Formal-[current_mood!c].png", xzoom=-1)
                ), zoom=0.80), "images/Bubbles/alpha_mask.png"),
), xzoom=-1)

image silk casual = Transform(Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble [current_mood] MC.png",
        (0, 0), AlphaMask(Transform(Composite(
                    (769, 1350),
                        (0, 450), Transform("images/Extras/Silk/Sister_Outgoing-[current_mood!c].png", xzoom=-1)
                ), zoom=0.80), "images/Bubbles/alpha_mask.png"),
), xzoom=-1)