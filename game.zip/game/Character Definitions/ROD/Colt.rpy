###Colt Textbox
init:
    $ colt = Character("COLT", color="#292928", who_outlines=[ (1, "#E5DBD9") ], what_xpos=175, what_ypos=-20, who_xpos=285, who_ypos=805)
    $ colt_text = Character('Colt', kind=nvl, color="#E5DBD9", what_color="#E5DBD9", who_size=28, what_size=33, bottom_padding=5, what_xpos=45, who_xpos=45)
    $ left_colt = Character("COLT", color="#292928", who_outlines=[ (1, "#E5DBD9") ], window_top_padding=831, what_xpos=100, what_ypos=-20, who_xpos=310, who_ypos=805)

    $ colt_holo = Character("COLT", color="#292928", what_color="#23a997", who_outlines=[ (1, "#E5DBD9") ], what_xpos=175, what_ypos=-20, who_xpos=285, who_ypos=805)
    $ colt_holo_text = Character('Colt', kind=nvl, color="#E5DBD9", what_color="#E5DBD9", who_size=28, what_size=33, bottom_padding=5, what_xpos=45, who_xpos=45)
    $ left_colt_holo = Character("COLT", color="#292928", who_outlines=[ (1, "#E5DBD9") ], window_top_padding=831, what_xpos=100, what_ypos=-20, who_xpos=310, who_ypos=805)


###Colt Image
default colt_outfit_style = "casual"
default colt_hair = "casual"
default colt_nipples = "undies"
default colt_mood = "neutral"
default colt_outfit = 1
default colt_jacket = True
default young_colt_outfit = "casual"

init python:

    def change_colt_outfit(outfit, index, jacket=True):
        global colt_outfit, colt_outfit_style, colt_jacket

        colt_outfit_style = outfit
        colt_outfit = index
        colt_jacket = jacket

image big colt = Transform(Composite(
    (769, 1350),
        (80, 200), Transform("images/Colt/Mood/colt_body.png", zoom=0.75),
        (80, 200), Transform("images/Colt/Mood/colt_outfit_[colt_outfit_style][colt_outfit].png", zoom=0.75),
        (80, 200), ConditionSwitch(
            "colt_jacket", Transform("images/Colt/Mood/colt_outfit_jacket.png", zoom=0.75),
            True, "images/Colt/Mood/nothing.png"
        ),
        (80, 200), Transform("images/Colt/Mood/colt_[colt_mood].png", zoom=0.75),
        (80, 200), Transform("images/Colt/Mood/colt_hair.png", zoom=0.75),
), xzoom=-1)

image colt = Transform(Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble [current_mood] MC.png",
        (0, 0), AlphaMask(Transform(Composite(
                    (769, 1350),
                        (10, 460), Transform("images/Colt/Mood/colt_body.png", zoom=0.75),
                        (10, 460), Transform("images/Colt/Mood/colt_outfit_[colt_outfit_style][colt_outfit].png", zoom=0.75),
                        (10, 460), ConditionSwitch(
                                    "colt_jacket", Transform("images/Colt/Mood/colt_outfit_jacket.png", zoom=0.75),
                                    True, "images/Colt/Mood/nothing.png"
                                ),
                        (10, 460), Transform("images/Colt/Mood/colt_[current_mood].png", zoom=0.75),
                        (10, 460), Transform("images/Colt/Mood/colt_hair.png", zoom=0.75),
                ), zoom=0.75), "images/Bubbles/alpha_mask.png"),
), xzoom=-1)

image colt helmet = Transform(Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble [current_mood] MC.png",
        (0, 0), AlphaMask(Transform(Composite(
                    (769, 1350),
                        (10, 460), Transform("images/Colt/Mood/colt_body.png", zoom=0.75),
                        (10, 460), Transform("images/Colt/Mood/colt_outfit_[colt_outfit_style][colt_outfit].png", zoom=0.75),
                        (10, 460), ConditionSwitch(
                                    "colt_jacket", Transform("images/Colt/Mood/colt_outfit_jacket.png", zoom=0.75),
                                    True, "images/Colt/Mood/nothing.png"
                                ),
                        (10, 460), Transform("images/Colt/Mood/colt_helmet.png", zoom=0.75),
                ), zoom=0.75), "images/Bubbles/alpha_mask.png"),
), xzoom=-1)

image colt holo = Transform(Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble [colt_mood] MC.png",
        (0, 0), AlphaMask(holo(Transform(Composite(
                    (769, 1350),
                        (10, 460), Transform("images/Colt/Mood/colt_body.png", zoom=0.75),
                        (10, 460), Transform("images/Colt/Mood/colt_outfit_[colt_outfit_style][colt_outfit].png", zoom=0.75),
                        (10, 460), ConditionSwitch(
                                    "colt_jacket", Transform("images/Colt/Mood/colt_outfit_jacket.png", zoom=0.75),
                                    True, "images/Colt/Mood/nothing.png"
                                ),
                        (10, 460), Transform("images/Colt/Mood/colt_[current_mood].png", zoom=0.75),
                        (10, 460), Transform("images/Colt/Mood/colt_hair.png", zoom=0.75),
                ), zoom=0.75)), "images/Bubbles/alpha_mask.png"),
), xzoom=-1)

image big young colt = Transform(Composite(
    (769, 1350),
        (-20, 350), Transform("images/Colt/Young_colt/colt_[young_colt_outfit]_[current_mood].png", zoom=1),
), xzoom=-1)

image colt young = Transform(Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble [current_mood] MC.png",
        (0, 0), AlphaMask(Transform(Composite(
                    (769, 1350),
                        (-70, 550), Transform("images/Colt/Young Colt/colt_[young_colt_outfit]_[current_mood].png", zoom=1)
                ), zoom=0.75), "images/Bubbles/alpha_mask.png"),
), xzoom=-1)
