###Mona Textbox
init:
    $ mona = Character("MONA", color="#292928", who_outlines=[ (1, "#E5DBD9") ], what_xpos=175, what_ypos=-20, who_xpos=285, who_ypos=805)
    $ mona_text = Character('Mona', kind=nvl, color="#E5DBD9", what_color="#E5DBD9", who_size=28, what_size=33, bottom_padding=5, what_xpos=45, who_xpos=45)
    $ left_mona = Character("MONA", color="#292928", who_outlines=[ (1, "#E5DBD9") ], window_top_padding=831, what_xpos=100, what_ypos=-20, who_xpos=310, who_ypos=805)

    $ mona_holo = Character("MONA", color="#292928", what_color="#23a997", who_outlines=[ (1, "#E5DBD9") ], what_xpos=175, what_ypos=-20, who_xpos=285, who_ypos=805)
    $ left_mona_holo = Character("MONA", color="#292928", who_outlines=[ (1, "#E5DBD9") ], window_top_padding=831, what_xpos=100, what_ypos=-20, who_xpos=310, who_ypos=805)

###Mona Image
default mona_outfit_bottom = 1
default mona_outfit_top = 1
default mona_hair = "casual"
default mona_nipples = "undies"
default mona_mood = "neutral"
default mona_outfit = 1
default mona_jacket = True
default young_mona_outfit = "casual"

init python:

    def change_mona_outfit(bottom, top, jacket=True):
        global mona_outfit_bottom, mona_outfit_top, mona_jacket

        mona_outfit_bottom = bottom
        mona_outfit_top = top
        mona_jacket = jacket

image big mona = Transform(Composite(
    (769, 1350),
        (130, 200), Transform("images/Mona/Mood/mona_hair_back.png", zoom=1),
        (130, 200), Transform("images/Mona/Mood/mona_body.png", zoom=1),
        (130, 200), Transform("images/Mona/Mood/mona_outfit_bottom[mona_outfit_bottom].png", zoom=1),
        (130, 200), Transform("images/Mona/Mood/mona_outfit_top[mona_outfit_top].png", zoom=1),
        (130, 200), ConditionSwitch(
            "mona_jacket", Transform("images/Mona/Mood/mona_outfit_jacket.png", zoom=1),
            True, "images/Mona/Mood/mona_outfit_bottom0.png"
        ),
        (130, 200), Transform("images/Mona/Mood/mona_[mona_mood].png", zoom=1),
        (130, 200), Transform("images/Mona/Mood/mona_hair_front.png", zoom=1),
), xzoom=-1)

image big mona bruised = Transform(Composite(
    (769, 1350),
        (130, 200), Transform("images/Mona/Mood/mona_hair_back.png", zoom=1),
        (130, 200), Transform("images/Mona/Mood/mona_body_bruised.png", zoom=1),
        (130, 200), Transform("images/Mona/Mood/mona_outfit_bottom[mona_outfit_bottom].png", zoom=1),
        (130, 200), Transform("images/Mona/Mood/mona_outfit_top[mona_outfit_top].png", zoom=1),
        (130, 200), ConditionSwitch(
            "mona_jacket", Transform("images/Mona/Mood/mona_outfit_jacket.png", zoom=1),
            True, "images/Mona/Mood/mona_outfit_bottom0.png"
        ),
        (130, 200), Transform("images/Mona/Mood/mona_[mona_mood].png", zoom=1),
        (130, 200), Transform("images/Mona/Mood/mona_hair_front.png", zoom=1),
), xzoom=-1)

image mona = Transform(Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble [current_mood] MC.png",
        (0, 0), AlphaMask(Transform(Composite(
                (769, 1350),
                    (80, 440), Transform("images/Mona/Mood/mona_hair_back.png", zoom=1),
                    (80, 440), Transform("images/Mona/Mood/mona_body.png", zoom=1),
                    (80, 440), Transform("images/Mona/Mood/mona_outfit_bottom[mona_outfit_bottom].png", zoom=1),
                    (80, 440), Transform("images/Mona/Mood/mona_outfit_top[mona_outfit_top].png", zoom=1),
                    (80, 440), ConditionSwitch(
                        "mona_jacket", Transform("images/Mona/Mood/mona_outfit_jacket.png", zoom=1),
                        True, "images/Mona/Mood/mona_outfit_bottom0.png"
                    ),
                    (80, 440), Transform("images/Mona/Mood/mona_[current_mood].png", zoom=1),
                    (80, 440), Transform("images/Mona/Mood/mona_hair_front.png", zoom=1),
            ), zoom=0.75), "images/Bubbles/alpha_mask.png"),
), xzoom=-1)

image mona holo = Transform(Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble [current_mood] MC.png",
        (0, 0), AlphaMask(holo(Transform(Composite(
                (769, 1350),
                    (80, 440), Transform("images/Mona/Mood/mona_hair_back.png", zoom=1),
                    (80, 440), Transform("images/Mona/Mood/mona_body.png", zoom=1),
                    (80, 440), Transform("images/Mona/Mood/mona_outfit_bottom[mona_outfit_bottom].png", zoom=1),
                    (80, 440), Transform("images/Mona/Mood/mona_outfit_top[mona_outfit_top].png", zoom=1),
                    (80, 440), ConditionSwitch(
                        "mona_jacket", Transform("images/Mona/Mood/mona_outfit_jacket.png", zoom=1),
                        True, "images/Mona/Mood/mona_outfit_bottom0.png"
                    ),
                    (80, 440), Transform("images/Mona/Mood/mona_[current_mood].png", zoom=1),
                    (80, 440), Transform("images/Mona/Mood/mona_hair_front.png", zoom=1),
            ), zoom=0.75)), "images/Bubbles/alpha_mask.png"),
), xzoom=-1)

image mona bruised = Transform(Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble [current_mood] MC.png",
        (0, 0), AlphaMask(Transform(Composite(
                (769, 1350),
                    (80, 440), Transform("images/Mona/Mood/mona_hair_back.png", zoom=1),
                    (80, 440), Transform("images/Mona/Mood/mona_body_bruised.png", zoom=1),
                    (80, 440), Transform("images/Mona/Mood/mona_outfit_bottom[mona_outfit_bottom].png", zoom=1),
                    (80, 440), Transform("images/Mona/Mood/mona_outfit_top[mona_outfit_top].png", zoom=1),
                    (80, 440), ConditionSwitch(
                        "mona_jacket", Transform("images/Mona/Mood/mona_outfit_jacket.png", zoom=1),
                        True, "images/Mona/Mood/mona_outfit_bottom0.png"
                    ),
                    (80, 440), Transform("images/Mona/Mood/mona_[current_mood].png", zoom=1),
                    (80, 440), Transform("images/Mona/Mood/mona_hair_front.png", zoom=1),
            ), zoom=0.75), "images/Bubbles/alpha_mask.png"),
), xzoom=-1)

image mona bruised holo = Transform(Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble [current_mood] MC.png",
        (0, 0), AlphaMask(holo(Transform(Composite(
                (769, 1350),
                    (80, 440), Transform("images/Mona/Mood/mona_hair_back.png", zoom=1),
                    (80, 440), Transform("images/Mona/Mood/mona_body_bruised.png", zoom=1),
                    (80, 440), Transform("images/Mona/Mood/mona_outfit_bottom[mona_outfit_bottom].png", zoom=1),
                    (80, 440), Transform("images/Mona/Mood/mona_outfit_top[mona_outfit_top].png", zoom=1),
                    (80, 440), ConditionSwitch(
                        "mona_jacket", Transform("images/Mona/Mood/mona_outfit_jacket.png", zoom=1),
                        True, "images/Mona/Mood/mona_outfit_bottom0.png"
                    ),
                    (80, 440), Transform("images/Mona/Mood/mona_[current_mood].png", zoom=1),
                    (80, 440), Transform("images/Mona/Mood/mona_hair_front.png", zoom=1),
            ), zoom=0.75)), "images/Bubbles/alpha_mask.png"),
), xzoom=-1)

image big young mona = Transform(Composite(
    (769, 1350),
        (-20, 350), Transform("images/Mona/Young Mona/mona_[young_mona_outfit]_[current_mood].png", zoom=1),
), xzoom=-1)

image mona young = Transform(Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble [current_mood] MC.png",
        (0, 0), AlphaMask(Transform(Composite(
                    (769, 1350),
                        (-70, 550), Transform("images/Mona/Young Mona/mona_[young_mona_outfit]_[current_mood].png", zoom=1)
                ), zoom=0.75), "images/Bubbles/alpha_mask.png"),
), xzoom=-1)
