###Logan Textbox
init:
    $ logan = Character("LOGAN", color="#292928", who_outlines=[ (1, "#E5DBD9") ], what_xpos=175, what_ypos=-20, who_xpos=285, who_ypos=805)
    $ logan_text = Character('Logan', kind=nvl, color="#E5DBD9", what_color="#E5DBD9", who_size=28, what_size=33, bottom_padding=5, what_xpos=45, who_xpos=45)
    $ left_logan = Character("LOGAN", color="#292928", who_outlines=[ (1, "#E5DBD9") ], window_top_padding=831, what_xpos=100, what_ypos=-20, who_xpos=310, who_ypos=805)
    
    $ logan_holo = Character("LOGAN", color="#292928", what_color="#23a997", who_outlines=[ (1, "#292928") ], what_xpos=175, what_ypos=-20, who_xpos=285, who_ypos=805)
    $ logan_holo_text = Character('Logan', kind=nvl, color="#E5DBD9", what_color="#23a997", who_size=28, what_size=33, bottom_padding=5, what_xpos=45, who_xpos=45)
    $ left_logan_holo = Character("LOGAN", color="#292928", who_outlines=[ (1, "#E5DBD9") ], window_top_padding=831, what_xpos=100, what_ypos=-20, who_xpos=310, who_ypos=805)

default logan_race = 1
default logan_race_max = 4
default logan_outfit = 2
default logan_undies = 1
default logan_undies_max = 4
default logan_pjs = 1
default logan_pjs_max = 2
default logan_formal = 1
default logan_formal_max = 5
default capsLogan = "LOGAN"
default logan_nipples = logan_undies
default logan_mood = "neutral"
default logan_outfit_style = "casual"
default young_logan_outfit = "casual"

init python:

    def change_logan_outfit(outfit, index):
        global logan_outfit, logan_outfit_style

        logan_outfit_style = outfit
        logan_outfit = index

#####################################renpy language version:
####Full sized
image big logan = Transform(Composite(
    (769, 1350),
        (70, 200), Transform("Create_character/Logan/Hair/logan_[logan_race]underhair.png", zoom=0.85),
        (70, 200), Transform("Create_Character/Logan/Mood/logan_[logan_race].png", zoom=0.85),
        (70, 200), Transform("Create_character/Logan/Mood/logan_[logan_race]_[logan_mood].png", zoom=0.85),
        (70, 200), ConditionSwitch(
            "logan_race == 2", Transform("Create_character/Logan/Eyes/Eye0.png", zoom=0.85),
            "True", Transform("Create_character/Logan/Eyes/full/logan[logan_race]_human_[logan_mood].png", zoom=0.85)
            ),
        (70, 200), Transform("Create_character/Logan/Stubble/Stubble.png", zoom=0.85),
        (70, 200), Transform("Create_character/Logan/Outfits/logan_[logan_outfit_style][logan_outfit].png", zoom=0.85),
        (70, 200), Transform("Create_character/Logan/Hair/logan_[logan_race]overhair.png", zoom=0.85),
), xzoom=-1)

###Resized
image logan = Transform(Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble [current_mood] MC.png",
        (0, 0), AlphaMask(Transform(Composite(
                    (769, 1350),
                        (10, 400), Transform("Create_character/Logan/Hair/logan_[logan_race]underhair.png", zoom=0.85),
                        (10, 400), Transform("Create_Character/Logan/Mood/logan_[logan_race].png", zoom=0.85),
                        (10, 400), Transform("Create_character/Logan/Mood/logan_[logan_race]_[current_mood].png", zoom=0.85),
                        (10, 400), ConditionSwitch(
                            "logan_race == 2", Transform("Create_character/Logan/Eyes/Eye0.png", zoom=0.85),
                            "True", Transform("Create_character/Logan/Eyes/full/logan[logan_race]_human_[current_mood].png", zoom=0.85)
                            ),
                        (10, 400), Transform("Create_character/Logan/Stubble/Stubble.png", zoom=0.85),
                        (10, 400), Transform("Create_character/Logan/Outfits/logan_[logan_outfit_style][logan_outfit].png", zoom=0.85),
                        (10, 400), Transform("Create_character/Logan/Hair/logan_[logan_race]overhair.png", zoom=0.85),
                ), zoom=0.75), "images/Bubbles/alpha_mask.png"),
), xzoom=-1)

image logan holo = Transform(Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble [logan_mood] MC.png",
        (0, 0), AlphaMask(holo(Transform(Composite(
                    (769, 1350),
                        (10, 400), Transform("Create_character/Logan/Hair/logan_[logan_race]underhair.png", zoom=0.85),
                        (10, 400), Transform("Create_Character/Logan/Mood/logan_[logan_race].png", zoom=0.85),
                        (10, 400), Transform("Create_character/Logan/Mood/logan_[logan_race]_[current_mood].png", zoom=0.85),
                        (10, 400), ConditionSwitch(
                            "logan_race == 2", Transform("Create_character/Logan/Eyes/Eye0.png", zoom=0.85),
                            "True", Transform("Create_character/Logan/Eyes/full/logan[logan_race]_human_[current_mood].png", zoom=0.85)
                            ),
                        (10, 400), Transform("Create_character/Logan/Stubble/Stubble.png", zoom=0.85),
                        (10, 400), Transform("Create_character/Logan/Outfits/logan_[logan_outfit_style][logan_outfit].png", zoom=0.85),
                        (10, 400), Transform("Create_character/Logan/Hair/logan_[logan_race]overhair.png", zoom=0.85),
                ), zoom=0.75)), "images/Bubbles/alpha_mask.png"),
), xzoom=-1)

image big young logan = Transform(Composite(
    (769, 1350),
        (-20, 350), Transform("Create_character/Logan/Young_Logan/Face [logan_race]/logan_[young_logan_outfit]_[current_mood].png", zoom=1),
), xzoom=-1)

image logan young = Transform(Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble [current_mood] MC.png",
        (0, 0), AlphaMask(Transform(Composite(
                    (769, 1350),
                        (-70, 550), Transform("Create_character/Logan/Young_Logan/Face [logan_race]/logan_[young_logan_outfit]_[current_mood].png", zoom=1)
                ), zoom=0.75), "images/Bubbles/alpha_mask.png"),
), xzoom=-1)

#####################################python version:
screen race_logan():
    default move = truecenter

    zorder 100000000000000
    modal True

    add "apartment night" at center
    add "big logan" at move

    if closet_choice_expanded:
        imagemap:
            idle "Dressup_Screen/idle no arrows.png"
            hover "Dressup_Screen/selected no arrows.png"
            selected_idle "Dressup_Screen/selected no arrows.png"
            selected_hover "Dressup_Screen/selected no arrows.png"

            ##Continue##
            hotspot (60,900,647,286) action Return() keysym "K_RETURN"

        imagebutton:
            xalign 0.865
            yalign 0.72
            idle "Dressup_Screen/arrow down.png"
            action (SetVariable("closet_choice_expanded", False))

        imagebutton:
            xoffset 20
            xalign 0.0
            yalign 0.5
            idle "Dressup_Screen/arrow left.png"
            action SetScreenVariable("move", move_right(PrevLoganModel, SetScreenVariable("move", truecenter)))
            keysym "K_LEFT"

        imagebutton:
            xoffset -20
            xalign 1.0
            yalign 0.5
            idle "Dressup_Screen/arrow right.png"
            action SetScreenVariable("move", move_left(NextLoganModel, SetScreenVariable("move", truecenter)))
            keysym "K_RIGHT"

    else:
        imagebutton:
            xalign 0.865
            yalign 0.98
            idle "Dressup_Screen/arrow up.png"
            action (SetVariable("closet_choice_expanded", True))
