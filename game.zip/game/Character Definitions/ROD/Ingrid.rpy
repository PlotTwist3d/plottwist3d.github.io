###Ingrid Textbox
init:
    $ ingrid = Character("INGRID", color="#292928", who_outlines=[ (1, "#E5DBD9") ], what_xpos=175, what_ypos=-20, who_xpos=285, who_ypos=805)
    $ ingrid_text = Character('Ingrid', kind=nvl, color="#E5DBD9", what_color="#E5DBD9", who_size=28, what_size=33, bottom_padding=5, what_xpos=45, who_xpos=45)
    $ left_ingrid = Character("INGRID", color="#292928", who_outlines=[ (1, "#E5DBD9") ], window_top_padding=831, what_xpos=100, what_ypos=-20, who_xpos=310, who_ypos=805)

    $ ingrid_holo = Character("INGRID", color="#292928", what_color="#23a997", who_outlines=[ (1, "#E5DBD9") ], what_xpos=175, what_ypos=-20, who_xpos=285, who_ypos=805)
    $ ingrid_holo_text = Character('Ingrid', kind=nvl, color="#E5DBD9", what_color="#E5DBD9", who_size=28, what_size=33, bottom_padding=5, what_xpos=45, who_xpos=45)
    $ left_ingrid_holo = Character("INGRID", color="#292928", who_outlines=[ (1, "#E5DBD9") ], window_top_padding=831, what_xpos=100, what_ypos=-20, who_xpos=310, who_ypos=805)


###Ingrid Image
default ingrid_outfit = 1
default ingrid_hair = 1
default ingrid_nipples = "undies"
default ingrid_mood = "neutral"
default ingrid_outfit_style = "casual"
default young_ingrid_outfit = "casual"

init python:

    def change_ingrid_outfit(outfit, index):
        global ingrid_outfit, ingrid_outfit_style

        ingrid_outfit_style = outfit
        ingrid_outfit = index

image big ingrid = Transform(Composite(
    (769, 1350),
        (150, 200), Transform("images/Ingrid/Mood/ingrid_hair[ingrid_hair]_back.png", zoom=0.75),
        (150, 200), Transform("images/Ingrid/Mood/ingrid_body.png", zoom=0.75),
        (150, 200), Transform("images/Ingrid/Mood/ingrid_[ingrid_outfit_style][ingrid_outfit].png", zoom=0.75),
        (150, 200), Transform("images/Ingrid/Mood/ingrid_[ingrid_mood].png", zoom=0.75),
        (150, 200), Transform("images/Ingrid/Mood/ingrid_hair[ingrid_hair].png", zoom=0.75),
), xzoom=-1)

image ingrid = Transform(Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble [current_mood] MC.png",
        (0, 0), AlphaMask(Transform(Composite(
                    (769, 1350),
                        (80, 500), Transform("images/Ingrid/Mood/ingrid_hair[ingrid_hair]_back.png", zoom=0.75),
                        (80, 500), Transform("images/Ingrid/Mood/ingrid_body.png", zoom=0.75),
                        (80, 500), Transform("images/Ingrid/Mood/ingrid_[ingrid_outfit_style][ingrid_outfit].png", zoom=0.75),
                        (80, 500), Transform("images/Ingrid/Mood/ingrid_[current_mood].png", zoom=0.75),
                        (80, 500), Transform("images/Ingrid/Mood/ingrid_hair[ingrid_hair].png", zoom=0.75),
                ), zoom=0.75), "images/Bubbles/alpha_mask.png"),
), xzoom=-1)

image ingrid holo = Transform(Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble [current_mood] MC.png",
        (0, 0), AlphaMask(holo(Transform(Composite(
                    (769, 1350),
                        (80, 500), Transform("images/Ingrid/Mood/ingrid_hair[ingrid_hair]_back.png", zoom=0.75),
                        (80, 500), Transform("images/Ingrid/Mood/ingrid_body.png", zoom=0.75),
                        (80, 500), Transform("images/Ingrid/Mood/ingrid_[ingrid_outfit_style][ingrid_outfit].png", zoom=0.75),
                        (80, 500), Transform("images/Ingrid/Mood/ingrid_[current_mood].png", zoom=0.75),
                        (80, 500), Transform("images/Ingrid/Mood/ingrid_hair[ingrid_hair].png", zoom=0.75),
                ), zoom=0.75)), "images/Bubbles/alpha_mask.png"),
), xzoom=-1)

image big young ingrid = Transform(Composite(
    (769, 1350),
        (-20, 350), Transform("images/Ingrid/Young_ingrid/ingrid_[young_ingrid_outfit]_[current_mood].png", zoom=1),
), xzoom=-1)

image ingrid young = Transform(Composite(
    (769, 1350),
        (0, 0), "images/Bubbles/Reaction Bubble [current_mood] MC.png",
        (0, 0), AlphaMask(Transform(Composite(
                    (769, 1350),
                        (-70, 550), Transform("images/Ingrid/Young Ingrid/ingrid_[young_ingrid_outfit]_[current_mood].png", zoom=1)
                ), zoom=0.75), "images/Bubbles/alpha_mask.png"),
), xzoom=-1)
